/**
 */
package dsl_4webquiz.tests;

import dsl_4webquiz.Dsl_4webquizFactory;
import dsl_4webquiz.Google_plus;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Google plus</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class Google_plusTest extends Redes_SocialesTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(Google_plusTest.class);
	}

	/**
	 * Constructs a new Google plus test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Google_plusTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Google plus test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected Google_plus getFixture() {
		return (Google_plus)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(Dsl_4webquizFactory.eINSTANCE.createGoogle_plus());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //Google_plusTest
