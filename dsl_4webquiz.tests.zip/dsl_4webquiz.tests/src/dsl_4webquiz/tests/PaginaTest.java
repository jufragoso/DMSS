/**
 */
package dsl_4webquiz.tests;

import dsl_4webquiz.Pagina;

import junit.framework.TestCase;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Pagina</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class PaginaTest extends TestCase {

	/**
	 * The fixture for this Pagina test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Pagina fixture = null;

	/**
	 * Constructs a new Pagina test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PaginaTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Pagina test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(Pagina fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Pagina test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Pagina getFixture() {
		return fixture;
	}

} //PaginaTest
