/**
 */
package dsl_4webquiz.tests;

import dsl_4webquiz.PAGINAS_CRUD;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>PAGINAS CRUD</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class PAGINAS_CRUDTest extends PaginaTest {

	/**
	 * Constructs a new PAGINAS CRUD test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PAGINAS_CRUDTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this PAGINAS CRUD test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected PAGINAS_CRUD getFixture() {
		return (PAGINAS_CRUD)fixture;
	}

} //PAGINAS_CRUDTest
