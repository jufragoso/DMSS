/**
 */
package dsl_4webquiz.tests;

import dsl_4webquiz.Dsl_4webquizFactory;
import dsl_4webquiz.TipoDatos;

import junit.framework.TestCase;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Tipo Datos</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class TipoDatosTest extends TestCase {

	/**
	 * The fixture for this Tipo Datos test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TipoDatos fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(TipoDatosTest.class);
	}

	/**
	 * Constructs a new Tipo Datos test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TipoDatosTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Tipo Datos test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(TipoDatos fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Tipo Datos test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TipoDatos getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(Dsl_4webquizFactory.eINSTANCE.createTipoDatos());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //TipoDatosTest
