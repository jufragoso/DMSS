/**
 */
package dsl_4webquiz.tests;

import dsl_4webquiz.Redes_Sociales;

import junit.framework.TestCase;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Redes Sociales</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class Redes_SocialesTest extends TestCase {

	/**
	 * The fixture for this Redes Sociales test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Redes_Sociales fixture = null;

	/**
	 * Constructs a new Redes Sociales test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Redes_SocialesTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Redes Sociales test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(Redes_Sociales fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Redes Sociales test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Redes_Sociales getFixture() {
		return fixture;
	}

} //Redes_SocialesTest
