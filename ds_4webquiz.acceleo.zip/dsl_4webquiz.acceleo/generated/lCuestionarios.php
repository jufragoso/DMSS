	<!DOCTYPE html>
	<html>
	    <head>
	        <meta charset="utf-8" />
	        <title>prueba4</title>
	    </head>
	    <body>
	        <div class="jumbotron">
	            <h1>prueba4</h1>
	            <p>Proyecto DMSS</p>
	        </div>
	            <ul class="nav nav-tabs">
	            <li role="presentation" ><a href="http://localhost/DMSS/index.html">Entidades</a></li>
	            <li role="presentation" ><a href="http://localhost/DMSS/lEncuestas.php">Encuestas</a></li>
				<li role="presentation" class="active"><a href="http://localhost/DMSS/lCuestionarios.php">Cuestionarios</a></li>
	            </ul>
	        <div class="panel panel-default">
				<table class="table">
				<tr><th></th><th>Contestar</th></tr>
					<tr><td>Cuestionario 1</td><td><a href="http://localhost/DMSS/CONSULTAS/cuestionario/10.php" ><button type="button" class="btn btn-default" aria-label="Left Align">
  <span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>
</button></a></td></tr>
				</table>
			</div>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
		<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
		</body>
	</html>
