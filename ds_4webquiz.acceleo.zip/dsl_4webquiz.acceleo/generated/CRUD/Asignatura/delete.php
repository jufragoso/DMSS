		<?php
		include_once '../dbconfig.php';
		if(isset($_GET['id']))
		{
			$sql_query = "SELECT * FROM ".str_replace(" ", "_", "Asignatura")."  WHERE ID='".$_GET['id']."'";
			$result_set=mysql_query($sql_query);
			$result_set = mysql_fetch_row($result_set);
		}
		if(isset($_POST['Borrar']))
		{
			$sql_query = "DELETE FROM ".str_replace(" ", "_", "Asignatura")." WHERE ID=".$_POST['id'];
		 	mysql_query($sql_query);
			header('Location: http://localhost/DMSS/CRUD/Asignatura/indice.php'); 
		}
		?>
		<!DOCTYPE html>
		<html>
		    <head>
		        <meta charset="utf-8" />
		        <title>prueba4</title>
		    </head>
		    <body>
		        <div class="jumbotron">
		            <h1>prueba4</h1>
		            <p>Proyecto DMSS</p>
		        </div>
					<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
					 <div class="row">
					<div class="col-md-4">
						<ul class="nav nav-tabs">
								<li class="active" ><a data-toggle="tab" href="#twitter">Twitter</a></li>
						</ul>
						<div class="tab-content">
								<div id="twitter" class="tab-pane fade in active">
									<a class="twitter-timeline" href="https://twitter.com/juanlu0809">Tweets de juanlu0809</a> <script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
								</div>
						</div>
					</div>
					<div class="col-md-8">
		            <ul class="nav nav-tabs">
		           		<li role="presentation" class="active"><a href="http://localhost/DMSS/index.html">Entidades</a></li>
			            <li role="presentation" ><a href="http://localhost/DMSS/lEncuestas.php">Encuestas</a></li>
						<li role="presentation"><a href="http://localhost/DMSS/lCuestionarios.php">Cuestionarios</a></li>
		            </ul>
					<ul class="nav nav-tabs">
							<li role="presentation"  class="active" ><a href="http://localhost/DMSS/CRUD/Asignatura/indice.php">Asignatura</a></li>
		
							<li role="presentation" ><a href="http://localhost/DMSS/CRUD/Profesor/indice.php">Profesor</a></li>
		
							<li role="presentation" ><a href="http://localhost/DMSS/CRUD/Centro de estudios/indice.php">Centro de estudios</a></li>
		
		</ul>	
		 <div id="content">
		    <form method="post" class="form-horizontal">
					<div class="form-group">
		            <label for="inputNombre" class="col-lg-2 control-label">creditos</label>
		            <div class="col-lg-10">
						<p class="form-control-static"><?php echo $result_set[1]; ?></p>
		            </div>
		          	</div>
					<div class="form-group">
		            <label for="inputNombre" class="col-lg-2 control-label">nombre</label>
		            <div class="col-lg-10">
						<p class="form-control-static"><?php echo $result_set[2]; ?></p>
		            </div>
		          	</div>
					<div class="form-group">
		            <label for="inputNombre" class="col-lg-2 control-label">responsable</label>
		            <div class="col-lg-10">
						<p class="form-control-static"><?php echo $result_set[3]; ?></p>
		            </div>
		          	</div>
					<input type="hidden" name="id" value="<?php echo $_GET['id']; ?>" >
		          	<div class="form-group">
		      			<div class="col-lg-10 col-lg-offset-2">
				        <button type="reset" class="btn btn-default">Cancelar</button>
				        <button type="submit" class="btn btn-primary" name="Borrar">Eliminar</button>
				      </div>
		    </div>
		        </form>
		    </div>
		    </div>
		    <!-- Latest compiled and minified JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
		<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
		</div>
		</body>
		</html>
