		<?php
			include_once '../dbconfig.php';
		?>
		<!DOCTYPE html>
		<html>
		    <head>
		        <meta charset="utf-8" />
		        <title>prueba4</title>
		    </head>
		    <body>
		        <div class="jumbotron">
		            <h1>prueba4</h1>
		            <p>Proyecto DMSS</p>
		        </div>
					<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
					 <div class="row">
					<div class="col-md-4">
						<ul class="nav nav-tabs">
								<li class="active" ><a data-toggle="tab" href="#twitter">Twitter</a></li>
						</ul>
						<div class="tab-content">
								<div id="twitter" class="tab-pane fade in active">
									<a class="twitter-timeline" href="https://twitter.com/juanlu0809">Tweets de juanlu0809</a> <script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
								</div>
						</div>
					</div>
					<div class="col-md-8">
		            <ul class="nav nav-tabs">
		           		<li role="presentation" class="active"><a href="http://localhost/DMSS/index.html">Entidades</a></li>
			            <li role="presentation" ><a href="http://localhost/DMSS/lEncuestas.php">Encuestas</a></li>
						<li role="presentation"><a href="http://localhost/DMSS/lCuestionarios.php">Cuestionarios</a></li>
		            </ul>
					<ul class="nav nav-tabs">
							<li role="presentation" ><a href="http://localhost/DMSS/CRUD/Asignatura/indice.php">Asignatura</a></li>
		
							<li role="presentation" ><a href="http://localhost/DMSS/CRUD/Profesor/indice.php">Profesor</a></li>
		
							<li role="presentation"  class="active" ><a href="http://localhost/DMSS/CRUD/Centro de estudios/indice.php">Centro de estudios</a></li>
		
		</ul>	
		<div class="panel panel-default">
		  <table class="table">
		<tr class="info">
			<th>Nombre</th><th>Ver</th><th>Editar</th><th>Borrar</th></tr>
		
		<?php
		      $sql_query="SELECT id, nombre FROM ".str_replace(" ", "_", "Centro de estudios");
		 $result_set=mysql_query($sql_query);
		 while($row=mysql_fetch_assoc($result_set))
		 {
		 ?>
	        <tr>
				<td><?php echo $row['nombre']; ?></td>				
		        <td>
					
					<a href="http://localhost/DMSS/CRUD/Centro de estudios/read.php?id=<?php echo $row['id']; ?>"><button type="button" class="btn btn-default" aria-label="Left Align"><span class="glyphicon glyphicon-zoom-in" aria-hidden="true"></span></button></a>
				</td>
				<td>
					
					<a href="http://localhost/DMSS/CRUD/Centro de estudios/update.php?id=<?php echo $row['id']; ?>"><button type="button" class="btn btn-default" aria-label="Left Align"><span class="glyphicon glyphicon glyphicon-pencil" aria-hidden="true"></span></button></a>
				</td>
		        <td>
					
					<a href="http://localhost/DMSS/CRUD/Centro de estudios/delete.php?id=<?php echo $row['id']; ?>"><button type="button" class="btn btn-default" aria-label="Left Align"><span class="glyphicon glyphicon glyphicon-remove" aria-hidden="true"></span></button></a>
				</td>

		 	</tr>
		        <?php
		 }
		      ?>
		  </table>	   
		<a href="http://localhost/DMSS/CRUD/Centro de estudios/create.php"><button class="btn btn-primary btn-lg">Nuevo</button></a>  
		</div>
		<!-- Latest compiled and minified JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
		<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
		</body>
		</html>
