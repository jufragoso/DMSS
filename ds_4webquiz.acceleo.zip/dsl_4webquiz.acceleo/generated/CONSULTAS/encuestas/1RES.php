		<?php
			include_once '../dbconfig.php';
?>
		<!DOCTYPE html>
	<html>
	    <head>
	        <meta charset="utf-8" />
	        <title>prueba4</title>
	    </head>
	    <body>
	        <div class="jumbotron">
	            <h1>prueba4</h1>
	            <p>Proyecto DMSS</p>
	        </div>
	            <ul class="nav nav-tabs">
	            <li role="presentation" ><a href="http://localhost/DMSS/index.html">Entidades</a></li>
	            <li role="presentation" ><a href="http://localhost/DMSS/lEncuestas.php">Encuestas</a></li>
				<li role="presentation" class="active"><a href="http://localhost/DMSS/lCuestionarios.php">Cuestionarios</a></li>
	            </ul>
        <div class="panel panel-default">
		<p><h1>Encuesta de prueba 2</h1></p>
	<form method="POST">
		<fieldset class="form-group">
<?php
		$sql_query="SELECT * FROM encuestas";
		 $result_set=mysql_query($sql_query);
		$vecesHecha = mysql_fetch_assoc($result_set)["selecciones"];
		$idCuestionario=0;
		$sql_query="SELECT * FROM pregunta where idCuestionario =1";
		 $result_set=mysql_query($sql_query);
		while($row=mysql_fetch_assoc($result_set))
		{
				$rowOpc;
				echo "<div class='alert alert-danger' role='alert'>".$row["enunciado"]."</div>"; 
				$sql_query="SELECT * FROM opcionE where idPregunta =".$row['idPregunta'];
				 $result_opc=mysql_query($sql_query);
				while($rowOpc=mysql_fetch_assoc($result_opc))
				{ ?>
					<p class="form-control-static"><?php echo $rowOpc["enunciado"]; ?>
					<div class="progress">
  <div class="progress-bar" role="progressbar" aria-valuenow="<?php echo floor(($rowOpc["selecciones"]/$vecesHecha)*100); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo floor(($rowOpc["selecciones"]/$vecesHecha)*100); ?>%;">
    <?php echo floor(($rowOpc["selecciones"]/$vecesHecha)*100); ?>%
  </div>
</div></p>
<?php
				}
		}
?>
	</fieldset>
	
	</form>
	</div>
</body>
    <!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
</html>	
