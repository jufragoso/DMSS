<?php
$conexion= mysql_connect("localhost","root","");
if (!$conexion) {
    die('No pudo conectarse: ' . mysql_error());
}
//// Creamos la Base de datos
$sql = "CREATE DATABASE prueba4";
if (mysql_query($sql, $conexion)) {
    echo "La base de datos se ha creado correctamente\n";
	
	if (mysql_select_db("prueba4", $conexion)) {
    echo "Se ha seleccionado la bbdd correctamente\n";
} else {
    echo "Error al seleccionar la  base de datos:". mysql_error()."\n";
}
}
//// Creamos la tabla
$sql="CREATE TABLE ".str_replace(" ", "_", "Asignatura")." (
	id int(11) NOT NULL AUTO_INCREMENT,
	creditos int(11),
	nombre varchar(11),
	responsable varchar(11),
PRIMARY KEY (id));";

if (mysql_query($sql, $conexion)) {
    echo "La tabla se ha creado correctamente\n";
} else {
    echo "Error al crear la tabla:". mysql_error()."\n";
}
$sql="CREATE TABLE ".str_replace(" ", "_", "Profesor")." (
	id int(11) NOT NULL AUTO_INCREMENT,
	nombre varchar(11),
	salario int(11),
PRIMARY KEY (id));";

if (mysql_query($sql, $conexion)) {
    echo "La tabla se ha creado correctamente\n";
} else {
    echo "Error al crear la tabla:". mysql_error()."\n";
}
$sql="CREATE TABLE ".str_replace(" ", "_", "Centro de estudios")." (
	id int(11) NOT NULL AUTO_INCREMENT,
	nombre varchar(11),
PRIMARY KEY (id));";

if (mysql_query($sql, $conexion)) {
    echo "La tabla se ha creado correctamente\n";
} else {
    echo "Error al crear la tabla:". mysql_error()."\n";
}

///tabla para almacenar los cuestionarios
$sql="CREATE TABLE cuestionarios(
	id int(11) NOT NULL AUTO_INCREMENT,
	nombre varchar(100),
	PRIMARY KEY (id))";
  if (mysql_query($sql, $conexion)) {
      echo "La tabla se ha creado correctamente\n";
  } else {
      echo "Error al crear la tabla:". mysql_error()."\n";
  }

$sql="CREATE TABLE encuestas(
	id int(11) NOT NULL AUTO_INCREMENT,
	nombre varchar(100),
	selecciones int(11) DEFAULT 0,
	PRIMARY KEY (id))";
  if (mysql_query($sql, $conexion)) {
      echo "La tabla se ha creado correctamente\n";
  } else {
      echo "Error al crear la tabla:". mysql_error()."\n";
  }



$sql = "CREATE TABLE pregunta(
idCuestionario int(11),
idPregunta int(11) NOT NULL AUTO_INCREMENT,
tipo int(2),
enunciado varchar(500),
PRIMARY KEY (idPregunta))";
if (mysql_query($sql, $conexion)) {
      echo "La tabla se ha creado correctamente\n";
  } else {
      echo "Error al crear la tabla:". mysql_error()."\n";
  }

$sql = "CREATE TABLE opcionE(
idCuestionario int(11),
idPregunta int(11),
idOpcion int(11) NOT NULL AUTO_INCREMENT,
selecciones int(11) DEFAULT 0,
enunciado varchar(500),
PRIMARY KEY (idOpcion))";
if (mysql_query($sql, $conexion)) {
      echo "La tabla se ha creado correctamente\n";
  } else {
      echo "Error al crear la tabla:". mysql_error()."\n";
  }


$sql="INSERT INTO cuestionarios (NOMBRE) VALUES ('".str_replace(" ", "_", "Cuestionario 1")."'); ";
if (mysql_query($sql, $conexion)) {
    echo "La tabla se ha creado correctamente\n";
} else {
    echo "Error al crear la tabla:". mysql_error()."\n";
}

$sql="INSERT INTO encuestas (id, NOMBRE) VALUES (1, '".str_replace(" ", "_", "Encuesta de prueba 2")."'); ";
if (mysql_query($sql, $conexion)) {
    echo "La tabla se ha creado correctamente\n";
} else {
    echo "Error al crear la tabla:". mysql_error()."\n";
}
$idCuestionario = 1;
	$sql="INSERT INTO pregunta (idCuestionario, tipo, enunciado) VALUES (".$idCuestionario.", 1, 'pregunta falsa'); ";
	if (mysql_query($sql, $conexion)) {
	    echo "La tabla se ha creado correctamente\n";
	} else {
	    echo "Error al crear la tabla:". mysql_error()."\n";
	}
	$idPregunta=0;
	$sql = "SELECT MAX(idPregunta) as id from pregunta";
	$result=mysql_query($sql);
	$fil = mysql_fetch_assoc($result);
	$idPregunta = $fil["id"];
	$sql="INSERT INTO opcionE (idCuestionario, idPregunta, selecciones, enunciado) VALUES (".$idCuestionario.", ".$idPregunta.", 0, 'Verdadero'); ";
	if (mysql_query($sql, $conexion)) {
	    echo "La tabla se ha creado correctamente\n";
	} else {
	    echo "Error al crear la tabla:". mysql_error()."\n";
	}
	$sql="INSERT INTO opcionE (idCuestionario, idPregunta, selecciones, enunciado) VALUES (".$idCuestionario.", ".$idPregunta.", 0, 'Falso'); ";
	if (mysql_query($sql, $conexion)) {
	    echo "La tabla se ha creado correctamente\n";
	} else {
	    echo "Error al crear la tabla:". mysql_error()."\n";
	}
	$sql="INSERT INTO pregunta (idCuestionario, tipo, enunciado) VALUES (".$idCuestionario.", 2, 'Seleccion 1'); ";
	$idPregunta=0;
	if (mysql_query($sql, $conexion)) {
	    echo "La tabla se ha creado correctamente\n";
	} else {
	    echo "Error al crear la tabla:". mysql_error()."\n";
	}
	$sql = "SELECT MAX(idPregunta) as id from pregunta";
	$result=mysql_query($sql);
	$fil = mysql_fetch_assoc($result);
	$idPregunta = $fil["id"];
	$sql="INSERT INTO opcionE (idCuestionario, idPregunta, selecciones, enunciado) VALUES (".$idCuestionario.", ".$idPregunta.", 0, 'Opcion a'); ";
	if (mysql_query($sql, $conexion)) {
	    echo "La tabla se ha creado correctamente\n";
	} else {
	    echo "Error al crear la tabla:". mysql_error()."\n";
	}
	$sql="INSERT INTO opcionE (idCuestionario, idPregunta, selecciones, enunciado) VALUES (".$idCuestionario.", ".$idPregunta.", 0, 'Opcion b'); ";
	if (mysql_query($sql, $conexion)) {
	    echo "La tabla se ha creado correctamente\n";
	} else {
	    echo "Error al crear la tabla:". mysql_error()."\n";
	}
?>
