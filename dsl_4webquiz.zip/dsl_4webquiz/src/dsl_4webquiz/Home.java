/**
 */
package dsl_4webquiz;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Home</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dsl_4webquiz.Home#getCrud <em>Crud</em>}</li>
 *   <li>{@link dsl_4webquiz.Home#getConsulta <em>Consulta</em>}</li>
 * </ul>
 *
 * @see dsl_4webquiz.Dsl_4webquizPackage#getHome()
 * @model annotation="gmf.node label='titulo' border.color='132,132,132' border.width='3' color='208,255,251' resizable='true' border.stype='solid'"
 * @generated
 */
public interface Home extends Pagina {
	/**
	 * Returns the value of the '<em><b>Crud</b></em>' reference list.
	 * The list contents are of type {@link dsl_4webquiz.PAGINAS_CRUD}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Crud</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Crud</em>' reference list.
	 * @see dsl_4webquiz.Dsl_4webquizPackage#getHome_Crud()
	 * @model annotation="gmf.link source='Home' target='crud' width='3' source.decoration='arrow' target.decoration='arrow' style='dot' Incoming='true'"
	 * @generated
	 */
	EList<PAGINAS_CRUD> getCrud();

	/**
	 * Returns the value of the '<em><b>Consulta</b></em>' reference list.
	 * The list contents are of type {@link dsl_4webquiz.Consulta}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Consulta</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Consulta</em>' reference list.
	 * @see dsl_4webquiz.Dsl_4webquizPackage#getHome_Consulta()
	 * @model annotation="gmf.link source='Home' target='consulta' width='3' source.decoration='arrow' target.decoration='arrow' style='dot' Incoming='true'"
	 * @generated
	 */
	EList<Consulta> getConsulta();

} // Home
