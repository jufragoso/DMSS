/**
 */
package dsl_4webquiz;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Opcion</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dsl_4webquiz.Opcion#getTituloPregunta <em>Titulo Pregunta</em>}</li>
 * </ul>
 *
 * @see dsl_4webquiz.Dsl_4webquizPackage#getOpcion()
 * @model annotation="gmf.node label='tituloPregunta' border.color='132,132,132' border.width='3' color='255,182,183' resizable='true' border.stype='solid'"
 * @generated
 */
public interface Opcion extends EObject {
	/**
	 * Returns the value of the '<em><b>Titulo Pregunta</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Titulo Pregunta</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Titulo Pregunta</em>' attribute.
	 * @see #setTituloPregunta(String)
	 * @see dsl_4webquiz.Dsl_4webquizPackage#getOpcion_TituloPregunta()
	 * @model
	 * @generated
	 */
	String getTituloPregunta();

	/**
	 * Sets the value of the '{@link dsl_4webquiz.Opcion#getTituloPregunta <em>Titulo Pregunta</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Titulo Pregunta</em>' attribute.
	 * @see #getTituloPregunta()
	 * @generated
	 */
	void setTituloPregunta(String value);

} // Opcion
