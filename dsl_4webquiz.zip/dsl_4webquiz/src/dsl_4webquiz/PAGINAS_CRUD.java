/**
 */
package dsl_4webquiz;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>PAGINAS CRUD</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dsl_4webquiz.PAGINAS_CRUD#getHome <em>Home</em>}</li>
 *   <li>{@link dsl_4webquiz.PAGINAS_CRUD#getTipodatos <em>Tipodatos</em>}</li>
 * </ul>
 *
 * @see dsl_4webquiz.Dsl_4webquizPackage#getPAGINAS_CRUD()
 * @model abstract="true"
 * @generated
 */
public interface PAGINAS_CRUD extends Pagina {
	/**
	 * Returns the value of the '<em><b>Home</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Home</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Home</em>' reference.
	 * @see #setHome(Home)
	 * @see dsl_4webquiz.Dsl_4webquizPackage#getPAGINAS_CRUD_Home()
	 * @model annotation="gmf.link source='Indice' target='home' width='3' source.decoration='arrow' target.decoration='arrow' Incoming='true'"
	 *        annotation="gmf.link source='Detalle' target='home' width='3' source.decoration='arrow' target.decoration='arrow' Incoming='true'"
	 *        annotation="gmf.link source='Creacion' target='home' width='3' source.decoration='arrow' target.decoration='arrow' Incoming='true'"
	 *        annotation="gmf.link source='Borrado' target='home' width='3' source.decoration='arrow' target.decoration='arrow' Incoming='true'"
	 * @generated
	 */
	Home getHome();

	/**
	 * Sets the value of the '{@link dsl_4webquiz.PAGINAS_CRUD#getHome <em>Home</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Home</em>' reference.
	 * @see #getHome()
	 * @generated
	 */
	void setHome(Home value);

	/**
	 * Returns the value of the '<em><b>Tipodatos</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Tipodatos</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Tipodatos</em>' reference.
	 * @see #setTipodatos(TipoDatos)
	 * @see dsl_4webquiz.Dsl_4webquizPackage#getPAGINAS_CRUD_Tipodatos()
	 * @model required="true"
	 *        annotation="gmf.link source='PAGINAS_CRUD' target='tipodatos' width='3' source.decoration='arrow' target.decoration='arrow' Incoming='true'"
	 * @generated
	 */
	TipoDatos getTipodatos();

	/**
	 * Sets the value of the '{@link dsl_4webquiz.PAGINAS_CRUD#getTipodatos <em>Tipodatos</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Tipodatos</em>' reference.
	 * @see #getTipodatos()
	 * @generated
	 */
	void setTipodatos(TipoDatos value);

} // PAGINAS_CRUD
