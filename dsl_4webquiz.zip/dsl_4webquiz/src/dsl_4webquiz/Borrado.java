/**
 */
package dsl_4webquiz;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Borrado</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see dsl_4webquiz.Dsl_4webquizPackage#getBorrado()
 * @model annotation="gmf.node label='titulo' border.color='132,132,132' border.width='3' color='208,255,251' resizable='true' border.stype='solid'"
 * @generated
 */
public interface Borrado extends PAGINAS_CRUD {
} // Borrado
