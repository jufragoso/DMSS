/**
 */
package dsl_4webquiz;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Web</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dsl_4webquiz.Web#getUsuario <em>Usuario</em>}</li>
 *   <li>{@link dsl_4webquiz.Web#getPagina <em>Pagina</em>}</li>
 *   <li>{@link dsl_4webquiz.Web#getRedes_sociales <em>Redes sociales</em>}</li>
 *   <li>{@link dsl_4webquiz.Web#getEntidad <em>Entidad</em>}</li>
 *   <li>{@link dsl_4webquiz.Web#getNombre <em>Nombre</em>}</li>
 *   <li>{@link dsl_4webquiz.Web#getUrl <em>Url</em>}</li>
 * </ul>
 *
 * @see dsl_4webquiz.Dsl_4webquizPackage#getWeb()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='num_Home num_RedesSociales num_Encuestas num_Cuestionarios includesCrud includesConsulta CRUD_Unico Indice_Update Indice_Creacion Indice_Borrado Indice_Detalle'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot num_Home='self.pagina->selectByType(Home)->size() =1' num_RedesSociales='self.redes_sociales->size()>0' num_Encuestas='self.pagina->selectByKind(Consulta)->selectByType(Encuesta)->size()>0' num_Cuestionarios='self.pagina->selectByKind(Consulta)->selectByType(Cuestionario)->size()>0' includesCrud='self.pagina->selectByKind(Home).crud->includesAll(self.pagina->selectByKind(PAGINAS_CRUD))' includesConsulta='self.pagina->selectByKind(Home).consulta->includesAll(self.pagina->selectByKind(Consulta))' CRUD_Unico='self.pagina->selectByKind(CRUD).tipodatos->asSet()->excludesAll(self.pagina->selectByKind(Indice).tipodatos->union(self.pagina->selectByKind(Creacion).tipodatos)->union(self.pagina->selectByKind(Detalle).tipodatos)->union(self.pagina->selectByKind(Borrado).tipodatos)->asSet())' Indice_Update='self.pagina->exists(self.pagina->selectByKind(Update).tipodatos=self.pagina->selectByKind(Indice).tipodatos)' Indice_Creacion='self.pagina->exists(self.pagina->selectByKind(Creacion).tipodatos=self.pagina->selectByKind(Indice).tipodatos)' Indice_Borrado='self.pagina->exists(self.pagina->selectByKind(Borrado).tipodatos=self.pagina->selectByKind(Indice).tipodatos)' Indice_Detalle='self.pagina->exists(self.pagina->selectByKind(Detalle).tipodatos=self.pagina->selectByKind(Indice).tipodatos)'"
 *        annotation="gmf.diagram diagram.extension='dsl'"
 * @generated
 */
public interface Web extends EObject {
	/**
	 * Returns the value of the '<em><b>Usuario</b></em>' containment reference list.
	 * The list contents are of type {@link dsl_4webquiz.Usuario}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Usuario</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Usuario</em>' containment reference list.
	 * @see dsl_4webquiz.Dsl_4webquizPackage#getWeb_Usuario()
	 * @model containment="true"
	 * @generated
	 */
	EList<Usuario> getUsuario();

	/**
	 * Returns the value of the '<em><b>Pagina</b></em>' containment reference list.
	 * The list contents are of type {@link dsl_4webquiz.Pagina}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Pagina</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pagina</em>' containment reference list.
	 * @see dsl_4webquiz.Dsl_4webquizPackage#getWeb_Pagina()
	 * @model containment="true"
	 * @generated
	 */
	EList<Pagina> getPagina();

	/**
	 * Returns the value of the '<em><b>Redes sociales</b></em>' containment reference list.
	 * The list contents are of type {@link dsl_4webquiz.Redes_Sociales}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Redes sociales</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Redes sociales</em>' containment reference list.
	 * @see dsl_4webquiz.Dsl_4webquizPackage#getWeb_Redes_sociales()
	 * @model containment="true"
	 * @generated
	 */
	EList<Redes_Sociales> getRedes_sociales();

	/**
	 * Returns the value of the '<em><b>Entidad</b></em>' containment reference list.
	 * The list contents are of type {@link dsl_4webquiz.TipoDatos}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Entidad</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Entidad</em>' containment reference list.
	 * @see dsl_4webquiz.Dsl_4webquizPackage#getWeb_Entidad()
	 * @model containment="true"
	 * @generated
	 */
	EList<TipoDatos> getEntidad();

	/**
	 * Returns the value of the '<em><b>Nombre</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Nombre</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Nombre</em>' attribute.
	 * @see #setNombre(String)
	 * @see dsl_4webquiz.Dsl_4webquizPackage#getWeb_Nombre()
	 * @model
	 * @generated
	 */
	String getNombre();

	/**
	 * Sets the value of the '{@link dsl_4webquiz.Web#getNombre <em>Nombre</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Nombre</em>' attribute.
	 * @see #getNombre()
	 * @generated
	 */
	void setNombre(String value);

	/**
	 * Returns the value of the '<em><b>Url</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Url</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Url</em>' attribute.
	 * @see #setUrl(String)
	 * @see dsl_4webquiz.Dsl_4webquizPackage#getWeb_Url()
	 * @model
	 * @generated
	 */
	String getUrl();

	/**
	 * Sets the value of the '{@link dsl_4webquiz.Web#getUrl <em>Url</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Url</em>' attribute.
	 * @see #getUrl()
	 * @generated
	 */
	void setUrl(String value);

} // Web
