/**
 */
package dsl_4webquiz;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Consulta</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dsl_4webquiz.Consulta#getHome <em>Home</em>}</li>
 * </ul>
 *
 * @see dsl_4webquiz.Dsl_4webquizPackage#getConsulta()
 * @model abstract="true"
 * @generated
 */
public interface Consulta extends Pagina {
	/**
	 * Returns the value of the '<em><b>Home</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Home</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Home</em>' reference.
	 * @see #setHome(Home)
	 * @see dsl_4webquiz.Dsl_4webquizPackage#getConsulta_Home()
	 * @model annotation="gmf.link source='Consulta' target='home' width='3' source.decoration='arrow' target.decoration='arrow' Incoming='true'"
	 * @generated
	 */
	Home getHome();

	/**
	 * Sets the value of the '{@link dsl_4webquiz.Consulta#getHome <em>Home</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Home</em>' reference.
	 * @see #getHome()
	 * @generated
	 */
	void setHome(Home value);

} // Consulta
