/**
 */
package dsl_4webquiz;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Atributo</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dsl_4webquiz.Atributo#getTipo <em>Tipo</em>}</li>
 *   <li>{@link dsl_4webquiz.Atributo#getNombre <em>Nombre</em>}</li>
 * </ul>
 *
 * @see dsl_4webquiz.Dsl_4webquizPackage#getAtributo()
 * @model annotation="gmf.node label='nombre' border.color='132,132,132' border.width='3' color='255,247,180' resizable='true' border.stype='solid'"
 * @generated
 */
public interface Atributo extends EObject {
	/**
	 * Returns the value of the '<em><b>Tipo</b></em>' attribute.
	 * The literals are from the enumeration {@link dsl_4webquiz.TipoAtributos}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Tipo</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Tipo</em>' attribute.
	 * @see dsl_4webquiz.TipoAtributos
	 * @see #setTipo(TipoAtributos)
	 * @see dsl_4webquiz.Dsl_4webquizPackage#getAtributo_Tipo()
	 * @model
	 * @generated
	 */
	TipoAtributos getTipo();

	/**
	 * Sets the value of the '{@link dsl_4webquiz.Atributo#getTipo <em>Tipo</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Tipo</em>' attribute.
	 * @see dsl_4webquiz.TipoAtributos
	 * @see #getTipo()
	 * @generated
	 */
	void setTipo(TipoAtributos value);

	/**
	 * Returns the value of the '<em><b>Nombre</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Nombre</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Nombre</em>' attribute.
	 * @see #setNombre(String)
	 * @see dsl_4webquiz.Dsl_4webquizPackage#getAtributo_Nombre()
	 * @model
	 * @generated
	 */
	String getNombre();

	/**
	 * Sets the value of the '{@link dsl_4webquiz.Atributo#getNombre <em>Nombre</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Nombre</em>' attribute.
	 * @see #getNombre()
	 * @generated
	 */
	void setNombre(String value);

} // Atributo
