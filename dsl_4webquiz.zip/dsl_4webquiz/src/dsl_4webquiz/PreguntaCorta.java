/**
 */
package dsl_4webquiz;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pregunta Corta</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dsl_4webquiz.PreguntaCorta#getRespuesta <em>Respuesta</em>}</li>
 * </ul>
 *
 * @see dsl_4webquiz.Dsl_4webquizPackage#getPreguntaCorta()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='respuesta_definida'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot respuesta_definida='not self.respuesta->isEmpty()'"
 *        annotation="gmf.node label='tituloPregunta' border.color='132,132,132' border.width='3' color='166,255,185' resizable='true' border.stype='solid'"
 * @generated
 */
public interface PreguntaCorta extends Pregunta {
	/**
	 * Returns the value of the '<em><b>Respuesta</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Respuesta</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Respuesta</em>' attribute.
	 * @see #setRespuesta(String)
	 * @see dsl_4webquiz.Dsl_4webquizPackage#getPreguntaCorta_Respuesta()
	 * @model
	 * @generated
	 */
	String getRespuesta();

	/**
	 * Sets the value of the '{@link dsl_4webquiz.PreguntaCorta#getRespuesta <em>Respuesta</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Respuesta</em>' attribute.
	 * @see #getRespuesta()
	 * @generated
	 */
	void setRespuesta(String value);

} // PreguntaCorta
