/**
 */
package dsl_4webquiz;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Seleccion</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dsl_4webquiz.Seleccion#getOpcion <em>Opcion</em>}</li>
 *   <li>{@link dsl_4webquiz.Seleccion#getCorrecta <em>Correcta</em>}</li>
 * </ul>
 *
 * @see dsl_4webquiz.Dsl_4webquizPackage#getSeleccion()
 * @model annotation="gmf.node label='tituloPregunta' border.color='132,132,132' border.width='3' color='255,247,180' resizable='true' border.stype='solid'"
 * @generated
 */
public interface Seleccion extends Pregunta {
	/**
	 * Returns the value of the '<em><b>Opcion</b></em>' containment reference list.
	 * The list contents are of type {@link dsl_4webquiz.Opcion}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Opcion</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Opcion</em>' containment reference list.
	 * @see dsl_4webquiz.Dsl_4webquizPackage#getSeleccion_Opcion()
	 * @model containment="true"
	 *        annotation="gmf.compartment layout='free'"
	 * @generated
	 */
	EList<Opcion> getOpcion();

	/**
	 * Returns the value of the '<em><b>Correcta</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Correcta</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Correcta</em>' reference.
	 * @see #setCorrecta(Opcion)
	 * @see dsl_4webquiz.Dsl_4webquizPackage#getSeleccion_Correcta()
	 * @model required="true"
	 * @generated
	 */
	Opcion getCorrecta();

	/**
	 * Sets the value of the '{@link dsl_4webquiz.Seleccion#getCorrecta <em>Correcta</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Correcta</em>' reference.
	 * @see #getCorrecta()
	 * @generated
	 */
	void setCorrecta(Opcion value);

} // Seleccion
