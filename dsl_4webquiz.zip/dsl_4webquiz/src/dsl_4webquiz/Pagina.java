/**
 */
package dsl_4webquiz;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pagina</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dsl_4webquiz.Pagina#getTitulo <em>Titulo</em>}</li>
 *   <li>{@link dsl_4webquiz.Pagina#getUrl <em>Url</em>}</li>
 *   <li>{@link dsl_4webquiz.Pagina#getRedes_sociales <em>Redes sociales</em>}</li>
 * </ul>
 *
 * @see dsl_4webquiz.Dsl_4webquizPackage#getPagina()
 * @model abstract="true"
 * @generated
 */
public interface Pagina extends EObject {
	/**
	 * Returns the value of the '<em><b>Titulo</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Titulo</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Titulo</em>' attribute.
	 * @see #setTitulo(String)
	 * @see dsl_4webquiz.Dsl_4webquizPackage#getPagina_Titulo()
	 * @model
	 * @generated
	 */
	String getTitulo();

	/**
	 * Sets the value of the '{@link dsl_4webquiz.Pagina#getTitulo <em>Titulo</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Titulo</em>' attribute.
	 * @see #getTitulo()
	 * @generated
	 */
	void setTitulo(String value);

	/**
	 * Returns the value of the '<em><b>Url</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Url</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Url</em>' attribute.
	 * @see #setUrl(String)
	 * @see dsl_4webquiz.Dsl_4webquizPackage#getPagina_Url()
	 * @model
	 * @generated
	 */
	String getUrl();

	/**
	 * Sets the value of the '{@link dsl_4webquiz.Pagina#getUrl <em>Url</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Url</em>' attribute.
	 * @see #getUrl()
	 * @generated
	 */
	void setUrl(String value);

	/**
	 * Returns the value of the '<em><b>Redes sociales</b></em>' reference list.
	 * The list contents are of type {@link dsl_4webquiz.Redes_Sociales}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Redes sociales</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Redes sociales</em>' reference list.
	 * @see dsl_4webquiz.Dsl_4webquizPackage#getPagina_Redes_sociales()
	 * @model annotation="gmf.link label='rs' source='Pagina' target='redes_sociales' width='3' source.decoration='arrow' target.decoration='arrow' incoming='true'"
	 * @generated
	 */
	EList<Redes_Sociales> getRedes_sociales();

} // Pagina
