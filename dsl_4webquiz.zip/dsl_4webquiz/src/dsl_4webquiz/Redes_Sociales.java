/**
 */
package dsl_4webquiz;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Redes Sociales</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dsl_4webquiz.Redes_Sociales#getEnlace <em>Enlace</em>}</li>
 *   <li>{@link dsl_4webquiz.Redes_Sociales#getPagina <em>Pagina</em>}</li>
 * </ul>
 *
 * @see dsl_4webquiz.Dsl_4webquizPackage#getRedes_Sociales()
 * @model abstract="true"
 * @generated
 */
public interface Redes_Sociales extends EObject {
	/**
	 * Returns the value of the '<em><b>Enlace</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Enlace</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Enlace</em>' attribute.
	 * @see #setEnlace(String)
	 * @see dsl_4webquiz.Dsl_4webquizPackage#getRedes_Sociales_Enlace()
	 * @model
	 * @generated
	 */
	String getEnlace();

	/**
	 * Sets the value of the '{@link dsl_4webquiz.Redes_Sociales#getEnlace <em>Enlace</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Enlace</em>' attribute.
	 * @see #getEnlace()
	 * @generated
	 */
	void setEnlace(String value);

	/**
	 * Returns the value of the '<em><b>Pagina</b></em>' reference list.
	 * The list contents are of type {@link dsl_4webquiz.Pagina}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Pagina</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pagina</em>' reference list.
	 * @see dsl_4webquiz.Dsl_4webquizPackage#getRedes_Sociales_Pagina()
	 * @model
	 * @generated
	 */
	EList<Pagina> getPagina();

} // Redes_Sociales
