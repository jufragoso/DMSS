/**
 */
package dsl_4webquiz;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pregunta</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dsl_4webquiz.Pregunta#getTituloPregunta <em>Titulo Pregunta</em>}</li>
 * </ul>
 *
 * @see dsl_4webquiz.Dsl_4webquizPackage#getPregunta()
 * @model abstract="true"
 * @generated
 */
public interface Pregunta extends EObject {
	/**
	 * Returns the value of the '<em><b>Titulo Pregunta</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Titulo Pregunta</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Titulo Pregunta</em>' attribute.
	 * @see #setTituloPregunta(String)
	 * @see dsl_4webquiz.Dsl_4webquizPackage#getPregunta_TituloPregunta()
	 * @model
	 * @generated
	 */
	String getTituloPregunta();

	/**
	 * Sets the value of the '{@link dsl_4webquiz.Pregunta#getTituloPregunta <em>Titulo Pregunta</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Titulo Pregunta</em>' attribute.
	 * @see #getTituloPregunta()
	 * @generated
	 */
	void setTituloPregunta(String value);

} // Pregunta
