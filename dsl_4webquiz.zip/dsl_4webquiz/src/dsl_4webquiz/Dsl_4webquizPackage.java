/**
 */
package dsl_4webquiz;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see dsl_4webquiz.Dsl_4webquizFactory
 * @model kind="package"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore invocationDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot' settingDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot' validationDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot'"
 * @generated
 */
public interface Dsl_4webquizPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "dsl_4webquiz";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/dsl_4webquiz";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "dsl_4webquiz";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	Dsl_4webquizPackage eINSTANCE = dsl_4webquiz.impl.Dsl_4webquizPackageImpl.init();

	/**
	 * The meta object id for the '{@link dsl_4webquiz.impl.WebImpl <em>Web</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dsl_4webquiz.impl.WebImpl
	 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getWeb()
	 * @generated
	 */
	int WEB = 0;

	/**
	 * The feature id for the '<em><b>Usuario</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEB__USUARIO = 0;

	/**
	 * The feature id for the '<em><b>Pagina</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEB__PAGINA = 1;

	/**
	 * The feature id for the '<em><b>Redes sociales</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEB__REDES_SOCIALES = 2;

	/**
	 * The feature id for the '<em><b>Entidad</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEB__ENTIDAD = 3;

	/**
	 * The feature id for the '<em><b>Nombre</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEB__NOMBRE = 4;

	/**
	 * The feature id for the '<em><b>Url</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEB__URL = 5;

	/**
	 * The number of structural features of the '<em>Web</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WEB_FEATURE_COUNT = 6;

	/**
	 * The meta object id for the '{@link dsl_4webquiz.impl.PaginaImpl <em>Pagina</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dsl_4webquiz.impl.PaginaImpl
	 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getPagina()
	 * @generated
	 */
	int PAGINA = 1;

	/**
	 * The feature id for the '<em><b>Titulo</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGINA__TITULO = 0;

	/**
	 * The feature id for the '<em><b>Url</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGINA__URL = 1;

	/**
	 * The feature id for the '<em><b>Redes sociales</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGINA__REDES_SOCIALES = 2;

	/**
	 * The number of structural features of the '<em>Pagina</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGINA_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link dsl_4webquiz.impl.Redes_SocialesImpl <em>Redes Sociales</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dsl_4webquiz.impl.Redes_SocialesImpl
	 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getRedes_Sociales()
	 * @generated
	 */
	int REDES_SOCIALES = 2;

	/**
	 * The feature id for the '<em><b>Enlace</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REDES_SOCIALES__ENLACE = 0;

	/**
	 * The feature id for the '<em><b>Pagina</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REDES_SOCIALES__PAGINA = 1;

	/**
	 * The number of structural features of the '<em>Redes Sociales</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REDES_SOCIALES_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link dsl_4webquiz.impl.UsuarioImpl <em>Usuario</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dsl_4webquiz.impl.UsuarioImpl
	 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getUsuario()
	 * @generated
	 */
	int USUARIO = 3;

	/**
	 * The feature id for the '<em><b>Usuario</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USUARIO__USUARIO = 0;

	/**
	 * The feature id for the '<em><b>Password</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USUARIO__PASSWORD = 1;

	/**
	 * The number of structural features of the '<em>Usuario</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int USUARIO_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link dsl_4webquiz.impl.TwitterImpl <em>Twitter</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dsl_4webquiz.impl.TwitterImpl
	 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getTwitter()
	 * @generated
	 */
	int TWITTER = 4;

	/**
	 * The feature id for the '<em><b>Enlace</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TWITTER__ENLACE = REDES_SOCIALES__ENLACE;

	/**
	 * The feature id for the '<em><b>Pagina</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TWITTER__PAGINA = REDES_SOCIALES__PAGINA;

	/**
	 * The number of structural features of the '<em>Twitter</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TWITTER_FEATURE_COUNT = REDES_SOCIALES_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link dsl_4webquiz.impl.Google_plusImpl <em>Google plus</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dsl_4webquiz.impl.Google_plusImpl
	 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getGoogle_plus()
	 * @generated
	 */
	int GOOGLE_PLUS = 5;

	/**
	 * The feature id for the '<em><b>Enlace</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOOGLE_PLUS__ENLACE = REDES_SOCIALES__ENLACE;

	/**
	 * The feature id for the '<em><b>Pagina</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOOGLE_PLUS__PAGINA = REDES_SOCIALES__PAGINA;

	/**
	 * The number of structural features of the '<em>Google plus</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GOOGLE_PLUS_FEATURE_COUNT = REDES_SOCIALES_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link dsl_4webquiz.impl.RSSImpl <em>RSS</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dsl_4webquiz.impl.RSSImpl
	 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getRSS()
	 * @generated
	 */
	int RSS = 6;

	/**
	 * The feature id for the '<em><b>Enlace</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RSS__ENLACE = REDES_SOCIALES__ENLACE;

	/**
	 * The feature id for the '<em><b>Pagina</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RSS__PAGINA = REDES_SOCIALES__PAGINA;

	/**
	 * The number of structural features of the '<em>RSS</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RSS_FEATURE_COUNT = REDES_SOCIALES_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link dsl_4webquiz.impl.PAGINAS_CRUDImpl <em>PAGINAS CRUD</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dsl_4webquiz.impl.PAGINAS_CRUDImpl
	 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getPAGINAS_CRUD()
	 * @generated
	 */
	int PAGINAS_CRUD = 7;

	/**
	 * The feature id for the '<em><b>Titulo</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGINAS_CRUD__TITULO = PAGINA__TITULO;

	/**
	 * The feature id for the '<em><b>Url</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGINAS_CRUD__URL = PAGINA__URL;

	/**
	 * The feature id for the '<em><b>Redes sociales</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGINAS_CRUD__REDES_SOCIALES = PAGINA__REDES_SOCIALES;

	/**
	 * The feature id for the '<em><b>Home</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGINAS_CRUD__HOME = PAGINA_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Tipodatos</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGINAS_CRUD__TIPODATOS = PAGINA_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>PAGINAS CRUD</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGINAS_CRUD_FEATURE_COUNT = PAGINA_FEATURE_COUNT + 2;

	/**
	 * The meta object id for the '{@link dsl_4webquiz.impl.IndiceImpl <em>Indice</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dsl_4webquiz.impl.IndiceImpl
	 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getIndice()
	 * @generated
	 */
	int INDICE = 8;

	/**
	 * The feature id for the '<em><b>Titulo</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INDICE__TITULO = PAGINAS_CRUD__TITULO;

	/**
	 * The feature id for the '<em><b>Url</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INDICE__URL = PAGINAS_CRUD__URL;

	/**
	 * The feature id for the '<em><b>Redes sociales</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INDICE__REDES_SOCIALES = PAGINAS_CRUD__REDES_SOCIALES;

	/**
	 * The feature id for the '<em><b>Home</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INDICE__HOME = PAGINAS_CRUD__HOME;

	/**
	 * The feature id for the '<em><b>Tipodatos</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INDICE__TIPODATOS = PAGINAS_CRUD__TIPODATOS;

	/**
	 * The number of structural features of the '<em>Indice</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INDICE_FEATURE_COUNT = PAGINAS_CRUD_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link dsl_4webquiz.impl.DetalleImpl <em>Detalle</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dsl_4webquiz.impl.DetalleImpl
	 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getDetalle()
	 * @generated
	 */
	int DETALLE = 9;

	/**
	 * The feature id for the '<em><b>Titulo</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DETALLE__TITULO = PAGINAS_CRUD__TITULO;

	/**
	 * The feature id for the '<em><b>Url</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DETALLE__URL = PAGINAS_CRUD__URL;

	/**
	 * The feature id for the '<em><b>Redes sociales</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DETALLE__REDES_SOCIALES = PAGINAS_CRUD__REDES_SOCIALES;

	/**
	 * The feature id for the '<em><b>Home</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DETALLE__HOME = PAGINAS_CRUD__HOME;

	/**
	 * The feature id for the '<em><b>Tipodatos</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DETALLE__TIPODATOS = PAGINAS_CRUD__TIPODATOS;

	/**
	 * The number of structural features of the '<em>Detalle</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DETALLE_FEATURE_COUNT = PAGINAS_CRUD_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link dsl_4webquiz.impl.CreacionImpl <em>Creacion</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dsl_4webquiz.impl.CreacionImpl
	 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getCreacion()
	 * @generated
	 */
	int CREACION = 10;

	/**
	 * The feature id for the '<em><b>Titulo</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREACION__TITULO = PAGINAS_CRUD__TITULO;

	/**
	 * The feature id for the '<em><b>Url</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREACION__URL = PAGINAS_CRUD__URL;

	/**
	 * The feature id for the '<em><b>Redes sociales</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREACION__REDES_SOCIALES = PAGINAS_CRUD__REDES_SOCIALES;

	/**
	 * The feature id for the '<em><b>Home</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREACION__HOME = PAGINAS_CRUD__HOME;

	/**
	 * The feature id for the '<em><b>Tipodatos</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREACION__TIPODATOS = PAGINAS_CRUD__TIPODATOS;

	/**
	 * The number of structural features of the '<em>Creacion</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CREACION_FEATURE_COUNT = PAGINAS_CRUD_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link dsl_4webquiz.impl.BorradoImpl <em>Borrado</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dsl_4webquiz.impl.BorradoImpl
	 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getBorrado()
	 * @generated
	 */
	int BORRADO = 11;

	/**
	 * The feature id for the '<em><b>Titulo</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BORRADO__TITULO = PAGINAS_CRUD__TITULO;

	/**
	 * The feature id for the '<em><b>Url</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BORRADO__URL = PAGINAS_CRUD__URL;

	/**
	 * The feature id for the '<em><b>Redes sociales</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BORRADO__REDES_SOCIALES = PAGINAS_CRUD__REDES_SOCIALES;

	/**
	 * The feature id for the '<em><b>Home</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BORRADO__HOME = PAGINAS_CRUD__HOME;

	/**
	 * The feature id for the '<em><b>Tipodatos</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BORRADO__TIPODATOS = PAGINAS_CRUD__TIPODATOS;

	/**
	 * The number of structural features of the '<em>Borrado</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BORRADO_FEATURE_COUNT = PAGINAS_CRUD_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link dsl_4webquiz.impl.HomeImpl <em>Home</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dsl_4webquiz.impl.HomeImpl
	 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getHome()
	 * @generated
	 */
	int HOME = 12;

	/**
	 * The feature id for the '<em><b>Titulo</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOME__TITULO = PAGINA__TITULO;

	/**
	 * The feature id for the '<em><b>Url</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOME__URL = PAGINA__URL;

	/**
	 * The feature id for the '<em><b>Redes sociales</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOME__REDES_SOCIALES = PAGINA__REDES_SOCIALES;

	/**
	 * The feature id for the '<em><b>Crud</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOME__CRUD = PAGINA_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Consulta</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOME__CONSULTA = PAGINA_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Home</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HOME_FEATURE_COUNT = PAGINA_FEATURE_COUNT + 2;

	/**
	 * The meta object id for the '{@link dsl_4webquiz.impl.ConsultaImpl <em>Consulta</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dsl_4webquiz.impl.ConsultaImpl
	 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getConsulta()
	 * @generated
	 */
	int CONSULTA = 13;

	/**
	 * The feature id for the '<em><b>Titulo</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSULTA__TITULO = PAGINA__TITULO;

	/**
	 * The feature id for the '<em><b>Url</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSULTA__URL = PAGINA__URL;

	/**
	 * The feature id for the '<em><b>Redes sociales</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSULTA__REDES_SOCIALES = PAGINA__REDES_SOCIALES;

	/**
	 * The feature id for the '<em><b>Home</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSULTA__HOME = PAGINA_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Consulta</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSULTA_FEATURE_COUNT = PAGINA_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link dsl_4webquiz.impl.EncuestaImpl <em>Encuesta</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dsl_4webquiz.impl.EncuestaImpl
	 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getEncuesta()
	 * @generated
	 */
	int ENCUESTA = 14;

	/**
	 * The feature id for the '<em><b>Titulo</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENCUESTA__TITULO = CONSULTA__TITULO;

	/**
	 * The feature id for the '<em><b>Url</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENCUESTA__URL = CONSULTA__URL;

	/**
	 * The feature id for the '<em><b>Redes sociales</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENCUESTA__REDES_SOCIALES = CONSULTA__REDES_SOCIALES;

	/**
	 * The feature id for the '<em><b>Home</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENCUESTA__HOME = CONSULTA__HOME;

	/**
	 * The feature id for the '<em><b>Pregunta Encuesta</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENCUESTA__PREGUNTA_ENCUESTA = CONSULTA_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Encuesta</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENCUESTA_FEATURE_COUNT = CONSULTA_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link dsl_4webquiz.impl.CuestionarioImpl <em>Cuestionario</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dsl_4webquiz.impl.CuestionarioImpl
	 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getCuestionario()
	 * @generated
	 */
	int CUESTIONARIO = 15;

	/**
	 * The feature id for the '<em><b>Titulo</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUESTIONARIO__TITULO = CONSULTA__TITULO;

	/**
	 * The feature id for the '<em><b>Url</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUESTIONARIO__URL = CONSULTA__URL;

	/**
	 * The feature id for the '<em><b>Redes sociales</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUESTIONARIO__REDES_SOCIALES = CONSULTA__REDES_SOCIALES;

	/**
	 * The feature id for the '<em><b>Home</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUESTIONARIO__HOME = CONSULTA__HOME;

	/**
	 * The feature id for the '<em><b>Pregunta Cuestionario</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUESTIONARIO__PREGUNTA_CUESTIONARIO = CONSULTA_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Cuestionario</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUESTIONARIO_FEATURE_COUNT = CONSULTA_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link dsl_4webquiz.impl.PreguntaImpl <em>Pregunta</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dsl_4webquiz.impl.PreguntaImpl
	 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getPregunta()
	 * @generated
	 */
	int PREGUNTA = 18;

	/**
	 * The feature id for the '<em><b>Titulo Pregunta</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREGUNTA__TITULO_PREGUNTA = 0;

	/**
	 * The number of structural features of the '<em>Pregunta</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREGUNTA_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link dsl_4webquiz.impl.PreguntaCortaImpl <em>Pregunta Corta</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dsl_4webquiz.impl.PreguntaCortaImpl
	 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getPreguntaCorta()
	 * @generated
	 */
	int PREGUNTA_CORTA = 16;

	/**
	 * The feature id for the '<em><b>Titulo Pregunta</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREGUNTA_CORTA__TITULO_PREGUNTA = PREGUNTA__TITULO_PREGUNTA;

	/**
	 * The feature id for the '<em><b>Respuesta</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREGUNTA_CORTA__RESPUESTA = PREGUNTA_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Pregunta Corta</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PREGUNTA_CORTA_FEATURE_COUNT = PREGUNTA_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link dsl_4webquiz.impl.SeleccionImpl <em>Seleccion</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dsl_4webquiz.impl.SeleccionImpl
	 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getSeleccion()
	 * @generated
	 */
	int SELECCION = 17;

	/**
	 * The feature id for the '<em><b>Titulo Pregunta</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SELECCION__TITULO_PREGUNTA = PREGUNTA__TITULO_PREGUNTA;

	/**
	 * The feature id for the '<em><b>Opcion</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SELECCION__OPCION = PREGUNTA_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Correcta</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SELECCION__CORRECTA = PREGUNTA_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Seleccion</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SELECCION_FEATURE_COUNT = PREGUNTA_FEATURE_COUNT + 2;

	/**
	 * The meta object id for the '{@link dsl_4webquiz.impl.VoFImpl <em>Vo F</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dsl_4webquiz.impl.VoFImpl
	 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getVoF()
	 * @generated
	 */
	int VO_F = 19;

	/**
	 * The feature id for the '<em><b>Titulo Pregunta</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VO_F__TITULO_PREGUNTA = PREGUNTA__TITULO_PREGUNTA;

	/**
	 * The feature id for the '<em><b>Correcta</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VO_F__CORRECTA = PREGUNTA_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Vo F</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VO_F_FEATURE_COUNT = PREGUNTA_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link dsl_4webquiz.impl.OpcionImpl <em>Opcion</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dsl_4webquiz.impl.OpcionImpl
	 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getOpcion()
	 * @generated
	 */
	int OPCION = 20;

	/**
	 * The feature id for the '<em><b>Titulo Pregunta</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPCION__TITULO_PREGUNTA = 0;

	/**
	 * The number of structural features of the '<em>Opcion</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OPCION_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link dsl_4webquiz.impl.TipoDatosImpl <em>Tipo Datos</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dsl_4webquiz.impl.TipoDatosImpl
	 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getTipoDatos()
	 * @generated
	 */
	int TIPO_DATOS = 21;

	/**
	 * The feature id for the '<em><b>Nombre</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TIPO_DATOS__NOMBRE = 0;

	/**
	 * The feature id for the '<em><b>Atributo</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TIPO_DATOS__ATRIBUTO = 1;

	/**
	 * The number of structural features of the '<em>Tipo Datos</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TIPO_DATOS_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link dsl_4webquiz.impl.AtributoImpl <em>Atributo</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dsl_4webquiz.impl.AtributoImpl
	 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getAtributo()
	 * @generated
	 */
	int ATRIBUTO = 22;

	/**
	 * The feature id for the '<em><b>Tipo</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATRIBUTO__TIPO = 0;

	/**
	 * The feature id for the '<em><b>Nombre</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATRIBUTO__NOMBRE = 1;

	/**
	 * The number of structural features of the '<em>Atributo</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATRIBUTO_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link dsl_4webquiz.impl.CRUDImpl <em>CRUD</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dsl_4webquiz.impl.CRUDImpl
	 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getCRUD()
	 * @generated
	 */
	int CRUD = 23;

	/**
	 * The feature id for the '<em><b>Titulo</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRUD__TITULO = PAGINAS_CRUD__TITULO;

	/**
	 * The feature id for the '<em><b>Url</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRUD__URL = PAGINAS_CRUD__URL;

	/**
	 * The feature id for the '<em><b>Redes sociales</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRUD__REDES_SOCIALES = PAGINAS_CRUD__REDES_SOCIALES;

	/**
	 * The feature id for the '<em><b>Home</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRUD__HOME = PAGINAS_CRUD__HOME;

	/**
	 * The feature id for the '<em><b>Tipodatos</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRUD__TIPODATOS = PAGINAS_CRUD__TIPODATOS;

	/**
	 * The number of structural features of the '<em>CRUD</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CRUD_FEATURE_COUNT = PAGINAS_CRUD_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link dsl_4webquiz.impl.UpdateImpl <em>Update</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dsl_4webquiz.impl.UpdateImpl
	 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getUpdate()
	 * @generated
	 */
	int UPDATE = 24;

	/**
	 * The feature id for the '<em><b>Titulo</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UPDATE__TITULO = PAGINAS_CRUD__TITULO;

	/**
	 * The feature id for the '<em><b>Url</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UPDATE__URL = PAGINAS_CRUD__URL;

	/**
	 * The feature id for the '<em><b>Redes sociales</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UPDATE__REDES_SOCIALES = PAGINAS_CRUD__REDES_SOCIALES;

	/**
	 * The feature id for the '<em><b>Home</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UPDATE__HOME = PAGINAS_CRUD__HOME;

	/**
	 * The feature id for the '<em><b>Tipodatos</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UPDATE__TIPODATOS = PAGINAS_CRUD__TIPODATOS;

	/**
	 * The number of structural features of the '<em>Update</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UPDATE_FEATURE_COUNT = PAGINAS_CRUD_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link dsl_4webquiz.TipoAtributos <em>Tipo Atributos</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dsl_4webquiz.TipoAtributos
	 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getTipoAtributos()
	 * @generated
	 */
	int TIPO_ATRIBUTOS = 25;


	/**
	 * Returns the meta object for class '{@link dsl_4webquiz.Web <em>Web</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Web</em>'.
	 * @see dsl_4webquiz.Web
	 * @generated
	 */
	EClass getWeb();

	/**
	 * Returns the meta object for the containment reference list '{@link dsl_4webquiz.Web#getUsuario <em>Usuario</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Usuario</em>'.
	 * @see dsl_4webquiz.Web#getUsuario()
	 * @see #getWeb()
	 * @generated
	 */
	EReference getWeb_Usuario();

	/**
	 * Returns the meta object for the containment reference list '{@link dsl_4webquiz.Web#getPagina <em>Pagina</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Pagina</em>'.
	 * @see dsl_4webquiz.Web#getPagina()
	 * @see #getWeb()
	 * @generated
	 */
	EReference getWeb_Pagina();

	/**
	 * Returns the meta object for the containment reference list '{@link dsl_4webquiz.Web#getRedes_sociales <em>Redes sociales</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Redes sociales</em>'.
	 * @see dsl_4webquiz.Web#getRedes_sociales()
	 * @see #getWeb()
	 * @generated
	 */
	EReference getWeb_Redes_sociales();

	/**
	 * Returns the meta object for the containment reference list '{@link dsl_4webquiz.Web#getEntidad <em>Entidad</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Entidad</em>'.
	 * @see dsl_4webquiz.Web#getEntidad()
	 * @see #getWeb()
	 * @generated
	 */
	EReference getWeb_Entidad();

	/**
	 * Returns the meta object for the attribute '{@link dsl_4webquiz.Web#getNombre <em>Nombre</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nombre</em>'.
	 * @see dsl_4webquiz.Web#getNombre()
	 * @see #getWeb()
	 * @generated
	 */
	EAttribute getWeb_Nombre();

	/**
	 * Returns the meta object for the attribute '{@link dsl_4webquiz.Web#getUrl <em>Url</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Url</em>'.
	 * @see dsl_4webquiz.Web#getUrl()
	 * @see #getWeb()
	 * @generated
	 */
	EAttribute getWeb_Url();

	/**
	 * Returns the meta object for class '{@link dsl_4webquiz.Pagina <em>Pagina</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Pagina</em>'.
	 * @see dsl_4webquiz.Pagina
	 * @generated
	 */
	EClass getPagina();

	/**
	 * Returns the meta object for the attribute '{@link dsl_4webquiz.Pagina#getTitulo <em>Titulo</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Titulo</em>'.
	 * @see dsl_4webquiz.Pagina#getTitulo()
	 * @see #getPagina()
	 * @generated
	 */
	EAttribute getPagina_Titulo();

	/**
	 * Returns the meta object for the attribute '{@link dsl_4webquiz.Pagina#getUrl <em>Url</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Url</em>'.
	 * @see dsl_4webquiz.Pagina#getUrl()
	 * @see #getPagina()
	 * @generated
	 */
	EAttribute getPagina_Url();

	/**
	 * Returns the meta object for the reference list '{@link dsl_4webquiz.Pagina#getRedes_sociales <em>Redes sociales</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Redes sociales</em>'.
	 * @see dsl_4webquiz.Pagina#getRedes_sociales()
	 * @see #getPagina()
	 * @generated
	 */
	EReference getPagina_Redes_sociales();

	/**
	 * Returns the meta object for class '{@link dsl_4webquiz.Redes_Sociales <em>Redes Sociales</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Redes Sociales</em>'.
	 * @see dsl_4webquiz.Redes_Sociales
	 * @generated
	 */
	EClass getRedes_Sociales();

	/**
	 * Returns the meta object for the attribute '{@link dsl_4webquiz.Redes_Sociales#getEnlace <em>Enlace</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Enlace</em>'.
	 * @see dsl_4webquiz.Redes_Sociales#getEnlace()
	 * @see #getRedes_Sociales()
	 * @generated
	 */
	EAttribute getRedes_Sociales_Enlace();

	/**
	 * Returns the meta object for the reference list '{@link dsl_4webquiz.Redes_Sociales#getPagina <em>Pagina</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Pagina</em>'.
	 * @see dsl_4webquiz.Redes_Sociales#getPagina()
	 * @see #getRedes_Sociales()
	 * @generated
	 */
	EReference getRedes_Sociales_Pagina();

	/**
	 * Returns the meta object for class '{@link dsl_4webquiz.Usuario <em>Usuario</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Usuario</em>'.
	 * @see dsl_4webquiz.Usuario
	 * @generated
	 */
	EClass getUsuario();

	/**
	 * Returns the meta object for the attribute '{@link dsl_4webquiz.Usuario#getUsuario <em>Usuario</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Usuario</em>'.
	 * @see dsl_4webquiz.Usuario#getUsuario()
	 * @see #getUsuario()
	 * @generated
	 */
	EAttribute getUsuario_Usuario();

	/**
	 * Returns the meta object for the attribute '{@link dsl_4webquiz.Usuario#getPassword <em>Password</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Password</em>'.
	 * @see dsl_4webquiz.Usuario#getPassword()
	 * @see #getUsuario()
	 * @generated
	 */
	EAttribute getUsuario_Password();

	/**
	 * Returns the meta object for class '{@link dsl_4webquiz.Twitter <em>Twitter</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Twitter</em>'.
	 * @see dsl_4webquiz.Twitter
	 * @generated
	 */
	EClass getTwitter();

	/**
	 * Returns the meta object for class '{@link dsl_4webquiz.Google_plus <em>Google plus</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Google plus</em>'.
	 * @see dsl_4webquiz.Google_plus
	 * @generated
	 */
	EClass getGoogle_plus();

	/**
	 * Returns the meta object for class '{@link dsl_4webquiz.RSS <em>RSS</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>RSS</em>'.
	 * @see dsl_4webquiz.RSS
	 * @generated
	 */
	EClass getRSS();

	/**
	 * Returns the meta object for class '{@link dsl_4webquiz.PAGINAS_CRUD <em>PAGINAS CRUD</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>PAGINAS CRUD</em>'.
	 * @see dsl_4webquiz.PAGINAS_CRUD
	 * @generated
	 */
	EClass getPAGINAS_CRUD();

	/**
	 * Returns the meta object for the reference '{@link dsl_4webquiz.PAGINAS_CRUD#getHome <em>Home</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Home</em>'.
	 * @see dsl_4webquiz.PAGINAS_CRUD#getHome()
	 * @see #getPAGINAS_CRUD()
	 * @generated
	 */
	EReference getPAGINAS_CRUD_Home();

	/**
	 * Returns the meta object for the reference '{@link dsl_4webquiz.PAGINAS_CRUD#getTipodatos <em>Tipodatos</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Tipodatos</em>'.
	 * @see dsl_4webquiz.PAGINAS_CRUD#getTipodatos()
	 * @see #getPAGINAS_CRUD()
	 * @generated
	 */
	EReference getPAGINAS_CRUD_Tipodatos();

	/**
	 * Returns the meta object for class '{@link dsl_4webquiz.Indice <em>Indice</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Indice</em>'.
	 * @see dsl_4webquiz.Indice
	 * @generated
	 */
	EClass getIndice();

	/**
	 * Returns the meta object for class '{@link dsl_4webquiz.Detalle <em>Detalle</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Detalle</em>'.
	 * @see dsl_4webquiz.Detalle
	 * @generated
	 */
	EClass getDetalle();

	/**
	 * Returns the meta object for class '{@link dsl_4webquiz.Creacion <em>Creacion</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Creacion</em>'.
	 * @see dsl_4webquiz.Creacion
	 * @generated
	 */
	EClass getCreacion();

	/**
	 * Returns the meta object for class '{@link dsl_4webquiz.Borrado <em>Borrado</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Borrado</em>'.
	 * @see dsl_4webquiz.Borrado
	 * @generated
	 */
	EClass getBorrado();

	/**
	 * Returns the meta object for class '{@link dsl_4webquiz.Home <em>Home</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Home</em>'.
	 * @see dsl_4webquiz.Home
	 * @generated
	 */
	EClass getHome();

	/**
	 * Returns the meta object for the reference list '{@link dsl_4webquiz.Home#getCrud <em>Crud</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Crud</em>'.
	 * @see dsl_4webquiz.Home#getCrud()
	 * @see #getHome()
	 * @generated
	 */
	EReference getHome_Crud();

	/**
	 * Returns the meta object for the reference list '{@link dsl_4webquiz.Home#getConsulta <em>Consulta</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Consulta</em>'.
	 * @see dsl_4webquiz.Home#getConsulta()
	 * @see #getHome()
	 * @generated
	 */
	EReference getHome_Consulta();

	/**
	 * Returns the meta object for class '{@link dsl_4webquiz.Consulta <em>Consulta</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Consulta</em>'.
	 * @see dsl_4webquiz.Consulta
	 * @generated
	 */
	EClass getConsulta();

	/**
	 * Returns the meta object for the reference '{@link dsl_4webquiz.Consulta#getHome <em>Home</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Home</em>'.
	 * @see dsl_4webquiz.Consulta#getHome()
	 * @see #getConsulta()
	 * @generated
	 */
	EReference getConsulta_Home();

	/**
	 * Returns the meta object for class '{@link dsl_4webquiz.Encuesta <em>Encuesta</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Encuesta</em>'.
	 * @see dsl_4webquiz.Encuesta
	 * @generated
	 */
	EClass getEncuesta();

	/**
	 * Returns the meta object for the containment reference list '{@link dsl_4webquiz.Encuesta#getPreguntaEncuesta <em>Pregunta Encuesta</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Pregunta Encuesta</em>'.
	 * @see dsl_4webquiz.Encuesta#getPreguntaEncuesta()
	 * @see #getEncuesta()
	 * @generated
	 */
	EReference getEncuesta_PreguntaEncuesta();

	/**
	 * Returns the meta object for class '{@link dsl_4webquiz.Cuestionario <em>Cuestionario</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Cuestionario</em>'.
	 * @see dsl_4webquiz.Cuestionario
	 * @generated
	 */
	EClass getCuestionario();

	/**
	 * Returns the meta object for the containment reference list '{@link dsl_4webquiz.Cuestionario#getPreguntaCuestionario <em>Pregunta Cuestionario</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Pregunta Cuestionario</em>'.
	 * @see dsl_4webquiz.Cuestionario#getPreguntaCuestionario()
	 * @see #getCuestionario()
	 * @generated
	 */
	EReference getCuestionario_PreguntaCuestionario();

	/**
	 * Returns the meta object for class '{@link dsl_4webquiz.PreguntaCorta <em>Pregunta Corta</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Pregunta Corta</em>'.
	 * @see dsl_4webquiz.PreguntaCorta
	 * @generated
	 */
	EClass getPreguntaCorta();

	/**
	 * Returns the meta object for the attribute '{@link dsl_4webquiz.PreguntaCorta#getRespuesta <em>Respuesta</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Respuesta</em>'.
	 * @see dsl_4webquiz.PreguntaCorta#getRespuesta()
	 * @see #getPreguntaCorta()
	 * @generated
	 */
	EAttribute getPreguntaCorta_Respuesta();

	/**
	 * Returns the meta object for class '{@link dsl_4webquiz.Seleccion <em>Seleccion</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Seleccion</em>'.
	 * @see dsl_4webquiz.Seleccion
	 * @generated
	 */
	EClass getSeleccion();

	/**
	 * Returns the meta object for the containment reference list '{@link dsl_4webquiz.Seleccion#getOpcion <em>Opcion</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Opcion</em>'.
	 * @see dsl_4webquiz.Seleccion#getOpcion()
	 * @see #getSeleccion()
	 * @generated
	 */
	EReference getSeleccion_Opcion();

	/**
	 * Returns the meta object for the reference '{@link dsl_4webquiz.Seleccion#getCorrecta <em>Correcta</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Correcta</em>'.
	 * @see dsl_4webquiz.Seleccion#getCorrecta()
	 * @see #getSeleccion()
	 * @generated
	 */
	EReference getSeleccion_Correcta();

	/**
	 * Returns the meta object for class '{@link dsl_4webquiz.Pregunta <em>Pregunta</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Pregunta</em>'.
	 * @see dsl_4webquiz.Pregunta
	 * @generated
	 */
	EClass getPregunta();

	/**
	 * Returns the meta object for the attribute '{@link dsl_4webquiz.Pregunta#getTituloPregunta <em>Titulo Pregunta</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Titulo Pregunta</em>'.
	 * @see dsl_4webquiz.Pregunta#getTituloPregunta()
	 * @see #getPregunta()
	 * @generated
	 */
	EAttribute getPregunta_TituloPregunta();

	/**
	 * Returns the meta object for class '{@link dsl_4webquiz.VoF <em>Vo F</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Vo F</em>'.
	 * @see dsl_4webquiz.VoF
	 * @generated
	 */
	EClass getVoF();

	/**
	 * Returns the meta object for the attribute '{@link dsl_4webquiz.VoF#isCorrecta <em>Correcta</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Correcta</em>'.
	 * @see dsl_4webquiz.VoF#isCorrecta()
	 * @see #getVoF()
	 * @generated
	 */
	EAttribute getVoF_Correcta();

	/**
	 * Returns the meta object for class '{@link dsl_4webquiz.Opcion <em>Opcion</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Opcion</em>'.
	 * @see dsl_4webquiz.Opcion
	 * @generated
	 */
	EClass getOpcion();

	/**
	 * Returns the meta object for the attribute '{@link dsl_4webquiz.Opcion#getTituloPregunta <em>Titulo Pregunta</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Titulo Pregunta</em>'.
	 * @see dsl_4webquiz.Opcion#getTituloPregunta()
	 * @see #getOpcion()
	 * @generated
	 */
	EAttribute getOpcion_TituloPregunta();

	/**
	 * Returns the meta object for class '{@link dsl_4webquiz.TipoDatos <em>Tipo Datos</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Tipo Datos</em>'.
	 * @see dsl_4webquiz.TipoDatos
	 * @generated
	 */
	EClass getTipoDatos();

	/**
	 * Returns the meta object for the attribute '{@link dsl_4webquiz.TipoDatos#getNombre <em>Nombre</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nombre</em>'.
	 * @see dsl_4webquiz.TipoDatos#getNombre()
	 * @see #getTipoDatos()
	 * @generated
	 */
	EAttribute getTipoDatos_Nombre();

	/**
	 * Returns the meta object for the containment reference list '{@link dsl_4webquiz.TipoDatos#getAtributo <em>Atributo</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Atributo</em>'.
	 * @see dsl_4webquiz.TipoDatos#getAtributo()
	 * @see #getTipoDatos()
	 * @generated
	 */
	EReference getTipoDatos_Atributo();

	/**
	 * Returns the meta object for class '{@link dsl_4webquiz.Atributo <em>Atributo</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Atributo</em>'.
	 * @see dsl_4webquiz.Atributo
	 * @generated
	 */
	EClass getAtributo();

	/**
	 * Returns the meta object for the attribute '{@link dsl_4webquiz.Atributo#getTipo <em>Tipo</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Tipo</em>'.
	 * @see dsl_4webquiz.Atributo#getTipo()
	 * @see #getAtributo()
	 * @generated
	 */
	EAttribute getAtributo_Tipo();

	/**
	 * Returns the meta object for the attribute '{@link dsl_4webquiz.Atributo#getNombre <em>Nombre</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nombre</em>'.
	 * @see dsl_4webquiz.Atributo#getNombre()
	 * @see #getAtributo()
	 * @generated
	 */
	EAttribute getAtributo_Nombre();

	/**
	 * Returns the meta object for class '{@link dsl_4webquiz.CRUD <em>CRUD</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>CRUD</em>'.
	 * @see dsl_4webquiz.CRUD
	 * @generated
	 */
	EClass getCRUD();

	/**
	 * Returns the meta object for class '{@link dsl_4webquiz.Update <em>Update</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Update</em>'.
	 * @see dsl_4webquiz.Update
	 * @generated
	 */
	EClass getUpdate();

	/**
	 * Returns the meta object for enum '{@link dsl_4webquiz.TipoAtributos <em>Tipo Atributos</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Tipo Atributos</em>'.
	 * @see dsl_4webquiz.TipoAtributos
	 * @generated
	 */
	EEnum getTipoAtributos();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	Dsl_4webquizFactory getDsl_4webquizFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link dsl_4webquiz.impl.WebImpl <em>Web</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dsl_4webquiz.impl.WebImpl
		 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getWeb()
		 * @generated
		 */
		EClass WEB = eINSTANCE.getWeb();

		/**
		 * The meta object literal for the '<em><b>Usuario</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference WEB__USUARIO = eINSTANCE.getWeb_Usuario();

		/**
		 * The meta object literal for the '<em><b>Pagina</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference WEB__PAGINA = eINSTANCE.getWeb_Pagina();

		/**
		 * The meta object literal for the '<em><b>Redes sociales</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference WEB__REDES_SOCIALES = eINSTANCE.getWeb_Redes_sociales();

		/**
		 * The meta object literal for the '<em><b>Entidad</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference WEB__ENTIDAD = eINSTANCE.getWeb_Entidad();

		/**
		 * The meta object literal for the '<em><b>Nombre</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WEB__NOMBRE = eINSTANCE.getWeb_Nombre();

		/**
		 * The meta object literal for the '<em><b>Url</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute WEB__URL = eINSTANCE.getWeb_Url();

		/**
		 * The meta object literal for the '{@link dsl_4webquiz.impl.PaginaImpl <em>Pagina</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dsl_4webquiz.impl.PaginaImpl
		 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getPagina()
		 * @generated
		 */
		EClass PAGINA = eINSTANCE.getPagina();

		/**
		 * The meta object literal for the '<em><b>Titulo</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PAGINA__TITULO = eINSTANCE.getPagina_Titulo();

		/**
		 * The meta object literal for the '<em><b>Url</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PAGINA__URL = eINSTANCE.getPagina_Url();

		/**
		 * The meta object literal for the '<em><b>Redes sociales</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAGINA__REDES_SOCIALES = eINSTANCE.getPagina_Redes_sociales();

		/**
		 * The meta object literal for the '{@link dsl_4webquiz.impl.Redes_SocialesImpl <em>Redes Sociales</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dsl_4webquiz.impl.Redes_SocialesImpl
		 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getRedes_Sociales()
		 * @generated
		 */
		EClass REDES_SOCIALES = eINSTANCE.getRedes_Sociales();

		/**
		 * The meta object literal for the '<em><b>Enlace</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REDES_SOCIALES__ENLACE = eINSTANCE.getRedes_Sociales_Enlace();

		/**
		 * The meta object literal for the '<em><b>Pagina</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference REDES_SOCIALES__PAGINA = eINSTANCE.getRedes_Sociales_Pagina();

		/**
		 * The meta object literal for the '{@link dsl_4webquiz.impl.UsuarioImpl <em>Usuario</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dsl_4webquiz.impl.UsuarioImpl
		 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getUsuario()
		 * @generated
		 */
		EClass USUARIO = eINSTANCE.getUsuario();

		/**
		 * The meta object literal for the '<em><b>Usuario</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute USUARIO__USUARIO = eINSTANCE.getUsuario_Usuario();

		/**
		 * The meta object literal for the '<em><b>Password</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute USUARIO__PASSWORD = eINSTANCE.getUsuario_Password();

		/**
		 * The meta object literal for the '{@link dsl_4webquiz.impl.TwitterImpl <em>Twitter</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dsl_4webquiz.impl.TwitterImpl
		 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getTwitter()
		 * @generated
		 */
		EClass TWITTER = eINSTANCE.getTwitter();

		/**
		 * The meta object literal for the '{@link dsl_4webquiz.impl.Google_plusImpl <em>Google plus</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dsl_4webquiz.impl.Google_plusImpl
		 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getGoogle_plus()
		 * @generated
		 */
		EClass GOOGLE_PLUS = eINSTANCE.getGoogle_plus();

		/**
		 * The meta object literal for the '{@link dsl_4webquiz.impl.RSSImpl <em>RSS</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dsl_4webquiz.impl.RSSImpl
		 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getRSS()
		 * @generated
		 */
		EClass RSS = eINSTANCE.getRSS();

		/**
		 * The meta object literal for the '{@link dsl_4webquiz.impl.PAGINAS_CRUDImpl <em>PAGINAS CRUD</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dsl_4webquiz.impl.PAGINAS_CRUDImpl
		 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getPAGINAS_CRUD()
		 * @generated
		 */
		EClass PAGINAS_CRUD = eINSTANCE.getPAGINAS_CRUD();

		/**
		 * The meta object literal for the '<em><b>Home</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAGINAS_CRUD__HOME = eINSTANCE.getPAGINAS_CRUD_Home();

		/**
		 * The meta object literal for the '<em><b>Tipodatos</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAGINAS_CRUD__TIPODATOS = eINSTANCE.getPAGINAS_CRUD_Tipodatos();

		/**
		 * The meta object literal for the '{@link dsl_4webquiz.impl.IndiceImpl <em>Indice</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dsl_4webquiz.impl.IndiceImpl
		 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getIndice()
		 * @generated
		 */
		EClass INDICE = eINSTANCE.getIndice();

		/**
		 * The meta object literal for the '{@link dsl_4webquiz.impl.DetalleImpl <em>Detalle</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dsl_4webquiz.impl.DetalleImpl
		 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getDetalle()
		 * @generated
		 */
		EClass DETALLE = eINSTANCE.getDetalle();

		/**
		 * The meta object literal for the '{@link dsl_4webquiz.impl.CreacionImpl <em>Creacion</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dsl_4webquiz.impl.CreacionImpl
		 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getCreacion()
		 * @generated
		 */
		EClass CREACION = eINSTANCE.getCreacion();

		/**
		 * The meta object literal for the '{@link dsl_4webquiz.impl.BorradoImpl <em>Borrado</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dsl_4webquiz.impl.BorradoImpl
		 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getBorrado()
		 * @generated
		 */
		EClass BORRADO = eINSTANCE.getBorrado();

		/**
		 * The meta object literal for the '{@link dsl_4webquiz.impl.HomeImpl <em>Home</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dsl_4webquiz.impl.HomeImpl
		 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getHome()
		 * @generated
		 */
		EClass HOME = eINSTANCE.getHome();

		/**
		 * The meta object literal for the '<em><b>Crud</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOME__CRUD = eINSTANCE.getHome_Crud();

		/**
		 * The meta object literal for the '<em><b>Consulta</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference HOME__CONSULTA = eINSTANCE.getHome_Consulta();

		/**
		 * The meta object literal for the '{@link dsl_4webquiz.impl.ConsultaImpl <em>Consulta</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dsl_4webquiz.impl.ConsultaImpl
		 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getConsulta()
		 * @generated
		 */
		EClass CONSULTA = eINSTANCE.getConsulta();

		/**
		 * The meta object literal for the '<em><b>Home</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONSULTA__HOME = eINSTANCE.getConsulta_Home();

		/**
		 * The meta object literal for the '{@link dsl_4webquiz.impl.EncuestaImpl <em>Encuesta</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dsl_4webquiz.impl.EncuestaImpl
		 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getEncuesta()
		 * @generated
		 */
		EClass ENCUESTA = eINSTANCE.getEncuesta();

		/**
		 * The meta object literal for the '<em><b>Pregunta Encuesta</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ENCUESTA__PREGUNTA_ENCUESTA = eINSTANCE.getEncuesta_PreguntaEncuesta();

		/**
		 * The meta object literal for the '{@link dsl_4webquiz.impl.CuestionarioImpl <em>Cuestionario</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dsl_4webquiz.impl.CuestionarioImpl
		 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getCuestionario()
		 * @generated
		 */
		EClass CUESTIONARIO = eINSTANCE.getCuestionario();

		/**
		 * The meta object literal for the '<em><b>Pregunta Cuestionario</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CUESTIONARIO__PREGUNTA_CUESTIONARIO = eINSTANCE.getCuestionario_PreguntaCuestionario();

		/**
		 * The meta object literal for the '{@link dsl_4webquiz.impl.PreguntaCortaImpl <em>Pregunta Corta</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dsl_4webquiz.impl.PreguntaCortaImpl
		 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getPreguntaCorta()
		 * @generated
		 */
		EClass PREGUNTA_CORTA = eINSTANCE.getPreguntaCorta();

		/**
		 * The meta object literal for the '<em><b>Respuesta</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PREGUNTA_CORTA__RESPUESTA = eINSTANCE.getPreguntaCorta_Respuesta();

		/**
		 * The meta object literal for the '{@link dsl_4webquiz.impl.SeleccionImpl <em>Seleccion</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dsl_4webquiz.impl.SeleccionImpl
		 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getSeleccion()
		 * @generated
		 */
		EClass SELECCION = eINSTANCE.getSeleccion();

		/**
		 * The meta object literal for the '<em><b>Opcion</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SELECCION__OPCION = eINSTANCE.getSeleccion_Opcion();

		/**
		 * The meta object literal for the '<em><b>Correcta</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SELECCION__CORRECTA = eINSTANCE.getSeleccion_Correcta();

		/**
		 * The meta object literal for the '{@link dsl_4webquiz.impl.PreguntaImpl <em>Pregunta</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dsl_4webquiz.impl.PreguntaImpl
		 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getPregunta()
		 * @generated
		 */
		EClass PREGUNTA = eINSTANCE.getPregunta();

		/**
		 * The meta object literal for the '<em><b>Titulo Pregunta</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PREGUNTA__TITULO_PREGUNTA = eINSTANCE.getPregunta_TituloPregunta();

		/**
		 * The meta object literal for the '{@link dsl_4webquiz.impl.VoFImpl <em>Vo F</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dsl_4webquiz.impl.VoFImpl
		 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getVoF()
		 * @generated
		 */
		EClass VO_F = eINSTANCE.getVoF();

		/**
		 * The meta object literal for the '<em><b>Correcta</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VO_F__CORRECTA = eINSTANCE.getVoF_Correcta();

		/**
		 * The meta object literal for the '{@link dsl_4webquiz.impl.OpcionImpl <em>Opcion</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dsl_4webquiz.impl.OpcionImpl
		 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getOpcion()
		 * @generated
		 */
		EClass OPCION = eINSTANCE.getOpcion();

		/**
		 * The meta object literal for the '<em><b>Titulo Pregunta</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OPCION__TITULO_PREGUNTA = eINSTANCE.getOpcion_TituloPregunta();

		/**
		 * The meta object literal for the '{@link dsl_4webquiz.impl.TipoDatosImpl <em>Tipo Datos</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dsl_4webquiz.impl.TipoDatosImpl
		 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getTipoDatos()
		 * @generated
		 */
		EClass TIPO_DATOS = eINSTANCE.getTipoDatos();

		/**
		 * The meta object literal for the '<em><b>Nombre</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TIPO_DATOS__NOMBRE = eINSTANCE.getTipoDatos_Nombre();

		/**
		 * The meta object literal for the '<em><b>Atributo</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TIPO_DATOS__ATRIBUTO = eINSTANCE.getTipoDatos_Atributo();

		/**
		 * The meta object literal for the '{@link dsl_4webquiz.impl.AtributoImpl <em>Atributo</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dsl_4webquiz.impl.AtributoImpl
		 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getAtributo()
		 * @generated
		 */
		EClass ATRIBUTO = eINSTANCE.getAtributo();

		/**
		 * The meta object literal for the '<em><b>Tipo</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATRIBUTO__TIPO = eINSTANCE.getAtributo_Tipo();

		/**
		 * The meta object literal for the '<em><b>Nombre</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATRIBUTO__NOMBRE = eINSTANCE.getAtributo_Nombre();

		/**
		 * The meta object literal for the '{@link dsl_4webquiz.impl.CRUDImpl <em>CRUD</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dsl_4webquiz.impl.CRUDImpl
		 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getCRUD()
		 * @generated
		 */
		EClass CRUD = eINSTANCE.getCRUD();

		/**
		 * The meta object literal for the '{@link dsl_4webquiz.impl.UpdateImpl <em>Update</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dsl_4webquiz.impl.UpdateImpl
		 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getUpdate()
		 * @generated
		 */
		EClass UPDATE = eINSTANCE.getUpdate();

		/**
		 * The meta object literal for the '{@link dsl_4webquiz.TipoAtributos <em>Tipo Atributos</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dsl_4webquiz.TipoAtributos
		 * @see dsl_4webquiz.impl.Dsl_4webquizPackageImpl#getTipoAtributos()
		 * @generated
		 */
		EEnum TIPO_ATRIBUTOS = eINSTANCE.getTipoAtributos();

	}

} //Dsl_4webquizPackage
