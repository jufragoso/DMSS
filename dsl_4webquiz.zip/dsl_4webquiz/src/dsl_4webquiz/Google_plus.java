/**
 */
package dsl_4webquiz;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Google plus</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see dsl_4webquiz.Dsl_4webquizPackage#getGoogle_plus()
 * @model annotation="gmf.node label='enlace' border.color='132,132,132' border.width='3' color='208,255,251' resizable='true' border.stype='solid'"
 * @generated
 */
public interface Google_plus extends Redes_Sociales {
} // Google_plus
