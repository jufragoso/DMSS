/**
 */
package dsl_4webquiz.impl;

import dsl_4webquiz.Creacion;
import dsl_4webquiz.Dsl_4webquizPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Creacion</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class CreacionImpl extends PAGINAS_CRUDImpl implements Creacion {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CreacionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Dsl_4webquizPackage.Literals.CREACION;
	}

} //CreacionImpl
