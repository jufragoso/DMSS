/**
 */
package dsl_4webquiz.impl;

import dsl_4webquiz.Consulta;
import dsl_4webquiz.Dsl_4webquizPackage;
import dsl_4webquiz.Home;
import dsl_4webquiz.PAGINAS_CRUD;

import java.util.Collection;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Home</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link dsl_4webquiz.impl.HomeImpl#getCrud <em>Crud</em>}</li>
 *   <li>{@link dsl_4webquiz.impl.HomeImpl#getConsulta <em>Consulta</em>}</li>
 * </ul>
 *
 * @generated
 */
public class HomeImpl extends PaginaImpl implements Home {
	/**
	 * The cached value of the '{@link #getCrud() <em>Crud</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCrud()
	 * @generated
	 * @ordered
	 */
	protected EList<PAGINAS_CRUD> crud;

	/**
	 * The cached value of the '{@link #getConsulta() <em>Consulta</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConsulta()
	 * @generated
	 * @ordered
	 */
	protected EList<Consulta> consulta;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected HomeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Dsl_4webquizPackage.Literals.HOME;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<PAGINAS_CRUD> getCrud() {
		if (crud == null) {
			crud = new EObjectResolvingEList<PAGINAS_CRUD>(PAGINAS_CRUD.class, this, Dsl_4webquizPackage.HOME__CRUD);
		}
		return crud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Consulta> getConsulta() {
		if (consulta == null) {
			consulta = new EObjectResolvingEList<Consulta>(Consulta.class, this, Dsl_4webquizPackage.HOME__CONSULTA);
		}
		return consulta;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Dsl_4webquizPackage.HOME__CRUD:
				return getCrud();
			case Dsl_4webquizPackage.HOME__CONSULTA:
				return getConsulta();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Dsl_4webquizPackage.HOME__CRUD:
				getCrud().clear();
				getCrud().addAll((Collection<? extends PAGINAS_CRUD>)newValue);
				return;
			case Dsl_4webquizPackage.HOME__CONSULTA:
				getConsulta().clear();
				getConsulta().addAll((Collection<? extends Consulta>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Dsl_4webquizPackage.HOME__CRUD:
				getCrud().clear();
				return;
			case Dsl_4webquizPackage.HOME__CONSULTA:
				getConsulta().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Dsl_4webquizPackage.HOME__CRUD:
				return crud != null && !crud.isEmpty();
			case Dsl_4webquizPackage.HOME__CONSULTA:
				return consulta != null && !consulta.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //HomeImpl
