/**
 */
package dsl_4webquiz.impl;

import dsl_4webquiz.Detalle;
import dsl_4webquiz.Dsl_4webquizPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Detalle</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class DetalleImpl extends PAGINAS_CRUDImpl implements Detalle {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DetalleImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Dsl_4webquizPackage.Literals.DETALLE;
	}

} //DetalleImpl
