/**
 */
package dsl_4webquiz.impl;

import dsl_4webquiz.Consulta;
import dsl_4webquiz.Dsl_4webquizPackage;
import dsl_4webquiz.Home;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Consulta</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link dsl_4webquiz.impl.ConsultaImpl#getHome <em>Home</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class ConsultaImpl extends PaginaImpl implements Consulta {
	/**
	 * The cached value of the '{@link #getHome() <em>Home</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHome()
	 * @generated
	 * @ordered
	 */
	protected Home home;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ConsultaImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Dsl_4webquizPackage.Literals.CONSULTA;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Home getHome() {
		if (home != null && home.eIsProxy()) {
			InternalEObject oldHome = (InternalEObject)home;
			home = (Home)eResolveProxy(oldHome);
			if (home != oldHome) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Dsl_4webquizPackage.CONSULTA__HOME, oldHome, home));
			}
		}
		return home;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Home basicGetHome() {
		return home;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setHome(Home newHome) {
		Home oldHome = home;
		home = newHome;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Dsl_4webquizPackage.CONSULTA__HOME, oldHome, home));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Dsl_4webquizPackage.CONSULTA__HOME:
				if (resolve) return getHome();
				return basicGetHome();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Dsl_4webquizPackage.CONSULTA__HOME:
				setHome((Home)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Dsl_4webquizPackage.CONSULTA__HOME:
				setHome((Home)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Dsl_4webquizPackage.CONSULTA__HOME:
				return home != null;
		}
		return super.eIsSet(featureID);
	}

} //ConsultaImpl
