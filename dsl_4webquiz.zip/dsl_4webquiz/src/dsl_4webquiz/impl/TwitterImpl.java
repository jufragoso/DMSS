/**
 */
package dsl_4webquiz.impl;

import dsl_4webquiz.Dsl_4webquizPackage;
import dsl_4webquiz.Twitter;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Twitter</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class TwitterImpl extends Redes_SocialesImpl implements Twitter {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TwitterImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Dsl_4webquizPackage.Literals.TWITTER;
	}

} //TwitterImpl
