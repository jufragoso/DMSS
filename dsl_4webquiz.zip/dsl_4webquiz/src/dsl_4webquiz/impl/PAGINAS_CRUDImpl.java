/**
 */
package dsl_4webquiz.impl;

import dsl_4webquiz.Dsl_4webquizPackage;
import dsl_4webquiz.Home;
import dsl_4webquiz.PAGINAS_CRUD;
import dsl_4webquiz.TipoDatos;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>PAGINAS CRUD</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link dsl_4webquiz.impl.PAGINAS_CRUDImpl#getHome <em>Home</em>}</li>
 *   <li>{@link dsl_4webquiz.impl.PAGINAS_CRUDImpl#getTipodatos <em>Tipodatos</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class PAGINAS_CRUDImpl extends PaginaImpl implements PAGINAS_CRUD {
	/**
	 * The cached value of the '{@link #getHome() <em>Home</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHome()
	 * @generated
	 * @ordered
	 */
	protected Home home;

	/**
	 * The cached value of the '{@link #getTipodatos() <em>Tipodatos</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTipodatos()
	 * @generated
	 * @ordered
	 */
	protected TipoDatos tipodatos;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PAGINAS_CRUDImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Dsl_4webquizPackage.Literals.PAGINAS_CRUD;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Home getHome() {
		if (home != null && home.eIsProxy()) {
			InternalEObject oldHome = (InternalEObject)home;
			home = (Home)eResolveProxy(oldHome);
			if (home != oldHome) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Dsl_4webquizPackage.PAGINAS_CRUD__HOME, oldHome, home));
			}
		}
		return home;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Home basicGetHome() {
		return home;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setHome(Home newHome) {
		Home oldHome = home;
		home = newHome;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Dsl_4webquizPackage.PAGINAS_CRUD__HOME, oldHome, home));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TipoDatos getTipodatos() {
		if (tipodatos != null && tipodatos.eIsProxy()) {
			InternalEObject oldTipodatos = (InternalEObject)tipodatos;
			tipodatos = (TipoDatos)eResolveProxy(oldTipodatos);
			if (tipodatos != oldTipodatos) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, Dsl_4webquizPackage.PAGINAS_CRUD__TIPODATOS, oldTipodatos, tipodatos));
			}
		}
		return tipodatos;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TipoDatos basicGetTipodatos() {
		return tipodatos;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTipodatos(TipoDatos newTipodatos) {
		TipoDatos oldTipodatos = tipodatos;
		tipodatos = newTipodatos;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Dsl_4webquizPackage.PAGINAS_CRUD__TIPODATOS, oldTipodatos, tipodatos));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Dsl_4webquizPackage.PAGINAS_CRUD__HOME:
				if (resolve) return getHome();
				return basicGetHome();
			case Dsl_4webquizPackage.PAGINAS_CRUD__TIPODATOS:
				if (resolve) return getTipodatos();
				return basicGetTipodatos();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Dsl_4webquizPackage.PAGINAS_CRUD__HOME:
				setHome((Home)newValue);
				return;
			case Dsl_4webquizPackage.PAGINAS_CRUD__TIPODATOS:
				setTipodatos((TipoDatos)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Dsl_4webquizPackage.PAGINAS_CRUD__HOME:
				setHome((Home)null);
				return;
			case Dsl_4webquizPackage.PAGINAS_CRUD__TIPODATOS:
				setTipodatos((TipoDatos)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Dsl_4webquizPackage.PAGINAS_CRUD__HOME:
				return home != null;
			case Dsl_4webquizPackage.PAGINAS_CRUD__TIPODATOS:
				return tipodatos != null;
		}
		return super.eIsSet(featureID);
	}

} //PAGINAS_CRUDImpl
