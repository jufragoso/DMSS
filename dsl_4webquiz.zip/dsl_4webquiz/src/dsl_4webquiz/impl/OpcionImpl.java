/**
 */
package dsl_4webquiz.impl;

import dsl_4webquiz.Dsl_4webquizPackage;
import dsl_4webquiz.Opcion;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Opcion</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link dsl_4webquiz.impl.OpcionImpl#getTituloPregunta <em>Titulo Pregunta</em>}</li>
 * </ul>
 *
 * @generated
 */
public class OpcionImpl extends EObjectImpl implements Opcion {
	/**
	 * The default value of the '{@link #getTituloPregunta() <em>Titulo Pregunta</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTituloPregunta()
	 * @generated
	 * @ordered
	 */
	protected static final String TITULO_PREGUNTA_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTituloPregunta() <em>Titulo Pregunta</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTituloPregunta()
	 * @generated
	 * @ordered
	 */
	protected String tituloPregunta = TITULO_PREGUNTA_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected OpcionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Dsl_4webquizPackage.Literals.OPCION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getTituloPregunta() {
		return tituloPregunta;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTituloPregunta(String newTituloPregunta) {
		String oldTituloPregunta = tituloPregunta;
		tituloPregunta = newTituloPregunta;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Dsl_4webquizPackage.OPCION__TITULO_PREGUNTA, oldTituloPregunta, tituloPregunta));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Dsl_4webquizPackage.OPCION__TITULO_PREGUNTA:
				return getTituloPregunta();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Dsl_4webquizPackage.OPCION__TITULO_PREGUNTA:
				setTituloPregunta((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Dsl_4webquizPackage.OPCION__TITULO_PREGUNTA:
				setTituloPregunta(TITULO_PREGUNTA_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Dsl_4webquizPackage.OPCION__TITULO_PREGUNTA:
				return TITULO_PREGUNTA_EDEFAULT == null ? tituloPregunta != null : !TITULO_PREGUNTA_EDEFAULT.equals(tituloPregunta);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (tituloPregunta: ");
		result.append(tituloPregunta);
		result.append(')');
		return result.toString();
	}

} //OpcionImpl
