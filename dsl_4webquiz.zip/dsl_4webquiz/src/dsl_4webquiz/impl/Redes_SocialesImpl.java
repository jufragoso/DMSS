/**
 */
package dsl_4webquiz.impl;

import dsl_4webquiz.Dsl_4webquizPackage;
import dsl_4webquiz.Pagina;
import dsl_4webquiz.Redes_Sociales;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Redes Sociales</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link dsl_4webquiz.impl.Redes_SocialesImpl#getEnlace <em>Enlace</em>}</li>
 *   <li>{@link dsl_4webquiz.impl.Redes_SocialesImpl#getPagina <em>Pagina</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class Redes_SocialesImpl extends EObjectImpl implements Redes_Sociales {
	/**
	 * The default value of the '{@link #getEnlace() <em>Enlace</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEnlace()
	 * @generated
	 * @ordered
	 */
	protected static final String ENLACE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getEnlace() <em>Enlace</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEnlace()
	 * @generated
	 * @ordered
	 */
	protected String enlace = ENLACE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getPagina() <em>Pagina</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPagina()
	 * @generated
	 * @ordered
	 */
	protected EList<Pagina> pagina;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Redes_SocialesImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Dsl_4webquizPackage.Literals.REDES_SOCIALES;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getEnlace() {
		return enlace;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEnlace(String newEnlace) {
		String oldEnlace = enlace;
		enlace = newEnlace;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Dsl_4webquizPackage.REDES_SOCIALES__ENLACE, oldEnlace, enlace));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Pagina> getPagina() {
		if (pagina == null) {
			pagina = new EObjectResolvingEList<Pagina>(Pagina.class, this, Dsl_4webquizPackage.REDES_SOCIALES__PAGINA);
		}
		return pagina;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Dsl_4webquizPackage.REDES_SOCIALES__ENLACE:
				return getEnlace();
			case Dsl_4webquizPackage.REDES_SOCIALES__PAGINA:
				return getPagina();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Dsl_4webquizPackage.REDES_SOCIALES__ENLACE:
				setEnlace((String)newValue);
				return;
			case Dsl_4webquizPackage.REDES_SOCIALES__PAGINA:
				getPagina().clear();
				getPagina().addAll((Collection<? extends Pagina>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Dsl_4webquizPackage.REDES_SOCIALES__ENLACE:
				setEnlace(ENLACE_EDEFAULT);
				return;
			case Dsl_4webquizPackage.REDES_SOCIALES__PAGINA:
				getPagina().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Dsl_4webquizPackage.REDES_SOCIALES__ENLACE:
				return ENLACE_EDEFAULT == null ? enlace != null : !ENLACE_EDEFAULT.equals(enlace);
			case Dsl_4webquizPackage.REDES_SOCIALES__PAGINA:
				return pagina != null && !pagina.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (enlace: ");
		result.append(enlace);
		result.append(')');
		return result.toString();
	}

} //Redes_SocialesImpl
