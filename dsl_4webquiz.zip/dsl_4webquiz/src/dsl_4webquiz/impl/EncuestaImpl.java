/**
 */
package dsl_4webquiz.impl;

import dsl_4webquiz.Dsl_4webquizPackage;
import dsl_4webquiz.Encuesta;
import dsl_4webquiz.Pregunta;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Encuesta</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link dsl_4webquiz.impl.EncuestaImpl#getPreguntaEncuesta <em>Pregunta Encuesta</em>}</li>
 * </ul>
 *
 * @generated
 */
public class EncuestaImpl extends ConsultaImpl implements Encuesta {
	/**
	 * The cached value of the '{@link #getPreguntaEncuesta() <em>Pregunta Encuesta</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPreguntaEncuesta()
	 * @generated
	 * @ordered
	 */
	protected EList<Pregunta> preguntaEncuesta;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EncuestaImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Dsl_4webquizPackage.Literals.ENCUESTA;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Pregunta> getPreguntaEncuesta() {
		if (preguntaEncuesta == null) {
			preguntaEncuesta = new EObjectContainmentEList<Pregunta>(Pregunta.class, this, Dsl_4webquizPackage.ENCUESTA__PREGUNTA_ENCUESTA);
		}
		return preguntaEncuesta;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Dsl_4webquizPackage.ENCUESTA__PREGUNTA_ENCUESTA:
				return ((InternalEList<?>)getPreguntaEncuesta()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Dsl_4webquizPackage.ENCUESTA__PREGUNTA_ENCUESTA:
				return getPreguntaEncuesta();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Dsl_4webquizPackage.ENCUESTA__PREGUNTA_ENCUESTA:
				getPreguntaEncuesta().clear();
				getPreguntaEncuesta().addAll((Collection<? extends Pregunta>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Dsl_4webquizPackage.ENCUESTA__PREGUNTA_ENCUESTA:
				getPreguntaEncuesta().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Dsl_4webquizPackage.ENCUESTA__PREGUNTA_ENCUESTA:
				return preguntaEncuesta != null && !preguntaEncuesta.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //EncuestaImpl
