/**
 */
package dsl_4webquiz.impl;

import dsl_4webquiz.Dsl_4webquizPackage;
import dsl_4webquiz.PreguntaCorta;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Pregunta Corta</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link dsl_4webquiz.impl.PreguntaCortaImpl#getRespuesta <em>Respuesta</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PreguntaCortaImpl extends PreguntaImpl implements PreguntaCorta {
	/**
	 * The default value of the '{@link #getRespuesta() <em>Respuesta</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRespuesta()
	 * @generated
	 * @ordered
	 */
	protected static final String RESPUESTA_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getRespuesta() <em>Respuesta</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRespuesta()
	 * @generated
	 * @ordered
	 */
	protected String respuesta = RESPUESTA_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PreguntaCortaImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Dsl_4webquizPackage.Literals.PREGUNTA_CORTA;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getRespuesta() {
		return respuesta;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRespuesta(String newRespuesta) {
		String oldRespuesta = respuesta;
		respuesta = newRespuesta;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Dsl_4webquizPackage.PREGUNTA_CORTA__RESPUESTA, oldRespuesta, respuesta));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Dsl_4webquizPackage.PREGUNTA_CORTA__RESPUESTA:
				return getRespuesta();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Dsl_4webquizPackage.PREGUNTA_CORTA__RESPUESTA:
				setRespuesta((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Dsl_4webquizPackage.PREGUNTA_CORTA__RESPUESTA:
				setRespuesta(RESPUESTA_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Dsl_4webquizPackage.PREGUNTA_CORTA__RESPUESTA:
				return RESPUESTA_EDEFAULT == null ? respuesta != null : !RESPUESTA_EDEFAULT.equals(respuesta);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (respuesta: ");
		result.append(respuesta);
		result.append(')');
		return result.toString();
	}

} //PreguntaCortaImpl
