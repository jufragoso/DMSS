/**
 */
package dsl_4webquiz.impl;

import dsl_4webquiz.Atributo;
import dsl_4webquiz.Borrado;
import dsl_4webquiz.Consulta;
import dsl_4webquiz.Creacion;
import dsl_4webquiz.Cuestionario;
import dsl_4webquiz.Detalle;
import dsl_4webquiz.Dsl_4webquizFactory;
import dsl_4webquiz.Dsl_4webquizPackage;
import dsl_4webquiz.Encuesta;
import dsl_4webquiz.Google_plus;
import dsl_4webquiz.Home;
import dsl_4webquiz.Indice;
import dsl_4webquiz.Opcion;
import dsl_4webquiz.Pagina;
import dsl_4webquiz.Pregunta;
import dsl_4webquiz.PreguntaCorta;
import dsl_4webquiz.Redes_Sociales;
import dsl_4webquiz.Seleccion;
import dsl_4webquiz.TipoAtributos;
import dsl_4webquiz.TipoDatos;
import dsl_4webquiz.Twitter;
import dsl_4webquiz.Update;
import dsl_4webquiz.Usuario;
import dsl_4webquiz.VoF;
import dsl_4webquiz.Web;

import dsl_4webquiz.util.Dsl_4webquizValidator;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EValidator;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class Dsl_4webquizPackageImpl extends EPackageImpl implements Dsl_4webquizPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass webEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass paginaEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass redes_SocialesEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass usuarioEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass twitterEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass google_plusEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass rssEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass paginaS_CRUDEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass indiceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass detalleEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass creacionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass borradoEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass homeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass consultaEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass encuestaEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass cuestionarioEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass preguntaCortaEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass seleccionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass preguntaEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass voFEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass opcionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass tipoDatosEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass atributoEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass crudEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass updateEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum tipoAtributosEEnum = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see dsl_4webquiz.Dsl_4webquizPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private Dsl_4webquizPackageImpl() {
		super(eNS_URI, Dsl_4webquizFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 * 
	 * <p>This method is used to initialize {@link Dsl_4webquizPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static Dsl_4webquizPackage init() {
		if (isInited) return (Dsl_4webquizPackage)EPackage.Registry.INSTANCE.getEPackage(Dsl_4webquizPackage.eNS_URI);

		// Obtain or create and register package
		Dsl_4webquizPackageImpl theDsl_4webquizPackage = (Dsl_4webquizPackageImpl)(EPackage.Registry.INSTANCE.get(eNS_URI) instanceof Dsl_4webquizPackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI) : new Dsl_4webquizPackageImpl());

		isInited = true;

		// Create package meta-data objects
		theDsl_4webquizPackage.createPackageContents();

		// Initialize created meta-data
		theDsl_4webquizPackage.initializePackageContents();

		// Register package validator
		EValidator.Registry.INSTANCE.put
			(theDsl_4webquizPackage, 
			 new EValidator.Descriptor() {
				 public EValidator getEValidator() {
					 return Dsl_4webquizValidator.INSTANCE;
				 }
			 });

		// Mark meta-data to indicate it can't be changed
		theDsl_4webquizPackage.freeze();

  
		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(Dsl_4webquizPackage.eNS_URI, theDsl_4webquizPackage);
		return theDsl_4webquizPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getWeb() {
		return webEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getWeb_Usuario() {
		return (EReference)webEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getWeb_Pagina() {
		return (EReference)webEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getWeb_Redes_sociales() {
		return (EReference)webEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getWeb_Entidad() {
		return (EReference)webEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getWeb_Nombre() {
		return (EAttribute)webEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getWeb_Url() {
		return (EAttribute)webEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPagina() {
		return paginaEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPagina_Titulo() {
		return (EAttribute)paginaEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPagina_Url() {
		return (EAttribute)paginaEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPagina_Redes_sociales() {
		return (EReference)paginaEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRedes_Sociales() {
		return redes_SocialesEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRedes_Sociales_Enlace() {
		return (EAttribute)redes_SocialesEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRedes_Sociales_Pagina() {
		return (EReference)redes_SocialesEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getUsuario() {
		return usuarioEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getUsuario_Usuario() {
		return (EAttribute)usuarioEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getUsuario_Password() {
		return (EAttribute)usuarioEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTwitter() {
		return twitterEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getGoogle_plus() {
		return google_plusEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRSS() {
		return rssEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPAGINAS_CRUD() {
		return paginaS_CRUDEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPAGINAS_CRUD_Home() {
		return (EReference)paginaS_CRUDEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPAGINAS_CRUD_Tipodatos() {
		return (EReference)paginaS_CRUDEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getIndice() {
		return indiceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDetalle() {
		return detalleEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCreacion() {
		return creacionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getBorrado() {
		return borradoEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getHome() {
		return homeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHome_Crud() {
		return (EReference)homeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getHome_Consulta() {
		return (EReference)homeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getConsulta() {
		return consultaEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getConsulta_Home() {
		return (EReference)consultaEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getEncuesta() {
		return encuestaEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getEncuesta_PreguntaEncuesta() {
		return (EReference)encuestaEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCuestionario() {
		return cuestionarioEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCuestionario_PreguntaCuestionario() {
		return (EReference)cuestionarioEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPreguntaCorta() {
		return preguntaCortaEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPreguntaCorta_Respuesta() {
		return (EAttribute)preguntaCortaEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSeleccion() {
		return seleccionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSeleccion_Opcion() {
		return (EReference)seleccionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSeleccion_Correcta() {
		return (EReference)seleccionEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPregunta() {
		return preguntaEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPregunta_TituloPregunta() {
		return (EAttribute)preguntaEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getVoF() {
		return voFEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVoF_Correcta() {
		return (EAttribute)voFEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getOpcion() {
		return opcionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getOpcion_TituloPregunta() {
		return (EAttribute)opcionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTipoDatos() {
		return tipoDatosEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTipoDatos_Nombre() {
		return (EAttribute)tipoDatosEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTipoDatos_Atributo() {
		return (EReference)tipoDatosEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAtributo() {
		return atributoEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAtributo_Tipo() {
		return (EAttribute)atributoEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAtributo_Nombre() {
		return (EAttribute)atributoEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCRUD() {
		return crudEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getUpdate() {
		return updateEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getTipoAtributos() {
		return tipoAtributosEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Dsl_4webquizFactory getDsl_4webquizFactory() {
		return (Dsl_4webquizFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		webEClass = createEClass(WEB);
		createEReference(webEClass, WEB__USUARIO);
		createEReference(webEClass, WEB__PAGINA);
		createEReference(webEClass, WEB__REDES_SOCIALES);
		createEReference(webEClass, WEB__ENTIDAD);
		createEAttribute(webEClass, WEB__NOMBRE);
		createEAttribute(webEClass, WEB__URL);

		paginaEClass = createEClass(PAGINA);
		createEAttribute(paginaEClass, PAGINA__TITULO);
		createEAttribute(paginaEClass, PAGINA__URL);
		createEReference(paginaEClass, PAGINA__REDES_SOCIALES);

		redes_SocialesEClass = createEClass(REDES_SOCIALES);
		createEAttribute(redes_SocialesEClass, REDES_SOCIALES__ENLACE);
		createEReference(redes_SocialesEClass, REDES_SOCIALES__PAGINA);

		usuarioEClass = createEClass(USUARIO);
		createEAttribute(usuarioEClass, USUARIO__USUARIO);
		createEAttribute(usuarioEClass, USUARIO__PASSWORD);

		twitterEClass = createEClass(TWITTER);

		google_plusEClass = createEClass(GOOGLE_PLUS);

		rssEClass = createEClass(RSS);

		paginaS_CRUDEClass = createEClass(PAGINAS_CRUD);
		createEReference(paginaS_CRUDEClass, PAGINAS_CRUD__HOME);
		createEReference(paginaS_CRUDEClass, PAGINAS_CRUD__TIPODATOS);

		indiceEClass = createEClass(INDICE);

		detalleEClass = createEClass(DETALLE);

		creacionEClass = createEClass(CREACION);

		borradoEClass = createEClass(BORRADO);

		homeEClass = createEClass(HOME);
		createEReference(homeEClass, HOME__CRUD);
		createEReference(homeEClass, HOME__CONSULTA);

		consultaEClass = createEClass(CONSULTA);
		createEReference(consultaEClass, CONSULTA__HOME);

		encuestaEClass = createEClass(ENCUESTA);
		createEReference(encuestaEClass, ENCUESTA__PREGUNTA_ENCUESTA);

		cuestionarioEClass = createEClass(CUESTIONARIO);
		createEReference(cuestionarioEClass, CUESTIONARIO__PREGUNTA_CUESTIONARIO);

		preguntaCortaEClass = createEClass(PREGUNTA_CORTA);
		createEAttribute(preguntaCortaEClass, PREGUNTA_CORTA__RESPUESTA);

		seleccionEClass = createEClass(SELECCION);
		createEReference(seleccionEClass, SELECCION__OPCION);
		createEReference(seleccionEClass, SELECCION__CORRECTA);

		preguntaEClass = createEClass(PREGUNTA);
		createEAttribute(preguntaEClass, PREGUNTA__TITULO_PREGUNTA);

		voFEClass = createEClass(VO_F);
		createEAttribute(voFEClass, VO_F__CORRECTA);

		opcionEClass = createEClass(OPCION);
		createEAttribute(opcionEClass, OPCION__TITULO_PREGUNTA);

		tipoDatosEClass = createEClass(TIPO_DATOS);
		createEAttribute(tipoDatosEClass, TIPO_DATOS__NOMBRE);
		createEReference(tipoDatosEClass, TIPO_DATOS__ATRIBUTO);

		atributoEClass = createEClass(ATRIBUTO);
		createEAttribute(atributoEClass, ATRIBUTO__TIPO);
		createEAttribute(atributoEClass, ATRIBUTO__NOMBRE);

		crudEClass = createEClass(CRUD);

		updateEClass = createEClass(UPDATE);

		// Create enums
		tipoAtributosEEnum = createEEnum(TIPO_ATRIBUTOS);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		twitterEClass.getESuperTypes().add(this.getRedes_Sociales());
		google_plusEClass.getESuperTypes().add(this.getRedes_Sociales());
		rssEClass.getESuperTypes().add(this.getRedes_Sociales());
		paginaS_CRUDEClass.getESuperTypes().add(this.getPagina());
		indiceEClass.getESuperTypes().add(this.getPAGINAS_CRUD());
		detalleEClass.getESuperTypes().add(this.getPAGINAS_CRUD());
		creacionEClass.getESuperTypes().add(this.getPAGINAS_CRUD());
		borradoEClass.getESuperTypes().add(this.getPAGINAS_CRUD());
		homeEClass.getESuperTypes().add(this.getPagina());
		consultaEClass.getESuperTypes().add(this.getPagina());
		encuestaEClass.getESuperTypes().add(this.getConsulta());
		cuestionarioEClass.getESuperTypes().add(this.getConsulta());
		preguntaCortaEClass.getESuperTypes().add(this.getPregunta());
		seleccionEClass.getESuperTypes().add(this.getPregunta());
		voFEClass.getESuperTypes().add(this.getPregunta());
		crudEClass.getESuperTypes().add(this.getPAGINAS_CRUD());
		updateEClass.getESuperTypes().add(this.getPAGINAS_CRUD());

		// Initialize classes and features; add operations and parameters
		initEClass(webEClass, Web.class, "Web", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getWeb_Usuario(), this.getUsuario(), null, "usuario", null, 0, -1, Web.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getWeb_Pagina(), this.getPagina(), null, "pagina", null, 0, -1, Web.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getWeb_Redes_sociales(), this.getRedes_Sociales(), null, "redes_sociales", null, 0, -1, Web.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getWeb_Entidad(), this.getTipoDatos(), null, "entidad", null, 0, -1, Web.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getWeb_Nombre(), ecorePackage.getEString(), "nombre", null, 0, 1, Web.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getWeb_Url(), ecorePackage.getEString(), "url", null, 0, 1, Web.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(paginaEClass, Pagina.class, "Pagina", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPagina_Titulo(), ecorePackage.getEString(), "titulo", null, 0, 1, Pagina.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPagina_Url(), ecorePackage.getEString(), "url", null, 0, 1, Pagina.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPagina_Redes_sociales(), this.getRedes_Sociales(), null, "redes_sociales", null, 0, -1, Pagina.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(redes_SocialesEClass, Redes_Sociales.class, "Redes_Sociales", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getRedes_Sociales_Enlace(), ecorePackage.getEString(), "enlace", null, 0, 1, Redes_Sociales.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRedes_Sociales_Pagina(), this.getPagina(), null, "pagina", null, 0, -1, Redes_Sociales.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(usuarioEClass, Usuario.class, "Usuario", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getUsuario_Usuario(), ecorePackage.getEString(), "usuario", null, 0, 1, Usuario.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getUsuario_Password(), ecorePackage.getEString(), "password", null, 0, 1, Usuario.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(twitterEClass, Twitter.class, "Twitter", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(google_plusEClass, Google_plus.class, "Google_plus", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(rssEClass, dsl_4webquiz.RSS.class, "RSS", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(paginaS_CRUDEClass, dsl_4webquiz.PAGINAS_CRUD.class, "PAGINAS_CRUD", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getPAGINAS_CRUD_Home(), this.getHome(), null, "home", null, 0, 1, dsl_4webquiz.PAGINAS_CRUD.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPAGINAS_CRUD_Tipodatos(), this.getTipoDatos(), null, "tipodatos", null, 1, 1, dsl_4webquiz.PAGINAS_CRUD.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(indiceEClass, Indice.class, "Indice", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(detalleEClass, Detalle.class, "Detalle", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(creacionEClass, Creacion.class, "Creacion", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(borradoEClass, Borrado.class, "Borrado", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(homeEClass, Home.class, "Home", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getHome_Crud(), this.getPAGINAS_CRUD(), null, "crud", null, 0, -1, Home.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getHome_Consulta(), this.getConsulta(), null, "consulta", null, 0, -1, Home.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(consultaEClass, Consulta.class, "Consulta", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getConsulta_Home(), this.getHome(), null, "home", null, 0, 1, Consulta.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(encuestaEClass, Encuesta.class, "Encuesta", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getEncuesta_PreguntaEncuesta(), this.getPregunta(), null, "preguntaEncuesta", null, 1, -1, Encuesta.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(cuestionarioEClass, Cuestionario.class, "Cuestionario", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getCuestionario_PreguntaCuestionario(), this.getPregunta(), null, "preguntaCuestionario", null, 1, -1, Cuestionario.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(preguntaCortaEClass, PreguntaCorta.class, "PreguntaCorta", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPreguntaCorta_Respuesta(), ecorePackage.getEString(), "respuesta", null, 0, 1, PreguntaCorta.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(seleccionEClass, Seleccion.class, "Seleccion", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getSeleccion_Opcion(), this.getOpcion(), null, "opcion", null, 0, -1, Seleccion.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSeleccion_Correcta(), this.getOpcion(), null, "correcta", null, 1, 1, Seleccion.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(preguntaEClass, Pregunta.class, "Pregunta", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPregunta_TituloPregunta(), ecorePackage.getEString(), "tituloPregunta", null, 0, 1, Pregunta.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(voFEClass, VoF.class, "VoF", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getVoF_Correcta(), ecorePackage.getEBoolean(), "correcta", null, 0, 1, VoF.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(opcionEClass, Opcion.class, "Opcion", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getOpcion_TituloPregunta(), ecorePackage.getEString(), "tituloPregunta", null, 0, 1, Opcion.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(tipoDatosEClass, TipoDatos.class, "TipoDatos", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getTipoDatos_Nombre(), ecorePackage.getEString(), "nombre", null, 0, 1, TipoDatos.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTipoDatos_Atributo(), this.getAtributo(), null, "atributo", null, 0, -1, TipoDatos.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(atributoEClass, Atributo.class, "Atributo", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAtributo_Tipo(), this.getTipoAtributos(), "tipo", null, 0, 1, Atributo.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAtributo_Nombre(), ecorePackage.getEString(), "nombre", null, 0, 1, Atributo.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(crudEClass, dsl_4webquiz.CRUD.class, "CRUD", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(updateEClass, Update.class, "Update", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		// Initialize enums and add enum literals
		initEEnum(tipoAtributosEEnum, TipoAtributos.class, "TipoAtributos");
		addEEnumLiteral(tipoAtributosEEnum, TipoAtributos.INT);
		addEEnumLiteral(tipoAtributosEEnum, TipoAtributos.FLOAT);
		addEEnumLiteral(tipoAtributosEEnum, TipoAtributos.STRING);

		// Create resource
		createResource(eNS_URI);

		// Create annotations
		// http://www.eclipse.org/emf/2002/Ecore
		createEcoreAnnotations();
		// http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot
		createPivotAnnotations();
		// gmf.diagram
		createGmfAnnotations();
		// gmf.link
		createGmf_1Annotations();
		// gmf.node
		createGmf_2Annotations();
		// gmf.compartment
		createGmf_3Annotations();
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/emf/2002/Ecore</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createEcoreAnnotations() {
		String source = "http://www.eclipse.org/emf/2002/Ecore";	
		addAnnotation
		  (this, 
		   source, 
		   new String[] {
			 "invocationDelegates", "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
			 "settingDelegates", "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
			 "validationDelegates", "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot"
		   });	
		addAnnotation
		  (webEClass, 
		   source, 
		   new String[] {
			 "constraints", "num_Home num_RedesSociales num_Encuestas num_Cuestionarios includesCrud includesConsulta CRUD_Unico Indice_Update Indice_Creacion Indice_Borrado Indice_Detalle"
		   });	
		addAnnotation
		  (preguntaCortaEClass, 
		   source, 
		   new String[] {
			 "constraints", "respuesta_definida"
		   });
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createPivotAnnotations() {
		String source = "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot";	
		addAnnotation
		  (webEClass, 
		   source, 
		   new String[] {
			 "num_Home", "self.pagina->selectByType(Home)->size() =1",
			 "num_RedesSociales", "self.redes_sociales->size()>0",
			 "num_Encuestas", "self.pagina->selectByKind(Consulta)->selectByType(Encuesta)->size()>0",
			 "num_Cuestionarios", "self.pagina->selectByKind(Consulta)->selectByType(Cuestionario)->size()>0",
			 "includesCrud", "self.pagina->selectByKind(Home).crud->includesAll(self.pagina->selectByKind(PAGINAS_CRUD))",
			 "includesConsulta", "self.pagina->selectByKind(Home).consulta->includesAll(self.pagina->selectByKind(Consulta))",
			 "CRUD_Unico", "self.pagina->selectByKind(CRUD).tipodatos->asSet()->excludesAll(self.pagina->selectByKind(Indice).tipodatos->union(self.pagina->selectByKind(Creacion).tipodatos)->union(self.pagina->selectByKind(Detalle).tipodatos)->union(self.pagina->selectByKind(Borrado).tipodatos)->asSet())",
			 "Indice_Update", "self.pagina->exists(self.pagina->selectByKind(Update).tipodatos=self.pagina->selectByKind(Indice).tipodatos)",
			 "Indice_Creacion", "self.pagina->exists(self.pagina->selectByKind(Creacion).tipodatos=self.pagina->selectByKind(Indice).tipodatos)",
			 "Indice_Borrado", "self.pagina->exists(self.pagina->selectByKind(Borrado).tipodatos=self.pagina->selectByKind(Indice).tipodatos)",
			 "Indice_Detalle", "self.pagina->exists(self.pagina->selectByKind(Detalle).tipodatos=self.pagina->selectByKind(Indice).tipodatos)"
		   });	
		addAnnotation
		  (preguntaCortaEClass, 
		   source, 
		   new String[] {
			 "respuesta_definida", "not self.respuesta->isEmpty()"
		   });
	}

	/**
	 * Initializes the annotations for <b>gmf.diagram</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createGmfAnnotations() {
		String source = "gmf.diagram";	
		addAnnotation
		  (webEClass, 
		   source, 
		   new String[] {
			 "diagram.extension", "dsl"
		   });
	}

	/**
	 * Initializes the annotations for <b>gmf.link</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createGmf_1Annotations() {
		String source = "gmf.link";	
		addAnnotation
		  (getPagina_Redes_sociales(), 
		   source, 
		   new String[] {
			 "label", "rs",
			 "source", "Pagina",
			 "target", "redes_sociales",
			 "width", "3",
			 "source.decoration", "arrow",
			 "target.decoration", "arrow",
			 "incoming", "true"
		   });	
		addAnnotation
		  (getPAGINAS_CRUD_Home(), 
		   source, 
		   new String[] {
			 "source", "Indice",
			 "target", "home",
			 "width", "3",
			 "source.decoration", "arrow",
			 "target.decoration", "arrow",
			 "Incoming", "true"
		   });	
		addAnnotation
		  (getPAGINAS_CRUD_Home(), 
		   source, 
		   new String[] {
			 "source", "Detalle",
			 "target", "home",
			 "width", "3",
			 "source.decoration", "arrow",
			 "target.decoration", "arrow",
			 "Incoming", "true"
		   });	
		addAnnotation
		  (getPAGINAS_CRUD_Home(), 
		   source, 
		   new String[] {
			 "source", "Creacion",
			 "target", "home",
			 "width", "3",
			 "source.decoration", "arrow",
			 "target.decoration", "arrow",
			 "Incoming", "true"
		   });	
		addAnnotation
		  (getPAGINAS_CRUD_Home(), 
		   source, 
		   new String[] {
			 "source", "Borrado",
			 "target", "home",
			 "width", "3",
			 "source.decoration", "arrow",
			 "target.decoration", "arrow",
			 "Incoming", "true"
		   });	
		addAnnotation
		  (getPAGINAS_CRUD_Tipodatos(), 
		   source, 
		   new String[] {
			 "source", "PAGINAS_CRUD",
			 "target", "tipodatos",
			 "width", "3",
			 "source.decoration", "arrow",
			 "target.decoration", "arrow",
			 "Incoming", "true"
		   });	
		addAnnotation
		  (getHome_Crud(), 
		   source, 
		   new String[] {
			 "source", "Home",
			 "target", "crud",
			 "width", "3",
			 "source.decoration", "arrow",
			 "target.decoration", "arrow",
			 "style", "dot",
			 "Incoming", "true"
		   });	
		addAnnotation
		  (getHome_Consulta(), 
		   source, 
		   new String[] {
			 "source", "Home",
			 "target", "consulta",
			 "width", "3",
			 "source.decoration", "arrow",
			 "target.decoration", "arrow",
			 "style", "dot",
			 "Incoming", "true"
		   });	
		addAnnotation
		  (getConsulta_Home(), 
		   source, 
		   new String[] {
			 "source", "Consulta",
			 "target", "home",
			 "width", "3",
			 "source.decoration", "arrow",
			 "target.decoration", "arrow",
			 "Incoming", "true"
		   });
	}

	/**
	 * Initializes the annotations for <b>gmf.node</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createGmf_2Annotations() {
		String source = "gmf.node";	
		addAnnotation
		  (usuarioEClass, 
		   source, 
		   new String[] {
			 "label", "usuario",
			 "border.color", "132,132,132",
			 "border.width", "3",
			 "color", "208,255,251",
			 "resizable", "true",
			 "border.stype", "solid"
		   });	
		addAnnotation
		  (twitterEClass, 
		   source, 
		   new String[] {
			 "label", "enlace",
			 "border.color", "132,132,132",
			 "border.width", "3",
			 "color", "208,255,251",
			 "resizable", "true",
			 "border.stype", "solid"
		   });	
		addAnnotation
		  (google_plusEClass, 
		   source, 
		   new String[] {
			 "label", "enlace",
			 "border.color", "132,132,132",
			 "border.width", "3",
			 "color", "208,255,251",
			 "resizable", "true",
			 "border.stype", "solid"
		   });	
		addAnnotation
		  (rssEClass, 
		   source, 
		   new String[] {
			 "label", "enlace",
			 "border.color", "132,132,132",
			 "border.width", "3",
			 "color", "208,255,251",
			 "resizable", "true",
			 "border.stype", "solid"
		   });	
		addAnnotation
		  (indiceEClass, 
		   source, 
		   new String[] {
			 "label", "titulo",
			 "border.color", "132,132,132",
			 "border.width", "3",
			 "color", "208,255,251",
			 "resizable", "true",
			 "border.stype", "solid"
		   });	
		addAnnotation
		  (detalleEClass, 
		   source, 
		   new String[] {
			 "label", "titulo",
			 "border.color", "132,132,132",
			 "border.width", "3",
			 "color", "208,255,251",
			 "resizable", "true",
			 "border.stype", "solid"
		   });	
		addAnnotation
		  (creacionEClass, 
		   source, 
		   new String[] {
			 "label", "titulo",
			 "border.color", "132,132,132",
			 "border.width", "3",
			 "color", "208,255,251",
			 "resizable", "true",
			 "border.stype", "solid"
		   });	
		addAnnotation
		  (borradoEClass, 
		   source, 
		   new String[] {
			 "label", "titulo",
			 "border.color", "132,132,132",
			 "border.width", "3",
			 "color", "208,255,251",
			 "resizable", "true",
			 "border.stype", "solid"
		   });	
		addAnnotation
		  (homeEClass, 
		   source, 
		   new String[] {
			 "label", "titulo",
			 "border.color", "132,132,132",
			 "border.width", "3",
			 "color", "208,255,251",
			 "resizable", "true",
			 "border.stype", "solid"
		   });	
		addAnnotation
		  (encuestaEClass, 
		   source, 
		   new String[] {
			 "label", "titulo",
			 "border.color", "132,132,132",
			 "border.width", "3",
			 "color", "208,255,251",
			 "resizable", "true",
			 "border.stype", "solid"
		   });	
		addAnnotation
		  (cuestionarioEClass, 
		   source, 
		   new String[] {
			 "label", "titulo",
			 "border.color", "132,132,132",
			 "border.width", "3",
			 "color", "208,255,251",
			 "resizable", "true",
			 "border.stype", "solid"
		   });	
		addAnnotation
		  (preguntaCortaEClass, 
		   source, 
		   new String[] {
			 "label", "tituloPregunta",
			 "border.color", "132,132,132",
			 "border.width", "3",
			 "color", "166,255,185",
			 "resizable", "true",
			 "border.stype", "solid"
		   });	
		addAnnotation
		  (seleccionEClass, 
		   source, 
		   new String[] {
			 "label", "tituloPregunta",
			 "border.color", "132,132,132",
			 "border.width", "3",
			 "color", "255,247,180",
			 "resizable", "true",
			 "border.stype", "solid"
		   });	
		addAnnotation
		  (voFEClass, 
		   source, 
		   new String[] {
			 "label", "tituloPregunta",
			 "border.color", "132,132,132",
			 "border.width", "3",
			 "color", "255,212,166",
			 "resizable", "true",
			 "border.stype", "solid"
		   });	
		addAnnotation
		  (opcionEClass, 
		   source, 
		   new String[] {
			 "label", "tituloPregunta",
			 "border.color", "132,132,132",
			 "border.width", "3",
			 "color", "255,182,183",
			 "resizable", "true",
			 "border.stype", "solid"
		   });	
		addAnnotation
		  (tipoDatosEClass, 
		   source, 
		   new String[] {
			 "label", "nombre",
			 "border.color", "132,132,132",
			 "border.width", "3",
			 "color", "208,255,251",
			 "resizable", "true",
			 "border.stype", "solid"
		   });	
		addAnnotation
		  (atributoEClass, 
		   source, 
		   new String[] {
			 "label", "nombre",
			 "border.color", "132,132,132",
			 "border.width", "3",
			 "color", "255,247,180",
			 "resizable", "true",
			 "border.stype", "solid"
		   });	
		addAnnotation
		  (crudEClass, 
		   source, 
		   new String[] {
			 "label", "titulo",
			 "border.color", "132,132,132",
			 "border.width", "3",
			 "color", "208,255,251",
			 "resizable", "true",
			 "border.stype", "solid"
		   });	
		addAnnotation
		  (updateEClass, 
		   source, 
		   new String[] {
			 "label", "titulo",
			 "border.color", "132,132,132",
			 "border.width", "3",
			 "color", "208,255,251",
			 "resizable", "true",
			 "border.stype", "solid"
		   });
	}

	/**
	 * Initializes the annotations for <b>gmf.compartment</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createGmf_3Annotations() {
		String source = "gmf.compartment";	
		addAnnotation
		  (getEncuesta_PreguntaEncuesta(), 
		   source, 
		   new String[] {
			 "layout", "free"
		   });	
		addAnnotation
		  (getCuestionario_PreguntaCuestionario(), 
		   source, 
		   new String[] {
			 "layout", "free"
		   });	
		addAnnotation
		  (getSeleccion_Opcion(), 
		   source, 
		   new String[] {
			 "layout", "free"
		   });	
		addAnnotation
		  (getTipoDatos_Atributo(), 
		   source, 
		   new String[] {
			 "layout", "free"
		   });
	}

} //Dsl_4webquizPackageImpl
