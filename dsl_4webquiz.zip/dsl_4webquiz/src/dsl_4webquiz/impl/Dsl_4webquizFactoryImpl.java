/**
 */
package dsl_4webquiz.impl;

import dsl_4webquiz.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class Dsl_4webquizFactoryImpl extends EFactoryImpl implements Dsl_4webquizFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static Dsl_4webquizFactory init() {
		try {
			Dsl_4webquizFactory theDsl_4webquizFactory = (Dsl_4webquizFactory)EPackage.Registry.INSTANCE.getEFactory(Dsl_4webquizPackage.eNS_URI);
			if (theDsl_4webquizFactory != null) {
				return theDsl_4webquizFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new Dsl_4webquizFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Dsl_4webquizFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case Dsl_4webquizPackage.WEB: return createWeb();
			case Dsl_4webquizPackage.USUARIO: return createUsuario();
			case Dsl_4webquizPackage.TWITTER: return createTwitter();
			case Dsl_4webquizPackage.GOOGLE_PLUS: return createGoogle_plus();
			case Dsl_4webquizPackage.RSS: return createRSS();
			case Dsl_4webquizPackage.INDICE: return createIndice();
			case Dsl_4webquizPackage.DETALLE: return createDetalle();
			case Dsl_4webquizPackage.CREACION: return createCreacion();
			case Dsl_4webquizPackage.BORRADO: return createBorrado();
			case Dsl_4webquizPackage.HOME: return createHome();
			case Dsl_4webquizPackage.ENCUESTA: return createEncuesta();
			case Dsl_4webquizPackage.CUESTIONARIO: return createCuestionario();
			case Dsl_4webquizPackage.PREGUNTA_CORTA: return createPreguntaCorta();
			case Dsl_4webquizPackage.SELECCION: return createSeleccion();
			case Dsl_4webquizPackage.VO_F: return createVoF();
			case Dsl_4webquizPackage.OPCION: return createOpcion();
			case Dsl_4webquizPackage.TIPO_DATOS: return createTipoDatos();
			case Dsl_4webquizPackage.ATRIBUTO: return createAtributo();
			case Dsl_4webquizPackage.CRUD: return createCRUD();
			case Dsl_4webquizPackage.UPDATE: return createUpdate();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
			case Dsl_4webquizPackage.TIPO_ATRIBUTOS:
				return createTipoAtributosFromString(eDataType, initialValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
			case Dsl_4webquizPackage.TIPO_ATRIBUTOS:
				return convertTipoAtributosToString(eDataType, instanceValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Web createWeb() {
		WebImpl web = new WebImpl();
		return web;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Usuario createUsuario() {
		UsuarioImpl usuario = new UsuarioImpl();
		return usuario;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Twitter createTwitter() {
		TwitterImpl twitter = new TwitterImpl();
		return twitter;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Google_plus createGoogle_plus() {
		Google_plusImpl google_plus = new Google_plusImpl();
		return google_plus;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RSS createRSS() {
		RSSImpl rss = new RSSImpl();
		return rss;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Indice createIndice() {
		IndiceImpl indice = new IndiceImpl();
		return indice;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Detalle createDetalle() {
		DetalleImpl detalle = new DetalleImpl();
		return detalle;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Creacion createCreacion() {
		CreacionImpl creacion = new CreacionImpl();
		return creacion;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Borrado createBorrado() {
		BorradoImpl borrado = new BorradoImpl();
		return borrado;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Home createHome() {
		HomeImpl home = new HomeImpl();
		return home;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Encuesta createEncuesta() {
		EncuestaImpl encuesta = new EncuestaImpl();
		return encuesta;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Cuestionario createCuestionario() {
		CuestionarioImpl cuestionario = new CuestionarioImpl();
		return cuestionario;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PreguntaCorta createPreguntaCorta() {
		PreguntaCortaImpl preguntaCorta = new PreguntaCortaImpl();
		return preguntaCorta;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Seleccion createSeleccion() {
		SeleccionImpl seleccion = new SeleccionImpl();
		return seleccion;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VoF createVoF() {
		VoFImpl voF = new VoFImpl();
		return voF;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Opcion createOpcion() {
		OpcionImpl opcion = new OpcionImpl();
		return opcion;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TipoDatos createTipoDatos() {
		TipoDatosImpl tipoDatos = new TipoDatosImpl();
		return tipoDatos;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Atributo createAtributo() {
		AtributoImpl atributo = new AtributoImpl();
		return atributo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CRUD createCRUD() {
		CRUDImpl crud = new CRUDImpl();
		return crud;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Update createUpdate() {
		UpdateImpl update = new UpdateImpl();
		return update;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TipoAtributos createTipoAtributosFromString(EDataType eDataType, String initialValue) {
		TipoAtributos result = TipoAtributos.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertTipoAtributosToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Dsl_4webquizPackage getDsl_4webquizPackage() {
		return (Dsl_4webquizPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static Dsl_4webquizPackage getPackage() {
		return Dsl_4webquizPackage.eINSTANCE;
	}

} //Dsl_4webquizFactoryImpl
