/**
 */
package dsl_4webquiz.impl;

import dsl_4webquiz.Dsl_4webquizPackage;
import dsl_4webquiz.Pagina;
import dsl_4webquiz.Redes_Sociales;
import dsl_4webquiz.TipoDatos;
import dsl_4webquiz.Usuario;
import dsl_4webquiz.Web;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Web</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link dsl_4webquiz.impl.WebImpl#getUsuario <em>Usuario</em>}</li>
 *   <li>{@link dsl_4webquiz.impl.WebImpl#getPagina <em>Pagina</em>}</li>
 *   <li>{@link dsl_4webquiz.impl.WebImpl#getRedes_sociales <em>Redes sociales</em>}</li>
 *   <li>{@link dsl_4webquiz.impl.WebImpl#getEntidad <em>Entidad</em>}</li>
 *   <li>{@link dsl_4webquiz.impl.WebImpl#getNombre <em>Nombre</em>}</li>
 *   <li>{@link dsl_4webquiz.impl.WebImpl#getUrl <em>Url</em>}</li>
 * </ul>
 *
 * @generated
 */
public class WebImpl extends EObjectImpl implements Web {
	/**
	 * The cached value of the '{@link #getUsuario() <em>Usuario</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUsuario()
	 * @generated
	 * @ordered
	 */
	protected EList<Usuario> usuario;

	/**
	 * The cached value of the '{@link #getPagina() <em>Pagina</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPagina()
	 * @generated
	 * @ordered
	 */
	protected EList<Pagina> pagina;

	/**
	 * The cached value of the '{@link #getRedes_sociales() <em>Redes sociales</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRedes_sociales()
	 * @generated
	 * @ordered
	 */
	protected EList<Redes_Sociales> redes_sociales;

	/**
	 * The cached value of the '{@link #getEntidad() <em>Entidad</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEntidad()
	 * @generated
	 * @ordered
	 */
	protected EList<TipoDatos> entidad;

	/**
	 * The default value of the '{@link #getNombre() <em>Nombre</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNombre()
	 * @generated
	 * @ordered
	 */
	protected static final String NOMBRE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNombre() <em>Nombre</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNombre()
	 * @generated
	 * @ordered
	 */
	protected String nombre = NOMBRE_EDEFAULT;

	/**
	 * The default value of the '{@link #getUrl() <em>Url</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUrl()
	 * @generated
	 * @ordered
	 */
	protected static final String URL_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getUrl() <em>Url</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUrl()
	 * @generated
	 * @ordered
	 */
	protected String url = URL_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected WebImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return Dsl_4webquizPackage.Literals.WEB;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Usuario> getUsuario() {
		if (usuario == null) {
			usuario = new EObjectContainmentEList<Usuario>(Usuario.class, this, Dsl_4webquizPackage.WEB__USUARIO);
		}
		return usuario;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Pagina> getPagina() {
		if (pagina == null) {
			pagina = new EObjectContainmentEList<Pagina>(Pagina.class, this, Dsl_4webquizPackage.WEB__PAGINA);
		}
		return pagina;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Redes_Sociales> getRedes_sociales() {
		if (redes_sociales == null) {
			redes_sociales = new EObjectContainmentEList<Redes_Sociales>(Redes_Sociales.class, this, Dsl_4webquizPackage.WEB__REDES_SOCIALES);
		}
		return redes_sociales;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<TipoDatos> getEntidad() {
		if (entidad == null) {
			entidad = new EObjectContainmentEList<TipoDatos>(TipoDatos.class, this, Dsl_4webquizPackage.WEB__ENTIDAD);
		}
		return entidad;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNombre(String newNombre) {
		String oldNombre = nombre;
		nombre = newNombre;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Dsl_4webquizPackage.WEB__NOMBRE, oldNombre, nombre));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setUrl(String newUrl) {
		String oldUrl = url;
		url = newUrl;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, Dsl_4webquizPackage.WEB__URL, oldUrl, url));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case Dsl_4webquizPackage.WEB__USUARIO:
				return ((InternalEList<?>)getUsuario()).basicRemove(otherEnd, msgs);
			case Dsl_4webquizPackage.WEB__PAGINA:
				return ((InternalEList<?>)getPagina()).basicRemove(otherEnd, msgs);
			case Dsl_4webquizPackage.WEB__REDES_SOCIALES:
				return ((InternalEList<?>)getRedes_sociales()).basicRemove(otherEnd, msgs);
			case Dsl_4webquizPackage.WEB__ENTIDAD:
				return ((InternalEList<?>)getEntidad()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case Dsl_4webquizPackage.WEB__USUARIO:
				return getUsuario();
			case Dsl_4webquizPackage.WEB__PAGINA:
				return getPagina();
			case Dsl_4webquizPackage.WEB__REDES_SOCIALES:
				return getRedes_sociales();
			case Dsl_4webquizPackage.WEB__ENTIDAD:
				return getEntidad();
			case Dsl_4webquizPackage.WEB__NOMBRE:
				return getNombre();
			case Dsl_4webquizPackage.WEB__URL:
				return getUrl();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case Dsl_4webquizPackage.WEB__USUARIO:
				getUsuario().clear();
				getUsuario().addAll((Collection<? extends Usuario>)newValue);
				return;
			case Dsl_4webquizPackage.WEB__PAGINA:
				getPagina().clear();
				getPagina().addAll((Collection<? extends Pagina>)newValue);
				return;
			case Dsl_4webquizPackage.WEB__REDES_SOCIALES:
				getRedes_sociales().clear();
				getRedes_sociales().addAll((Collection<? extends Redes_Sociales>)newValue);
				return;
			case Dsl_4webquizPackage.WEB__ENTIDAD:
				getEntidad().clear();
				getEntidad().addAll((Collection<? extends TipoDatos>)newValue);
				return;
			case Dsl_4webquizPackage.WEB__NOMBRE:
				setNombre((String)newValue);
				return;
			case Dsl_4webquizPackage.WEB__URL:
				setUrl((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case Dsl_4webquizPackage.WEB__USUARIO:
				getUsuario().clear();
				return;
			case Dsl_4webquizPackage.WEB__PAGINA:
				getPagina().clear();
				return;
			case Dsl_4webquizPackage.WEB__REDES_SOCIALES:
				getRedes_sociales().clear();
				return;
			case Dsl_4webquizPackage.WEB__ENTIDAD:
				getEntidad().clear();
				return;
			case Dsl_4webquizPackage.WEB__NOMBRE:
				setNombre(NOMBRE_EDEFAULT);
				return;
			case Dsl_4webquizPackage.WEB__URL:
				setUrl(URL_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case Dsl_4webquizPackage.WEB__USUARIO:
				return usuario != null && !usuario.isEmpty();
			case Dsl_4webquizPackage.WEB__PAGINA:
				return pagina != null && !pagina.isEmpty();
			case Dsl_4webquizPackage.WEB__REDES_SOCIALES:
				return redes_sociales != null && !redes_sociales.isEmpty();
			case Dsl_4webquizPackage.WEB__ENTIDAD:
				return entidad != null && !entidad.isEmpty();
			case Dsl_4webquizPackage.WEB__NOMBRE:
				return NOMBRE_EDEFAULT == null ? nombre != null : !NOMBRE_EDEFAULT.equals(nombre);
			case Dsl_4webquizPackage.WEB__URL:
				return URL_EDEFAULT == null ? url != null : !URL_EDEFAULT.equals(url);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (nombre: ");
		result.append(nombre);
		result.append(", url: ");
		result.append(url);
		result.append(')');
		return result.toString();
	}

} //WebImpl
