/**
 */
package dsl_4webquiz.util;

import dsl_4webquiz.*;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see dsl_4webquiz.Dsl_4webquizPackage
 * @generated
 */
public class Dsl_4webquizSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static Dsl_4webquizPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Dsl_4webquizSwitch() {
		if (modelPackage == null) {
			modelPackage = Dsl_4webquizPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
			case Dsl_4webquizPackage.WEB: {
				Web web = (Web)theEObject;
				T result = caseWeb(web);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case Dsl_4webquizPackage.PAGINA: {
				Pagina pagina = (Pagina)theEObject;
				T result = casePagina(pagina);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case Dsl_4webquizPackage.REDES_SOCIALES: {
				Redes_Sociales redes_Sociales = (Redes_Sociales)theEObject;
				T result = caseRedes_Sociales(redes_Sociales);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case Dsl_4webquizPackage.USUARIO: {
				Usuario usuario = (Usuario)theEObject;
				T result = caseUsuario(usuario);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case Dsl_4webquizPackage.TWITTER: {
				Twitter twitter = (Twitter)theEObject;
				T result = caseTwitter(twitter);
				if (result == null) result = caseRedes_Sociales(twitter);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case Dsl_4webquizPackage.GOOGLE_PLUS: {
				Google_plus google_plus = (Google_plus)theEObject;
				T result = caseGoogle_plus(google_plus);
				if (result == null) result = caseRedes_Sociales(google_plus);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case Dsl_4webquizPackage.RSS: {
				RSS rss = (RSS)theEObject;
				T result = caseRSS(rss);
				if (result == null) result = caseRedes_Sociales(rss);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case Dsl_4webquizPackage.PAGINAS_CRUD: {
				PAGINAS_CRUD paginaS_CRUD = (PAGINAS_CRUD)theEObject;
				T result = casePAGINAS_CRUD(paginaS_CRUD);
				if (result == null) result = casePagina(paginaS_CRUD);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case Dsl_4webquizPackage.INDICE: {
				Indice indice = (Indice)theEObject;
				T result = caseIndice(indice);
				if (result == null) result = casePAGINAS_CRUD(indice);
				if (result == null) result = casePagina(indice);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case Dsl_4webquizPackage.DETALLE: {
				Detalle detalle = (Detalle)theEObject;
				T result = caseDetalle(detalle);
				if (result == null) result = casePAGINAS_CRUD(detalle);
				if (result == null) result = casePagina(detalle);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case Dsl_4webquizPackage.CREACION: {
				Creacion creacion = (Creacion)theEObject;
				T result = caseCreacion(creacion);
				if (result == null) result = casePAGINAS_CRUD(creacion);
				if (result == null) result = casePagina(creacion);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case Dsl_4webquizPackage.BORRADO: {
				Borrado borrado = (Borrado)theEObject;
				T result = caseBorrado(borrado);
				if (result == null) result = casePAGINAS_CRUD(borrado);
				if (result == null) result = casePagina(borrado);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case Dsl_4webquizPackage.HOME: {
				Home home = (Home)theEObject;
				T result = caseHome(home);
				if (result == null) result = casePagina(home);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case Dsl_4webquizPackage.CONSULTA: {
				Consulta consulta = (Consulta)theEObject;
				T result = caseConsulta(consulta);
				if (result == null) result = casePagina(consulta);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case Dsl_4webquizPackage.ENCUESTA: {
				Encuesta encuesta = (Encuesta)theEObject;
				T result = caseEncuesta(encuesta);
				if (result == null) result = caseConsulta(encuesta);
				if (result == null) result = casePagina(encuesta);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case Dsl_4webquizPackage.CUESTIONARIO: {
				Cuestionario cuestionario = (Cuestionario)theEObject;
				T result = caseCuestionario(cuestionario);
				if (result == null) result = caseConsulta(cuestionario);
				if (result == null) result = casePagina(cuestionario);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case Dsl_4webquizPackage.PREGUNTA_CORTA: {
				PreguntaCorta preguntaCorta = (PreguntaCorta)theEObject;
				T result = casePreguntaCorta(preguntaCorta);
				if (result == null) result = casePregunta(preguntaCorta);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case Dsl_4webquizPackage.SELECCION: {
				Seleccion seleccion = (Seleccion)theEObject;
				T result = caseSeleccion(seleccion);
				if (result == null) result = casePregunta(seleccion);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case Dsl_4webquizPackage.PREGUNTA: {
				Pregunta pregunta = (Pregunta)theEObject;
				T result = casePregunta(pregunta);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case Dsl_4webquizPackage.VO_F: {
				VoF voF = (VoF)theEObject;
				T result = caseVoF(voF);
				if (result == null) result = casePregunta(voF);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case Dsl_4webquizPackage.OPCION: {
				Opcion opcion = (Opcion)theEObject;
				T result = caseOpcion(opcion);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case Dsl_4webquizPackage.TIPO_DATOS: {
				TipoDatos tipoDatos = (TipoDatos)theEObject;
				T result = caseTipoDatos(tipoDatos);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case Dsl_4webquizPackage.ATRIBUTO: {
				Atributo atributo = (Atributo)theEObject;
				T result = caseAtributo(atributo);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case Dsl_4webquizPackage.CRUD: {
				CRUD crud = (CRUD)theEObject;
				T result = caseCRUD(crud);
				if (result == null) result = casePAGINAS_CRUD(crud);
				if (result == null) result = casePagina(crud);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case Dsl_4webquizPackage.UPDATE: {
				Update update = (Update)theEObject;
				T result = caseUpdate(update);
				if (result == null) result = casePAGINAS_CRUD(update);
				if (result == null) result = casePagina(update);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			default: return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Web</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Web</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseWeb(Web object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Pagina</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Pagina</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePagina(Pagina object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Redes Sociales</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Redes Sociales</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseRedes_Sociales(Redes_Sociales object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Usuario</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Usuario</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseUsuario(Usuario object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Twitter</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Twitter</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTwitter(Twitter object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Google plus</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Google plus</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseGoogle_plus(Google_plus object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>RSS</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>RSS</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseRSS(RSS object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>PAGINAS CRUD</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>PAGINAS CRUD</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePAGINAS_CRUD(PAGINAS_CRUD object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Indice</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Indice</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseIndice(Indice object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Detalle</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Detalle</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDetalle(Detalle object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Creacion</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Creacion</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCreacion(Creacion object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Borrado</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Borrado</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseBorrado(Borrado object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Home</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Home</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseHome(Home object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Consulta</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Consulta</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseConsulta(Consulta object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Encuesta</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Encuesta</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseEncuesta(Encuesta object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Cuestionario</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Cuestionario</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCuestionario(Cuestionario object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Pregunta Corta</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Pregunta Corta</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePreguntaCorta(PreguntaCorta object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Seleccion</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Seleccion</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSeleccion(Seleccion object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Pregunta</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Pregunta</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePregunta(Pregunta object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Vo F</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Vo F</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseVoF(VoF object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Opcion</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Opcion</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseOpcion(Opcion object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Tipo Datos</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Tipo Datos</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTipoDatos(TipoDatos object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Atributo</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Atributo</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAtributo(Atributo object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>CRUD</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>CRUD</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCRUD(CRUD object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Update</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Update</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseUpdate(Update object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //Dsl_4webquizSwitch
