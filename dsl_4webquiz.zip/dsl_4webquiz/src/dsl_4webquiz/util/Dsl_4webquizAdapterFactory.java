/**
 */
package dsl_4webquiz.util;

import dsl_4webquiz.*;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see dsl_4webquiz.Dsl_4webquizPackage
 * @generated
 */
public class Dsl_4webquizAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static Dsl_4webquizPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Dsl_4webquizAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = Dsl_4webquizPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject)object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Dsl_4webquizSwitch<Adapter> modelSwitch =
		new Dsl_4webquizSwitch<Adapter>() {
			@Override
			public Adapter caseWeb(Web object) {
				return createWebAdapter();
			}
			@Override
			public Adapter casePagina(Pagina object) {
				return createPaginaAdapter();
			}
			@Override
			public Adapter caseRedes_Sociales(Redes_Sociales object) {
				return createRedes_SocialesAdapter();
			}
			@Override
			public Adapter caseUsuario(Usuario object) {
				return createUsuarioAdapter();
			}
			@Override
			public Adapter caseTwitter(Twitter object) {
				return createTwitterAdapter();
			}
			@Override
			public Adapter caseGoogle_plus(Google_plus object) {
				return createGoogle_plusAdapter();
			}
			@Override
			public Adapter caseRSS(RSS object) {
				return createRSSAdapter();
			}
			@Override
			public Adapter casePAGINAS_CRUD(PAGINAS_CRUD object) {
				return createPAGINAS_CRUDAdapter();
			}
			@Override
			public Adapter caseIndice(Indice object) {
				return createIndiceAdapter();
			}
			@Override
			public Adapter caseDetalle(Detalle object) {
				return createDetalleAdapter();
			}
			@Override
			public Adapter caseCreacion(Creacion object) {
				return createCreacionAdapter();
			}
			@Override
			public Adapter caseBorrado(Borrado object) {
				return createBorradoAdapter();
			}
			@Override
			public Adapter caseHome(Home object) {
				return createHomeAdapter();
			}
			@Override
			public Adapter caseConsulta(Consulta object) {
				return createConsultaAdapter();
			}
			@Override
			public Adapter caseEncuesta(Encuesta object) {
				return createEncuestaAdapter();
			}
			@Override
			public Adapter caseCuestionario(Cuestionario object) {
				return createCuestionarioAdapter();
			}
			@Override
			public Adapter casePreguntaCorta(PreguntaCorta object) {
				return createPreguntaCortaAdapter();
			}
			@Override
			public Adapter caseSeleccion(Seleccion object) {
				return createSeleccionAdapter();
			}
			@Override
			public Adapter casePregunta(Pregunta object) {
				return createPreguntaAdapter();
			}
			@Override
			public Adapter caseVoF(VoF object) {
				return createVoFAdapter();
			}
			@Override
			public Adapter caseOpcion(Opcion object) {
				return createOpcionAdapter();
			}
			@Override
			public Adapter caseTipoDatos(TipoDatos object) {
				return createTipoDatosAdapter();
			}
			@Override
			public Adapter caseAtributo(Atributo object) {
				return createAtributoAdapter();
			}
			@Override
			public Adapter caseCRUD(CRUD object) {
				return createCRUDAdapter();
			}
			@Override
			public Adapter caseUpdate(Update object) {
				return createUpdateAdapter();
			}
			@Override
			public Adapter defaultCase(EObject object) {
				return createEObjectAdapter();
			}
		};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject)target);
	}


	/**
	 * Creates a new adapter for an object of class '{@link dsl_4webquiz.Web <em>Web</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dsl_4webquiz.Web
	 * @generated
	 */
	public Adapter createWebAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dsl_4webquiz.Pagina <em>Pagina</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dsl_4webquiz.Pagina
	 * @generated
	 */
	public Adapter createPaginaAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dsl_4webquiz.Redes_Sociales <em>Redes Sociales</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dsl_4webquiz.Redes_Sociales
	 * @generated
	 */
	public Adapter createRedes_SocialesAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dsl_4webquiz.Usuario <em>Usuario</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dsl_4webquiz.Usuario
	 * @generated
	 */
	public Adapter createUsuarioAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dsl_4webquiz.Twitter <em>Twitter</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dsl_4webquiz.Twitter
	 * @generated
	 */
	public Adapter createTwitterAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dsl_4webquiz.Google_plus <em>Google plus</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dsl_4webquiz.Google_plus
	 * @generated
	 */
	public Adapter createGoogle_plusAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dsl_4webquiz.RSS <em>RSS</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dsl_4webquiz.RSS
	 * @generated
	 */
	public Adapter createRSSAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dsl_4webquiz.PAGINAS_CRUD <em>PAGINAS CRUD</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dsl_4webquiz.PAGINAS_CRUD
	 * @generated
	 */
	public Adapter createPAGINAS_CRUDAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dsl_4webquiz.Indice <em>Indice</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dsl_4webquiz.Indice
	 * @generated
	 */
	public Adapter createIndiceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dsl_4webquiz.Detalle <em>Detalle</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dsl_4webquiz.Detalle
	 * @generated
	 */
	public Adapter createDetalleAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dsl_4webquiz.Creacion <em>Creacion</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dsl_4webquiz.Creacion
	 * @generated
	 */
	public Adapter createCreacionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dsl_4webquiz.Borrado <em>Borrado</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dsl_4webquiz.Borrado
	 * @generated
	 */
	public Adapter createBorradoAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dsl_4webquiz.Home <em>Home</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dsl_4webquiz.Home
	 * @generated
	 */
	public Adapter createHomeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dsl_4webquiz.Consulta <em>Consulta</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dsl_4webquiz.Consulta
	 * @generated
	 */
	public Adapter createConsultaAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dsl_4webquiz.Encuesta <em>Encuesta</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dsl_4webquiz.Encuesta
	 * @generated
	 */
	public Adapter createEncuestaAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dsl_4webquiz.Cuestionario <em>Cuestionario</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dsl_4webquiz.Cuestionario
	 * @generated
	 */
	public Adapter createCuestionarioAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dsl_4webquiz.PreguntaCorta <em>Pregunta Corta</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dsl_4webquiz.PreguntaCorta
	 * @generated
	 */
	public Adapter createPreguntaCortaAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dsl_4webquiz.Seleccion <em>Seleccion</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dsl_4webquiz.Seleccion
	 * @generated
	 */
	public Adapter createSeleccionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dsl_4webquiz.Pregunta <em>Pregunta</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dsl_4webquiz.Pregunta
	 * @generated
	 */
	public Adapter createPreguntaAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dsl_4webquiz.VoF <em>Vo F</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dsl_4webquiz.VoF
	 * @generated
	 */
	public Adapter createVoFAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dsl_4webquiz.Opcion <em>Opcion</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dsl_4webquiz.Opcion
	 * @generated
	 */
	public Adapter createOpcionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dsl_4webquiz.TipoDatos <em>Tipo Datos</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dsl_4webquiz.TipoDatos
	 * @generated
	 */
	public Adapter createTipoDatosAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dsl_4webquiz.Atributo <em>Atributo</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dsl_4webquiz.Atributo
	 * @generated
	 */
	public Adapter createAtributoAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dsl_4webquiz.CRUD <em>CRUD</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dsl_4webquiz.CRUD
	 * @generated
	 */
	public Adapter createCRUDAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dsl_4webquiz.Update <em>Update</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dsl_4webquiz.Update
	 * @generated
	 */
	public Adapter createUpdateAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //Dsl_4webquizAdapterFactory
