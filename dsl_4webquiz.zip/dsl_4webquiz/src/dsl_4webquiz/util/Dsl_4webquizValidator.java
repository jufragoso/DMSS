/**
 */
package dsl_4webquiz.util;

import dsl_4webquiz.*;

import java.util.Map;

import org.eclipse.emf.common.util.Diagnostic;
import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.EObjectValidator;

/**
 * <!-- begin-user-doc -->
 * The <b>Validator</b> for the model.
 * <!-- end-user-doc -->
 * @see dsl_4webquiz.Dsl_4webquizPackage
 * @generated
 */
public class Dsl_4webquizValidator extends EObjectValidator {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final Dsl_4webquizValidator INSTANCE = new Dsl_4webquizValidator();

	/**
	 * A constant for the {@link org.eclipse.emf.common.util.Diagnostic#getSource() source} of diagnostic {@link org.eclipse.emf.common.util.Diagnostic#getCode() codes} from this package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.common.util.Diagnostic#getSource()
	 * @see org.eclipse.emf.common.util.Diagnostic#getCode()
	 * @generated
	 */
	public static final String DIAGNOSTIC_SOURCE = "dsl_4webquiz";

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final int GENERATED_DIAGNOSTIC_CODE_COUNT = 0;

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants in a derived class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final int DIAGNOSTIC_CODE_COUNT = GENERATED_DIAGNOSTIC_CODE_COUNT;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Dsl_4webquizValidator() {
		super();
	}

	/**
	 * Returns the package of this validator switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EPackage getEPackage() {
	  return Dsl_4webquizPackage.eINSTANCE;
	}

	/**
	 * Calls <code>validateXXX</code> for the corresponding classifier of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean validate(int classifierID, Object value, DiagnosticChain diagnostics, Map<Object, Object> context) {
		switch (classifierID) {
			case Dsl_4webquizPackage.WEB:
				return validateWeb((Web)value, diagnostics, context);
			case Dsl_4webquizPackage.PAGINA:
				return validatePagina((Pagina)value, diagnostics, context);
			case Dsl_4webquizPackage.REDES_SOCIALES:
				return validateRedes_Sociales((Redes_Sociales)value, diagnostics, context);
			case Dsl_4webquizPackage.USUARIO:
				return validateUsuario((Usuario)value, diagnostics, context);
			case Dsl_4webquizPackage.TWITTER:
				return validateTwitter((Twitter)value, diagnostics, context);
			case Dsl_4webquizPackage.GOOGLE_PLUS:
				return validateGoogle_plus((Google_plus)value, diagnostics, context);
			case Dsl_4webquizPackage.RSS:
				return validateRSS((RSS)value, diagnostics, context);
			case Dsl_4webquizPackage.PAGINAS_CRUD:
				return validatePAGINAS_CRUD((PAGINAS_CRUD)value, diagnostics, context);
			case Dsl_4webquizPackage.INDICE:
				return validateIndice((Indice)value, diagnostics, context);
			case Dsl_4webquizPackage.DETALLE:
				return validateDetalle((Detalle)value, diagnostics, context);
			case Dsl_4webquizPackage.CREACION:
				return validateCreacion((Creacion)value, diagnostics, context);
			case Dsl_4webquizPackage.BORRADO:
				return validateBorrado((Borrado)value, diagnostics, context);
			case Dsl_4webquizPackage.HOME:
				return validateHome((Home)value, diagnostics, context);
			case Dsl_4webquizPackage.CONSULTA:
				return validateConsulta((Consulta)value, diagnostics, context);
			case Dsl_4webquizPackage.ENCUESTA:
				return validateEncuesta((Encuesta)value, diagnostics, context);
			case Dsl_4webquizPackage.CUESTIONARIO:
				return validateCuestionario((Cuestionario)value, diagnostics, context);
			case Dsl_4webquizPackage.PREGUNTA_CORTA:
				return validatePreguntaCorta((PreguntaCorta)value, diagnostics, context);
			case Dsl_4webquizPackage.SELECCION:
				return validateSeleccion((Seleccion)value, diagnostics, context);
			case Dsl_4webquizPackage.PREGUNTA:
				return validatePregunta((Pregunta)value, diagnostics, context);
			case Dsl_4webquizPackage.VO_F:
				return validateVoF((VoF)value, diagnostics, context);
			case Dsl_4webquizPackage.OPCION:
				return validateOpcion((Opcion)value, diagnostics, context);
			case Dsl_4webquizPackage.TIPO_DATOS:
				return validateTipoDatos((TipoDatos)value, diagnostics, context);
			case Dsl_4webquizPackage.ATRIBUTO:
				return validateAtributo((Atributo)value, diagnostics, context);
			case Dsl_4webquizPackage.CRUD:
				return validateCRUD((CRUD)value, diagnostics, context);
			case Dsl_4webquizPackage.UPDATE:
				return validateUpdate((Update)value, diagnostics, context);
			case Dsl_4webquizPackage.TIPO_ATRIBUTOS:
				return validateTipoAtributos((TipoAtributos)value, diagnostics, context);
			default:
				return true;
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateWeb(Web web, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(web, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(web, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(web, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(web, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(web, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(web, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(web, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(web, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(web, diagnostics, context);
		if (result || diagnostics != null) result &= validateWeb_num_Home(web, diagnostics, context);
		if (result || diagnostics != null) result &= validateWeb_num_RedesSociales(web, diagnostics, context);
		if (result || diagnostics != null) result &= validateWeb_num_Encuestas(web, diagnostics, context);
		if (result || diagnostics != null) result &= validateWeb_num_Cuestionarios(web, diagnostics, context);
		if (result || diagnostics != null) result &= validateWeb_includesCrud(web, diagnostics, context);
		if (result || diagnostics != null) result &= validateWeb_includesConsulta(web, diagnostics, context);
		if (result || diagnostics != null) result &= validateWeb_CRUD_Unico(web, diagnostics, context);
		if (result || diagnostics != null) result &= validateWeb_Indice_Update(web, diagnostics, context);
		if (result || diagnostics != null) result &= validateWeb_Indice_Creacion(web, diagnostics, context);
		if (result || diagnostics != null) result &= validateWeb_Indice_Borrado(web, diagnostics, context);
		if (result || diagnostics != null) result &= validateWeb_Indice_Detalle(web, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the num_Home constraint of '<em>Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String WEB__NUM_HOME__EEXPRESSION = "self.pagina->selectByType(Home)->size() =1";

	/**
	 * Validates the num_Home constraint of '<em>Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateWeb_num_Home(Web web, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(Dsl_4webquizPackage.Literals.WEB,
				 web,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "num_Home",
				 WEB__NUM_HOME__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the num_RedesSociales constraint of '<em>Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String WEB__NUM_REDES_SOCIALES__EEXPRESSION = "self.redes_sociales->size()>0";

	/**
	 * Validates the num_RedesSociales constraint of '<em>Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateWeb_num_RedesSociales(Web web, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(Dsl_4webquizPackage.Literals.WEB,
				 web,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "num_RedesSociales",
				 WEB__NUM_REDES_SOCIALES__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the num_Encuestas constraint of '<em>Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String WEB__NUM_ENCUESTAS__EEXPRESSION = "self.pagina->selectByKind(Consulta)->selectByType(Encuesta)->size()>0";

	/**
	 * Validates the num_Encuestas constraint of '<em>Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateWeb_num_Encuestas(Web web, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(Dsl_4webquizPackage.Literals.WEB,
				 web,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "num_Encuestas",
				 WEB__NUM_ENCUESTAS__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the num_Cuestionarios constraint of '<em>Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String WEB__NUM_CUESTIONARIOS__EEXPRESSION = "self.pagina->selectByKind(Consulta)->selectByType(Cuestionario)->size()>0";

	/**
	 * Validates the num_Cuestionarios constraint of '<em>Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateWeb_num_Cuestionarios(Web web, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(Dsl_4webquizPackage.Literals.WEB,
				 web,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "num_Cuestionarios",
				 WEB__NUM_CUESTIONARIOS__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the includesCrud constraint of '<em>Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String WEB__INCLUDES_CRUD__EEXPRESSION = "self.pagina->selectByKind(Home).crud->includesAll(self.pagina->selectByKind(PAGINAS_CRUD))";

	/**
	 * Validates the includesCrud constraint of '<em>Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateWeb_includesCrud(Web web, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(Dsl_4webquizPackage.Literals.WEB,
				 web,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "includesCrud",
				 WEB__INCLUDES_CRUD__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the includesConsulta constraint of '<em>Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String WEB__INCLUDES_CONSULTA__EEXPRESSION = "self.pagina->selectByKind(Home).consulta->includesAll(self.pagina->selectByKind(Consulta))";

	/**
	 * Validates the includesConsulta constraint of '<em>Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateWeb_includesConsulta(Web web, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(Dsl_4webquizPackage.Literals.WEB,
				 web,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "includesConsulta",
				 WEB__INCLUDES_CONSULTA__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the CRUD_Unico constraint of '<em>Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String WEB__CRUD_UNICO__EEXPRESSION = "self.pagina->selectByKind(CRUD).tipodatos->asSet()->excludesAll(self.pagina->selectByKind(Indice).tipodatos->union(self.pagina->selectByKind(Creacion).tipodatos)->union(self.pagina->selectByKind(Detalle).tipodatos)->union(self.pagina->selectByKind(Borrado).tipodatos)->asSet())";

	/**
	 * Validates the CRUD_Unico constraint of '<em>Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateWeb_CRUD_Unico(Web web, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(Dsl_4webquizPackage.Literals.WEB,
				 web,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "CRUD_Unico",
				 WEB__CRUD_UNICO__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the Indice_Update constraint of '<em>Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String WEB__INDICE_UPDATE__EEXPRESSION = "self.pagina->exists(self.pagina->selectByKind(Update).tipodatos=self.pagina->selectByKind(Indice).tipodatos)";

	/**
	 * Validates the Indice_Update constraint of '<em>Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateWeb_Indice_Update(Web web, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(Dsl_4webquizPackage.Literals.WEB,
				 web,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "Indice_Update",
				 WEB__INDICE_UPDATE__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the Indice_Creacion constraint of '<em>Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String WEB__INDICE_CREACION__EEXPRESSION = "self.pagina->exists(self.pagina->selectByKind(Creacion).tipodatos=self.pagina->selectByKind(Indice).tipodatos)";

	/**
	 * Validates the Indice_Creacion constraint of '<em>Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateWeb_Indice_Creacion(Web web, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(Dsl_4webquizPackage.Literals.WEB,
				 web,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "Indice_Creacion",
				 WEB__INDICE_CREACION__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the Indice_Borrado constraint of '<em>Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String WEB__INDICE_BORRADO__EEXPRESSION = "self.pagina->exists(self.pagina->selectByKind(Borrado).tipodatos=self.pagina->selectByKind(Indice).tipodatos)";

	/**
	 * Validates the Indice_Borrado constraint of '<em>Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateWeb_Indice_Borrado(Web web, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(Dsl_4webquizPackage.Literals.WEB,
				 web,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "Indice_Borrado",
				 WEB__INDICE_BORRADO__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the Indice_Detalle constraint of '<em>Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String WEB__INDICE_DETALLE__EEXPRESSION = "self.pagina->exists(self.pagina->selectByKind(Detalle).tipodatos=self.pagina->selectByKind(Indice).tipodatos)";

	/**
	 * Validates the Indice_Detalle constraint of '<em>Web</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateWeb_Indice_Detalle(Web web, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(Dsl_4webquizPackage.Literals.WEB,
				 web,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "Indice_Detalle",
				 WEB__INDICE_DETALLE__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePagina(Pagina pagina, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(pagina, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateRedes_Sociales(Redes_Sociales redes_Sociales, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(redes_Sociales, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateUsuario(Usuario usuario, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(usuario, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTwitter(Twitter twitter, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(twitter, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateGoogle_plus(Google_plus google_plus, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(google_plus, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateRSS(RSS rss, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(rss, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePAGINAS_CRUD(PAGINAS_CRUD paginaS_CRUD, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(paginaS_CRUD, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateIndice(Indice indice, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(indice, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateDetalle(Detalle detalle, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(detalle, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCreacion(Creacion creacion, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(creacion, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateBorrado(Borrado borrado, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(borrado, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateHome(Home home, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(home, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateConsulta(Consulta consulta, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(consulta, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateEncuesta(Encuesta encuesta, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(encuesta, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCuestionario(Cuestionario cuestionario, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(cuestionario, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePreguntaCorta(PreguntaCorta preguntaCorta, DiagnosticChain diagnostics, Map<Object, Object> context) {
		if (!validate_NoCircularContainment(preguntaCorta, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(preguntaCorta, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(preguntaCorta, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(preguntaCorta, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(preguntaCorta, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(preguntaCorta, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(preguntaCorta, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(preguntaCorta, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(preguntaCorta, diagnostics, context);
		if (result || diagnostics != null) result &= validatePreguntaCorta_respuesta_definida(preguntaCorta, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the respuesta_definida constraint of '<em>Pregunta Corta</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String PREGUNTA_CORTA__RESPUESTA_DEFINIDA__EEXPRESSION = "not self.respuesta->isEmpty()";

	/**
	 * Validates the respuesta_definida constraint of '<em>Pregunta Corta</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePreguntaCorta_respuesta_definida(PreguntaCorta preguntaCorta, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return
			validate
				(Dsl_4webquizPackage.Literals.PREGUNTA_CORTA,
				 preguntaCorta,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "respuesta_definida",
				 PREGUNTA_CORTA__RESPUESTA_DEFINIDA__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateSeleccion(Seleccion seleccion, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(seleccion, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validatePregunta(Pregunta pregunta, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(pregunta, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateVoF(VoF voF, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(voF, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateOpcion(Opcion opcion, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(opcion, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTipoDatos(TipoDatos tipoDatos, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(tipoDatos, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateAtributo(Atributo atributo, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(atributo, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCRUD(CRUD crud, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(crud, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateUpdate(Update update, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return validate_EveryDefaultConstraint(update, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateTipoAtributos(TipoAtributos tipoAtributos, DiagnosticChain diagnostics, Map<Object, Object> context) {
		return true;
	}

	/**
	 * Returns the resource locator that will be used to fetch messages for this validator's diagnostics.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator() {
		// TODO
		// Specialize this to return a resource locator for messages specific to this validator.
		// Ensure that you remove @generated or mark it @generated NOT
		return super.getResourceLocator();
	}

} //Dsl_4webquizValidator
