/**
 */
package dsl_4webquiz;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Encuesta</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dsl_4webquiz.Encuesta#getPreguntaEncuesta <em>Pregunta Encuesta</em>}</li>
 * </ul>
 *
 * @see dsl_4webquiz.Dsl_4webquizPackage#getEncuesta()
 * @model annotation="gmf.node label='titulo' border.color='132,132,132' border.width='3' color='208,255,251' resizable='true' border.stype='solid'"
 * @generated
 */
public interface Encuesta extends Consulta {
	/**
	 * Returns the value of the '<em><b>Pregunta Encuesta</b></em>' containment reference list.
	 * The list contents are of type {@link dsl_4webquiz.Pregunta}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Pregunta Encuesta</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pregunta Encuesta</em>' containment reference list.
	 * @see dsl_4webquiz.Dsl_4webquizPackage#getEncuesta_PreguntaEncuesta()
	 * @model containment="true" required="true"
	 *        annotation="gmf.compartment layout='free'"
	 * @generated
	 */
	EList<Pregunta> getPreguntaEncuesta();

} // Encuesta
