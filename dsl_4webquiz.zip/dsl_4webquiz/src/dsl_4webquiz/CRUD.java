/**
 */
package dsl_4webquiz;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>CRUD</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see dsl_4webquiz.Dsl_4webquizPackage#getCRUD()
 * @model annotation="gmf.node label='titulo' border.color='132,132,132' border.width='3' color='208,255,251' resizable='true' border.stype='solid'"
 * @generated
 */
public interface CRUD extends PAGINAS_CRUD {
} // CRUD
