/**
 */
package dsl_4webquiz;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Vo F</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dsl_4webquiz.VoF#isCorrecta <em>Correcta</em>}</li>
 * </ul>
 *
 * @see dsl_4webquiz.Dsl_4webquizPackage#getVoF()
 * @model annotation="gmf.node label='tituloPregunta' border.color='132,132,132' border.width='3' color='255,212,166' resizable='true' border.stype='solid'"
 * @generated
 */
public interface VoF extends Pregunta {
	/**
	 * Returns the value of the '<em><b>Correcta</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Correcta</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Correcta</em>' attribute.
	 * @see #setCorrecta(boolean)
	 * @see dsl_4webquiz.Dsl_4webquizPackage#getVoF_Correcta()
	 * @model
	 * @generated
	 */
	boolean isCorrecta();

	/**
	 * Sets the value of the '{@link dsl_4webquiz.VoF#isCorrecta <em>Correcta</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Correcta</em>' attribute.
	 * @see #isCorrecta()
	 * @generated
	 */
	void setCorrecta(boolean value);

} // VoF
