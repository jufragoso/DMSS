/*
* 
*/
package dsl_4webquiz.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.commands.DestroyReferenceCommand;
import org.eclipse.gmf.runtime.emf.type.core.requests.DestroyReferenceRequest;

/**
 * @generated
 */
public class PaginaRedes_socialesItemSemanticEditPolicy
		extends dsl_4webquiz.diagram.edit.policies.Dsl_4webquizBaseItemSemanticEditPolicy {

	/**
	* @generated
	*/
	public PaginaRedes_socialesItemSemanticEditPolicy() {
		super(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PaginaRedes_sociales_4001);
	}

	/**
	* @generated
	*/
	protected Command getDestroyReferenceCommand(DestroyReferenceRequest req) {
		return getGEFWrapper(new DestroyReferenceCommand(req));
	}

}
