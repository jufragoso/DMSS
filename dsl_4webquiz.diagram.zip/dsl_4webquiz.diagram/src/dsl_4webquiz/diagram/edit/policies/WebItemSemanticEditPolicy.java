/*
* 
*/
package dsl_4webquiz.diagram.edit.policies;

import org.eclipse.emf.transaction.TransactionalEditingDomain;
import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.diagram.ui.editparts.IGraphicalEditPart;
import org.eclipse.gmf.runtime.emf.commands.core.commands.DuplicateEObjectsCommand;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;
import org.eclipse.gmf.runtime.emf.type.core.requests.DuplicateElementsRequest;

/**
 * @generated
 */
public class WebItemSemanticEditPolicy
		extends dsl_4webquiz.diagram.edit.policies.Dsl_4webquizBaseItemSemanticEditPolicy {

	/**
	* @generated
	*/
	public WebItemSemanticEditPolicy() {
		super(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Web_1000);
	}

	/**
	* @generated
	*/
	protected Command getCreateCommand(CreateElementRequest req) {
		if (dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Indice_2001 == req.getElementType()) {
			return getGEFWrapper(new dsl_4webquiz.diagram.edit.commands.IndiceCreateCommand(req));
		}
		if (dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Detalle_2002 == req.getElementType()) {
			return getGEFWrapper(new dsl_4webquiz.diagram.edit.commands.DetalleCreateCommand(req));
		}
		if (dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Creacion_2003 == req.getElementType()) {
			return getGEFWrapper(new dsl_4webquiz.diagram.edit.commands.CreacionCreateCommand(req));
		}
		if (dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Borrado_2004 == req.getElementType()) {
			return getGEFWrapper(new dsl_4webquiz.diagram.edit.commands.BorradoCreateCommand(req));
		}
		if (dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Encuesta_2005 == req.getElementType()) {
			return getGEFWrapper(new dsl_4webquiz.diagram.edit.commands.EncuestaCreateCommand(req));
		}
		if (dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Cuestionario_2006 == req.getElementType()) {
			return getGEFWrapper(new dsl_4webquiz.diagram.edit.commands.CuestionarioCreateCommand(req));
		}
		if (dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.CRUD_2007 == req.getElementType()) {
			return getGEFWrapper(new dsl_4webquiz.diagram.edit.commands.CRUDCreateCommand(req));
		}
		if (dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Update_2008 == req.getElementType()) {
			return getGEFWrapper(new dsl_4webquiz.diagram.edit.commands.UpdateCreateCommand(req));
		}
		if (dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Home_2009 == req.getElementType()) {
			return getGEFWrapper(new dsl_4webquiz.diagram.edit.commands.HomeCreateCommand(req));
		}
		if (dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Twitter_2010 == req.getElementType()) {
			return getGEFWrapper(new dsl_4webquiz.diagram.edit.commands.TwitterCreateCommand(req));
		}
		if (dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Google_plus_2011 == req.getElementType()) {
			return getGEFWrapper(new dsl_4webquiz.diagram.edit.commands.Google_plusCreateCommand(req));
		}
		if (dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.RSS_2012 == req.getElementType()) {
			return getGEFWrapper(new dsl_4webquiz.diagram.edit.commands.RSSCreateCommand(req));
		}
		if (dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Usuario_2013 == req.getElementType()) {
			return getGEFWrapper(new dsl_4webquiz.diagram.edit.commands.UsuarioCreateCommand(req));
		}
		if (dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.TipoDatos_2014 == req.getElementType()) {
			return getGEFWrapper(new dsl_4webquiz.diagram.edit.commands.TipoDatosCreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

	/**
	* @generated
	*/
	protected Command getDuplicateCommand(DuplicateElementsRequest req) {
		TransactionalEditingDomain editingDomain = ((IGraphicalEditPart) getHost()).getEditingDomain();
		return getGEFWrapper(new DuplicateAnythingCommand(editingDomain, req));
	}

	/**
	* @generated
	*/
	private static class DuplicateAnythingCommand extends DuplicateEObjectsCommand {

		/**
		* @generated
		*/
		public DuplicateAnythingCommand(TransactionalEditingDomain editingDomain, DuplicateElementsRequest req) {
			super(editingDomain, req.getLabel(), req.getElementsToBeDuplicated(), req.getAllDuplicatedElementsMap());
		}

	}

}
