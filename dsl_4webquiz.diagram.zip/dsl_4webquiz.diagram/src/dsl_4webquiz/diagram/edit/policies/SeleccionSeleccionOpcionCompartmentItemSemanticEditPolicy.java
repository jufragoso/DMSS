/*
* 
*/
package dsl_4webquiz.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class SeleccionSeleccionOpcionCompartmentItemSemanticEditPolicy
		extends dsl_4webquiz.diagram.edit.policies.Dsl_4webquizBaseItemSemanticEditPolicy {

	/**
	* @generated
	*/
	public SeleccionSeleccionOpcionCompartmentItemSemanticEditPolicy() {
		super(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Seleccion_3002);
	}

	/**
	* @generated
	*/
	protected Command getCreateCommand(CreateElementRequest req) {
		if (dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Opcion_3003 == req.getElementType()) {
			return getGEFWrapper(new dsl_4webquiz.diagram.edit.commands.OpcionCreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
