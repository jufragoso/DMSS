/*
* 
*/
package dsl_4webquiz.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class TipoDatosTipoDatosAtributoCompartmentItemSemanticEditPolicy
		extends dsl_4webquiz.diagram.edit.policies.Dsl_4webquizBaseItemSemanticEditPolicy {

	/**
	* @generated
	*/
	public TipoDatosTipoDatosAtributoCompartmentItemSemanticEditPolicy() {
		super(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.TipoDatos_2014);
	}

	/**
	* @generated
	*/
	protected Command getCreateCommand(CreateElementRequest req) {
		if (dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Atributo_3008 == req.getElementType()) {
			return getGEFWrapper(new dsl_4webquiz.diagram.edit.commands.AtributoCreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
