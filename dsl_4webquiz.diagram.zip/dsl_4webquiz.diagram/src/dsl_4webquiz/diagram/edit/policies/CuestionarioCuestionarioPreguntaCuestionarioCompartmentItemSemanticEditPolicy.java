/*
* 
*/
package dsl_4webquiz.diagram.edit.policies;

import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;

/**
 * @generated
 */
public class CuestionarioCuestionarioPreguntaCuestionarioCompartmentItemSemanticEditPolicy
		extends dsl_4webquiz.diagram.edit.policies.Dsl_4webquizBaseItemSemanticEditPolicy {

	/**
	* @generated
	*/
	public CuestionarioCuestionarioPreguntaCuestionarioCompartmentItemSemanticEditPolicy() {
		super(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Cuestionario_2006);
	}

	/**
	* @generated
	*/
	protected Command getCreateCommand(CreateElementRequest req) {
		if (dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PreguntaCorta_3005 == req.getElementType()) {
			return getGEFWrapper(new dsl_4webquiz.diagram.edit.commands.PreguntaCorta2CreateCommand(req));
		}
		if (dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Seleccion_3006 == req.getElementType()) {
			return getGEFWrapper(new dsl_4webquiz.diagram.edit.commands.Seleccion2CreateCommand(req));
		}
		if (dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.VoF_3007 == req.getElementType()) {
			return getGEFWrapper(new dsl_4webquiz.diagram.edit.commands.VoF2CreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

}
