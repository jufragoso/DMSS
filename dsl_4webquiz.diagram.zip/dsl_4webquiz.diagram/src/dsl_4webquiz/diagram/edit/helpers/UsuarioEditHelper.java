/*
 * 
 */
package dsl_4webquiz.diagram.edit.helpers;

/**
 * @generated
 */
public class UsuarioEditHelper extends dsl_4webquiz.diagram.edit.helpers.Dsl_4webquizBaseEditHelper {
}
