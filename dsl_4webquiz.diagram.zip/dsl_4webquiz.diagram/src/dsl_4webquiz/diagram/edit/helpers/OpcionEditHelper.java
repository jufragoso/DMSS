/*
 * 
 */
package dsl_4webquiz.diagram.edit.helpers;

/**
 * @generated
 */
public class OpcionEditHelper extends dsl_4webquiz.diagram.edit.helpers.Dsl_4webquizBaseEditHelper {
}
