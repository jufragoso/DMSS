/*
 * 
 */
package dsl_4webquiz.diagram.edit.helpers;

import org.eclipse.gmf.tooling.runtime.edit.helpers.GeneratedEditHelperBase;

/**
 * @generated
 */
public class Dsl_4webquizBaseEditHelper extends GeneratedEditHelperBase {

}
