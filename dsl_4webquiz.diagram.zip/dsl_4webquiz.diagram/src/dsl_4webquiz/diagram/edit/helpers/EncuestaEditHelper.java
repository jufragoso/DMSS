/*
 * 
 */
package dsl_4webquiz.diagram.edit.helpers;

/**
 * @generated
 */
public class EncuestaEditHelper extends dsl_4webquiz.diagram.edit.helpers.Dsl_4webquizBaseEditHelper {
}
