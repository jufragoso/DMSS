/*
 * 
 */
package dsl_4webquiz.diagram.edit.helpers;

/**
 * @generated
 */
public class Google_plusEditHelper extends dsl_4webquiz.diagram.edit.helpers.Dsl_4webquizBaseEditHelper {
}
