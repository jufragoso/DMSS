/*
 * 
 */
package dsl_4webquiz.diagram.edit.commands;

import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.runtime.common.core.command.CommandResult;
import org.eclipse.gmf.runtime.emf.type.core.commands.EditElementCommand;
import org.eclipse.gmf.runtime.emf.type.core.requests.ReorientReferenceRelationshipRequest;
import org.eclipse.gmf.runtime.emf.type.core.requests.ReorientRelationshipRequest;

/**
 * @generated
 */
public class PaginaRedes_socialesReorientCommand extends EditElementCommand {

	/**
	* @generated
	*/
	private final int reorientDirection;

	/**
	* @generated
	*/
	private final EObject referenceOwner;

	/**
	* @generated
	*/
	private final EObject oldEnd;

	/**
	* @generated
	*/
	private final EObject newEnd;

	/**
	* @generated
	*/
	public PaginaRedes_socialesReorientCommand(ReorientReferenceRelationshipRequest request) {
		super(request.getLabel(), null, request);
		reorientDirection = request.getDirection();
		referenceOwner = request.getReferenceOwner();
		oldEnd = request.getOldRelationshipEnd();
		newEnd = request.getNewRelationshipEnd();
	}

	/**
	* @generated
	*/
	public boolean canExecute() {
		if (false == referenceOwner instanceof dsl_4webquiz.Pagina) {
			return false;
		}
		if (reorientDirection == ReorientRelationshipRequest.REORIENT_SOURCE) {
			return canReorientSource();
		}
		if (reorientDirection == ReorientRelationshipRequest.REORIENT_TARGET) {
			return canReorientTarget();
		}
		return false;
	}

	/**
	* @generated
	*/
	protected boolean canReorientSource() {
		if (!(oldEnd instanceof dsl_4webquiz.Redes_Sociales && newEnd instanceof dsl_4webquiz.Pagina)) {
			return false;
		}
		return dsl_4webquiz.diagram.edit.policies.Dsl_4webquizBaseItemSemanticEditPolicy.getLinkConstraints()
				.canExistPaginaRedes_sociales_4001(getNewSource(), getOldTarget());
	}

	/**
	* @generated
	*/
	protected boolean canReorientTarget() {
		if (!(oldEnd instanceof dsl_4webquiz.Redes_Sociales && newEnd instanceof dsl_4webquiz.Redes_Sociales)) {
			return false;
		}
		return dsl_4webquiz.diagram.edit.policies.Dsl_4webquizBaseItemSemanticEditPolicy.getLinkConstraints()
				.canExistPaginaRedes_sociales_4001(getOldSource(), getNewTarget());
	}

	/**
	* @generated
	*/
	protected CommandResult doExecuteWithResult(IProgressMonitor monitor, IAdaptable info) throws ExecutionException {
		if (!canExecute()) {
			throw new ExecutionException("Invalid arguments in reorient link command"); //$NON-NLS-1$
		}
		if (reorientDirection == ReorientRelationshipRequest.REORIENT_SOURCE) {
			return reorientSource();
		}
		if (reorientDirection == ReorientRelationshipRequest.REORIENT_TARGET) {
			return reorientTarget();
		}
		throw new IllegalStateException();
	}

	/**
	* @generated
	*/
	protected CommandResult reorientSource() throws ExecutionException {
		getOldSource().getRedes_sociales().remove(getOldTarget());
		getNewSource().getRedes_sociales().add(getOldTarget());
		return CommandResult.newOKCommandResult(referenceOwner);
	}

	/**
	* @generated
	*/
	protected CommandResult reorientTarget() throws ExecutionException {
		getOldSource().getRedes_sociales().remove(getOldTarget());
		getOldSource().getRedes_sociales().add(getNewTarget());
		return CommandResult.newOKCommandResult(referenceOwner);
	}

	/**
	* @generated
	*/
	protected dsl_4webquiz.Pagina getOldSource() {
		return (dsl_4webquiz.Pagina) referenceOwner;
	}

	/**
	* @generated
	*/
	protected dsl_4webquiz.Pagina getNewSource() {
		return (dsl_4webquiz.Pagina) newEnd;
	}

	/**
	* @generated
	*/
	protected dsl_4webquiz.Redes_Sociales getOldTarget() {
		return (dsl_4webquiz.Redes_Sociales) oldEnd;
	}

	/**
	* @generated
	*/
	protected dsl_4webquiz.Redes_Sociales getNewTarget() {
		return (dsl_4webquiz.Redes_Sociales) newEnd;
	}
}
