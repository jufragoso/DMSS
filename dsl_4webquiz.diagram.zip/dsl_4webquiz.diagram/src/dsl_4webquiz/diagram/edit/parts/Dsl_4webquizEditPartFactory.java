/*
 * 
 */
package dsl_4webquiz.diagram.edit.parts;

import org.eclipse.gef.EditPart;
import org.eclipse.gef.EditPartFactory;
import org.eclipse.gef.tools.CellEditorLocator;
import org.eclipse.gmf.runtime.diagram.ui.editparts.ITextAwareEditPart;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.gmf.tooling.runtime.directedit.locator.CellEditorLocatorAccess;

/**
 * @generated
 */
public class Dsl_4webquizEditPartFactory implements EditPartFactory {

	/**
	* @generated
	*/
	public EditPart createEditPart(EditPart context, Object model) {
		if (model instanceof View) {
			View view = (View) model;
			switch (dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getVisualID(view)) {

			case dsl_4webquiz.diagram.edit.parts.WebEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.WebEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.IndiceEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.IndiceEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.IndiceTituloEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.IndiceTituloEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.DetalleEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.DetalleEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.DetalleTituloEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.DetalleTituloEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.CreacionEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.CreacionEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.CreacionTituloEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.CreacionTituloEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.BorradoEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.BorradoEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.BorradoTituloEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.BorradoTituloEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.EncuestaEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.EncuestaEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.EncuestaTituloEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.EncuestaTituloEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.CuestionarioEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.CuestionarioEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.CuestionarioTituloEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.CuestionarioTituloEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.CRUDEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.CRUDEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.CRUDTituloEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.CRUDTituloEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.UpdateEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.UpdateEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.UpdateTituloEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.UpdateTituloEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.HomeEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.HomeEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.HomeTituloEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.HomeTituloEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.TwitterEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.TwitterEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.TwitterEnlaceEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.TwitterEnlaceEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.Google_plusEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.Google_plusEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.Google_plusEnlaceEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.Google_plusEnlaceEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.RSSEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.RSSEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.RSSEnlaceEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.RSSEnlaceEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.UsuarioEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.UsuarioEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.UsuarioUsuarioEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.UsuarioUsuarioEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.TipoDatosEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.TipoDatosEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.TipoDatosNombreEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.TipoDatosNombreEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.PreguntaCortaEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.PreguntaCortaEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.PreguntaCortaTituloPreguntaEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.PreguntaCortaTituloPreguntaEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.SeleccionEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.SeleccionEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.SeleccionTituloPreguntaEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.SeleccionTituloPreguntaEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.OpcionEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.OpcionEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.OpcionTituloPreguntaEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.OpcionTituloPreguntaEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.VoFEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.VoFEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.VoFTituloPreguntaEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.VoFTituloPreguntaEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.PreguntaCorta2EditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.PreguntaCorta2EditPart(view);

			case dsl_4webquiz.diagram.edit.parts.PreguntaCortaTituloPregunta2EditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.PreguntaCortaTituloPregunta2EditPart(view);

			case dsl_4webquiz.diagram.edit.parts.Seleccion2EditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.Seleccion2EditPart(view);

			case dsl_4webquiz.diagram.edit.parts.SeleccionTituloPregunta2EditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.SeleccionTituloPregunta2EditPart(view);

			case dsl_4webquiz.diagram.edit.parts.VoF2EditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.VoF2EditPart(view);

			case dsl_4webquiz.diagram.edit.parts.VoFTituloPregunta2EditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.VoFTituloPregunta2EditPart(view);

			case dsl_4webquiz.diagram.edit.parts.AtributoEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.AtributoEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.AtributoNombreEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.AtributoNombreEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.EncuestaEncuestaPreguntaEncuestaCompartmentEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.EncuestaEncuestaPreguntaEncuestaCompartmentEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.SeleccionSeleccionOpcionCompartmentEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.SeleccionSeleccionOpcionCompartmentEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.CuestionarioCuestionarioPreguntaCuestionarioCompartmentEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.CuestionarioCuestionarioPreguntaCuestionarioCompartmentEditPart(
						view);

			case dsl_4webquiz.diagram.edit.parts.SeleccionSeleccionOpcionCompartment2EditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.SeleccionSeleccionOpcionCompartment2EditPart(view);

			case dsl_4webquiz.diagram.edit.parts.TipoDatosTipoDatosAtributoCompartmentEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.TipoDatosTipoDatosAtributoCompartmentEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.PaginaRedes_socialesEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.PaginaRedes_socialesEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.PaginaRedes_socialesExternalLabelEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.PaginaRedes_socialesExternalLabelEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.PAGINAS_CRUDHomeEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.PAGINAS_CRUDHomeEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.WrappingLabelEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.WrappingLabelEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.PAGINAS_CRUDTipodatosEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.PAGINAS_CRUDTipodatosEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.WrappingLabel2EditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.WrappingLabel2EditPart(view);

			case dsl_4webquiz.diagram.edit.parts.HomeCrudEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.HomeCrudEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.WrappingLabel3EditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.WrappingLabel3EditPart(view);

			case dsl_4webquiz.diagram.edit.parts.HomeConsultaEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.HomeConsultaEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.WrappingLabel4EditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.WrappingLabel4EditPart(view);

			case dsl_4webquiz.diagram.edit.parts.ConsultaHomeEditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.ConsultaHomeEditPart(view);

			case dsl_4webquiz.diagram.edit.parts.WrappingLabel5EditPart.VISUAL_ID:
				return new dsl_4webquiz.diagram.edit.parts.WrappingLabel5EditPart(view);

			}
		}
		return createUnrecognizedEditPart(context, model);
	}

	/**
	* @generated
	*/
	private EditPart createUnrecognizedEditPart(EditPart context, Object model) {
		// Handle creation of unrecognized child node EditParts here
		return null;
	}

	/**
	* @generated
	*/
	public static CellEditorLocator getTextCellEditorLocator(ITextAwareEditPart source) {
		return CellEditorLocatorAccess.INSTANCE.getTextCellEditorLocator(source);
	}

}
