/*
 * 
 */
package dsl_4webquiz.diagram.providers;

import org.eclipse.gmf.runtime.common.ui.services.icon.IIconProvider;
import org.eclipse.gmf.tooling.runtime.providers.DefaultElementTypeIconProvider;

/**
 * @generated
 */
public class Dsl_4webquizIconProvider extends DefaultElementTypeIconProvider implements IIconProvider {

	/**
	* @generated
	*/
	public Dsl_4webquizIconProvider() {
		super(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.TYPED_INSTANCE);
	}

}
