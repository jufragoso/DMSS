/*
 * 
 */
package dsl_4webquiz.diagram.providers.assistants;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.gmf.runtime.diagram.ui.editparts.IGraphicalEditPart;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;

/**
 * @generated
 */
public class Dsl_4webquizModelingAssistantProviderOfHomeEditPart
		extends dsl_4webquiz.diagram.providers.Dsl_4webquizModelingAssistantProvider {

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getRelTypesOnSource(IAdaptable source) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source.getAdapter(IGraphicalEditPart.class);
		return doGetRelTypesOnSource((dsl_4webquiz.diagram.edit.parts.HomeEditPart) sourceEditPart);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetRelTypesOnSource(dsl_4webquiz.diagram.edit.parts.HomeEditPart source) {
		List<IElementType> types = new ArrayList<IElementType>(3);
		types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PaginaRedes_sociales_4001);
		types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.HomeCrud_4003);
		types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.HomeConsulta_4004);
		return types;
	}

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getRelTypesOnSourceAndTarget(IAdaptable source, IAdaptable target) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source.getAdapter(IGraphicalEditPart.class);
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target.getAdapter(IGraphicalEditPart.class);
		return doGetRelTypesOnSourceAndTarget((dsl_4webquiz.diagram.edit.parts.HomeEditPart) sourceEditPart,
				targetEditPart);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetRelTypesOnSourceAndTarget(dsl_4webquiz.diagram.edit.parts.HomeEditPart source,
			IGraphicalEditPart targetEditPart) {
		List<IElementType> types = new LinkedList<IElementType>();
		if (targetEditPart instanceof dsl_4webquiz.diagram.edit.parts.TwitterEditPart) {
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PaginaRedes_sociales_4001);
		}
		if (targetEditPart instanceof dsl_4webquiz.diagram.edit.parts.Google_plusEditPart) {
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PaginaRedes_sociales_4001);
		}
		if (targetEditPart instanceof dsl_4webquiz.diagram.edit.parts.RSSEditPart) {
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PaginaRedes_sociales_4001);
		}
		if (targetEditPart instanceof dsl_4webquiz.diagram.edit.parts.IndiceEditPart) {
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.HomeCrud_4003);
		}
		if (targetEditPart instanceof dsl_4webquiz.diagram.edit.parts.DetalleEditPart) {
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.HomeCrud_4003);
		}
		if (targetEditPart instanceof dsl_4webquiz.diagram.edit.parts.CreacionEditPart) {
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.HomeCrud_4003);
		}
		if (targetEditPart instanceof dsl_4webquiz.diagram.edit.parts.BorradoEditPart) {
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.HomeCrud_4003);
		}
		if (targetEditPart instanceof dsl_4webquiz.diagram.edit.parts.CRUDEditPart) {
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.HomeCrud_4003);
		}
		if (targetEditPart instanceof dsl_4webquiz.diagram.edit.parts.UpdateEditPart) {
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.HomeCrud_4003);
		}
		if (targetEditPart instanceof dsl_4webquiz.diagram.edit.parts.EncuestaEditPart) {
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.HomeConsulta_4004);
		}
		if (targetEditPart instanceof dsl_4webquiz.diagram.edit.parts.CuestionarioEditPart) {
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.HomeConsulta_4004);
		}
		return types;
	}

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getTypesForTarget(IAdaptable source, IElementType relationshipType) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source.getAdapter(IGraphicalEditPart.class);
		return doGetTypesForTarget((dsl_4webquiz.diagram.edit.parts.HomeEditPart) sourceEditPart, relationshipType);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetTypesForTarget(dsl_4webquiz.diagram.edit.parts.HomeEditPart source,
			IElementType relationshipType) {
		List<IElementType> types = new ArrayList<IElementType>();
		if (relationshipType == dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PaginaRedes_sociales_4001) {
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Twitter_2010);
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Google_plus_2011);
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.RSS_2012);
		} else if (relationshipType == dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.HomeCrud_4003) {
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Indice_2001);
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Detalle_2002);
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Creacion_2003);
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Borrado_2004);
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.CRUD_2007);
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Update_2008);
		} else if (relationshipType == dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.HomeConsulta_4004) {
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Encuesta_2005);
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Cuestionario_2006);
		}
		return types;
	}

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getRelTypesOnTarget(IAdaptable target) {
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target.getAdapter(IGraphicalEditPart.class);
		return doGetRelTypesOnTarget((dsl_4webquiz.diagram.edit.parts.HomeEditPart) targetEditPart);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetRelTypesOnTarget(dsl_4webquiz.diagram.edit.parts.HomeEditPart target) {
		List<IElementType> types = new ArrayList<IElementType>(2);
		types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PAGINAS_CRUDHome_4002);
		types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.ConsultaHome_4005);
		return types;
	}

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getTypesForSource(IAdaptable target, IElementType relationshipType) {
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target.getAdapter(IGraphicalEditPart.class);
		return doGetTypesForSource((dsl_4webquiz.diagram.edit.parts.HomeEditPart) targetEditPart, relationshipType);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetTypesForSource(dsl_4webquiz.diagram.edit.parts.HomeEditPart target,
			IElementType relationshipType) {
		List<IElementType> types = new ArrayList<IElementType>();
		if (relationshipType == dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PAGINAS_CRUDHome_4002) {
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Indice_2001);
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Detalle_2002);
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Creacion_2003);
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Borrado_2004);
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.CRUD_2007);
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Update_2008);
		} else if (relationshipType == dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.ConsultaHome_4005) {
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Encuesta_2005);
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Cuestionario_2006);
		}
		return types;
	}

}
