/*
 * 
 */
package dsl_4webquiz.diagram.providers.assistants;

/**
 * @generated
 */
public class Dsl_4webquizModelingAssistantProviderOfVoFEditPart
		extends dsl_4webquiz.diagram.providers.Dsl_4webquizModelingAssistantProvider {

}
