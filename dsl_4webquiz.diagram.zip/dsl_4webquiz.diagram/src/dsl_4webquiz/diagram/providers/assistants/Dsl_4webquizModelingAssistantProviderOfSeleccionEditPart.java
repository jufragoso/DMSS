/*
 * 
 */
package dsl_4webquiz.diagram.providers.assistants;

/**
 * @generated
 */
public class Dsl_4webquizModelingAssistantProviderOfSeleccionEditPart
		extends dsl_4webquiz.diagram.providers.Dsl_4webquizModelingAssistantProvider {

}
