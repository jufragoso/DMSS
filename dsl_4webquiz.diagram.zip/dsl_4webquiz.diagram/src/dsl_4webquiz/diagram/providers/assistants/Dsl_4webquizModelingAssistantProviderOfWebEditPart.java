/*
 * 
 */
package dsl_4webquiz.diagram.providers.assistants;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;

/**
 * @generated
 */
public class Dsl_4webquizModelingAssistantProviderOfWebEditPart
		extends dsl_4webquiz.diagram.providers.Dsl_4webquizModelingAssistantProvider {

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getTypesForPopupBar(IAdaptable host) {
		List<IElementType> types = new ArrayList<IElementType>(14);
		types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Indice_2001);
		types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Detalle_2002);
		types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Creacion_2003);
		types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Borrado_2004);
		types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Encuesta_2005);
		types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Cuestionario_2006);
		types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.CRUD_2007);
		types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Update_2008);
		types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Home_2009);
		types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Twitter_2010);
		types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Google_plus_2011);
		types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.RSS_2012);
		types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Usuario_2013);
		types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.TipoDatos_2014);
		return types;
	}

}
