/*
 * 
 */
package dsl_4webquiz.diagram.providers.assistants;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.gmf.runtime.diagram.ui.editparts.IGraphicalEditPart;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;

/**
 * @generated
 */
public class Dsl_4webquizModelingAssistantProviderOfUpdateEditPart
		extends dsl_4webquiz.diagram.providers.Dsl_4webquizModelingAssistantProvider {

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getRelTypesOnSource(IAdaptable source) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source.getAdapter(IGraphicalEditPart.class);
		return doGetRelTypesOnSource((dsl_4webquiz.diagram.edit.parts.UpdateEditPart) sourceEditPart);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetRelTypesOnSource(dsl_4webquiz.diagram.edit.parts.UpdateEditPart source) {
		List<IElementType> types = new ArrayList<IElementType>(3);
		types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PaginaRedes_sociales_4001);
		types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PAGINAS_CRUDHome_4002);
		types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PAGINAS_CRUDTipodatos_4006);
		return types;
	}

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getRelTypesOnSourceAndTarget(IAdaptable source, IAdaptable target) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source.getAdapter(IGraphicalEditPart.class);
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target.getAdapter(IGraphicalEditPart.class);
		return doGetRelTypesOnSourceAndTarget((dsl_4webquiz.diagram.edit.parts.UpdateEditPart) sourceEditPart,
				targetEditPart);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetRelTypesOnSourceAndTarget(dsl_4webquiz.diagram.edit.parts.UpdateEditPart source,
			IGraphicalEditPart targetEditPart) {
		List<IElementType> types = new LinkedList<IElementType>();
		if (targetEditPart instanceof dsl_4webquiz.diagram.edit.parts.TwitterEditPart) {
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PaginaRedes_sociales_4001);
		}
		if (targetEditPart instanceof dsl_4webquiz.diagram.edit.parts.Google_plusEditPart) {
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PaginaRedes_sociales_4001);
		}
		if (targetEditPart instanceof dsl_4webquiz.diagram.edit.parts.RSSEditPart) {
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PaginaRedes_sociales_4001);
		}
		if (targetEditPart instanceof dsl_4webquiz.diagram.edit.parts.HomeEditPart) {
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PAGINAS_CRUDHome_4002);
		}
		if (targetEditPart instanceof dsl_4webquiz.diagram.edit.parts.TipoDatosEditPart) {
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PAGINAS_CRUDTipodatos_4006);
		}
		return types;
	}

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getTypesForTarget(IAdaptable source, IElementType relationshipType) {
		IGraphicalEditPart sourceEditPart = (IGraphicalEditPart) source.getAdapter(IGraphicalEditPart.class);
		return doGetTypesForTarget((dsl_4webquiz.diagram.edit.parts.UpdateEditPart) sourceEditPart, relationshipType);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetTypesForTarget(dsl_4webquiz.diagram.edit.parts.UpdateEditPart source,
			IElementType relationshipType) {
		List<IElementType> types = new ArrayList<IElementType>();
		if (relationshipType == dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PaginaRedes_sociales_4001) {
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Twitter_2010);
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Google_plus_2011);
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.RSS_2012);
		} else if (relationshipType == dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PAGINAS_CRUDHome_4002) {
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Home_2009);
		} else if (relationshipType == dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PAGINAS_CRUDTipodatos_4006) {
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.TipoDatos_2014);
		}
		return types;
	}

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getRelTypesOnTarget(IAdaptable target) {
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target.getAdapter(IGraphicalEditPart.class);
		return doGetRelTypesOnTarget((dsl_4webquiz.diagram.edit.parts.UpdateEditPart) targetEditPart);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetRelTypesOnTarget(dsl_4webquiz.diagram.edit.parts.UpdateEditPart target) {
		List<IElementType> types = new ArrayList<IElementType>(1);
		types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.HomeCrud_4003);
		return types;
	}

	/**
	* @generated
	*/
	@Override

	public List<IElementType> getTypesForSource(IAdaptable target, IElementType relationshipType) {
		IGraphicalEditPart targetEditPart = (IGraphicalEditPart) target.getAdapter(IGraphicalEditPart.class);
		return doGetTypesForSource((dsl_4webquiz.diagram.edit.parts.UpdateEditPart) targetEditPart, relationshipType);
	}

	/**
	* @generated
	*/
	public List<IElementType> doGetTypesForSource(dsl_4webquiz.diagram.edit.parts.UpdateEditPart target,
			IElementType relationshipType) {
		List<IElementType> types = new ArrayList<IElementType>();
		if (relationshipType == dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.HomeCrud_4003) {
			types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Home_2009);
		}
		return types;
	}

}
