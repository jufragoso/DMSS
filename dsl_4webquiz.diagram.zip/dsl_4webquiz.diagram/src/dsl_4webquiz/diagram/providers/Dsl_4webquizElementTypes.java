/*
 * 
 */
package dsl_4webquiz.diagram.providers;

import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.emf.ecore.ENamedElement;
import org.eclipse.gmf.runtime.emf.type.core.ElementTypeRegistry;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.tooling.runtime.providers.DiagramElementTypeImages;
import org.eclipse.gmf.tooling.runtime.providers.DiagramElementTypes;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.graphics.Image;

/**
 * @generated
 */
public class Dsl_4webquizElementTypes {

	/**
	* @generated
	*/
	private Dsl_4webquizElementTypes() {
	}

	/**
	* @generated
	*/
	private static Map<IElementType, ENamedElement> elements;

	/**
	* @generated
	*/
	private static DiagramElementTypeImages elementTypeImages = new DiagramElementTypeImages(
			dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance().getItemProvidersAdapterFactory());

	/**
	* @generated
	*/
	private static Set<IElementType> KNOWN_ELEMENT_TYPES;

	/**
	* @generated
	*/
	public static final IElementType Web_1000 = getElementType("dsl_4webquiz.diagram.Web_1000"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType Indice_2001 = getElementType("dsl_4webquiz.diagram.Indice_2001"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType Detalle_2002 = getElementType("dsl_4webquiz.diagram.Detalle_2002"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType Creacion_2003 = getElementType("dsl_4webquiz.diagram.Creacion_2003"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType Borrado_2004 = getElementType("dsl_4webquiz.diagram.Borrado_2004"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType Encuesta_2005 = getElementType("dsl_4webquiz.diagram.Encuesta_2005"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType Cuestionario_2006 = getElementType("dsl_4webquiz.diagram.Cuestionario_2006"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType CRUD_2007 = getElementType("dsl_4webquiz.diagram.CRUD_2007"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType Update_2008 = getElementType("dsl_4webquiz.diagram.Update_2008"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType Home_2009 = getElementType("dsl_4webquiz.diagram.Home_2009"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType Twitter_2010 = getElementType("dsl_4webquiz.diagram.Twitter_2010"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType Google_plus_2011 = getElementType("dsl_4webquiz.diagram.Google_plus_2011"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType RSS_2012 = getElementType("dsl_4webquiz.diagram.RSS_2012"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType Usuario_2013 = getElementType("dsl_4webquiz.diagram.Usuario_2013"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType TipoDatos_2014 = getElementType("dsl_4webquiz.diagram.TipoDatos_2014"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType PreguntaCorta_3001 = getElementType("dsl_4webquiz.diagram.PreguntaCorta_3001"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType Seleccion_3002 = getElementType("dsl_4webquiz.diagram.Seleccion_3002"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType Opcion_3003 = getElementType("dsl_4webquiz.diagram.Opcion_3003"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType VoF_3004 = getElementType("dsl_4webquiz.diagram.VoF_3004"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType PreguntaCorta_3005 = getElementType("dsl_4webquiz.diagram.PreguntaCorta_3005"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType Seleccion_3006 = getElementType("dsl_4webquiz.diagram.Seleccion_3006"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType VoF_3007 = getElementType("dsl_4webquiz.diagram.VoF_3007"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType Atributo_3008 = getElementType("dsl_4webquiz.diagram.Atributo_3008"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType PaginaRedes_sociales_4001 = getElementType(
			"dsl_4webquiz.diagram.PaginaRedes_sociales_4001"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType PAGINAS_CRUDHome_4002 = getElementType(
			"dsl_4webquiz.diagram.PAGINAS_CRUDHome_4002"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType PAGINAS_CRUDTipodatos_4006 = getElementType(
			"dsl_4webquiz.diagram.PAGINAS_CRUDTipodatos_4006"); //$NON-NLS-1$

	/**
	* @generated
	*/
	public static final IElementType HomeCrud_4003 = getElementType("dsl_4webquiz.diagram.HomeCrud_4003"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType HomeConsulta_4004 = getElementType("dsl_4webquiz.diagram.HomeConsulta_4004"); //$NON-NLS-1$
	/**
	* @generated
	*/
	public static final IElementType ConsultaHome_4005 = getElementType("dsl_4webquiz.diagram.ConsultaHome_4005"); //$NON-NLS-1$

	/**
	* @generated
	*/
	public static ImageDescriptor getImageDescriptor(ENamedElement element) {
		return elementTypeImages.getImageDescriptor(element);
	}

	/**
	* @generated
	*/
	public static Image getImage(ENamedElement element) {
		return elementTypeImages.getImage(element);
	}

	/**
	* @generated
	*/
	public static ImageDescriptor getImageDescriptor(IAdaptable hint) {
		return getImageDescriptor(getElement(hint));
	}

	/**
	* @generated
	*/
	public static Image getImage(IAdaptable hint) {
		return getImage(getElement(hint));
	}

	/**
	* Returns 'type' of the ecore object associated with the hint.
	* 
	* @generated
	*/
	public static ENamedElement getElement(IAdaptable hint) {
		Object type = hint.getAdapter(IElementType.class);
		if (elements == null) {
			elements = new IdentityHashMap<IElementType, ENamedElement>();

			elements.put(Web_1000, dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getWeb());

			elements.put(Indice_2001, dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getIndice());

			elements.put(Detalle_2002, dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getDetalle());

			elements.put(Creacion_2003, dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getCreacion());

			elements.put(Borrado_2004, dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getBorrado());

			elements.put(Encuesta_2005, dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getEncuesta());

			elements.put(Cuestionario_2006, dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getCuestionario());

			elements.put(CRUD_2007, dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getCRUD());

			elements.put(Update_2008, dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getUpdate());

			elements.put(Home_2009, dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getHome());

			elements.put(Twitter_2010, dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getTwitter());

			elements.put(Google_plus_2011, dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getGoogle_plus());

			elements.put(RSS_2012, dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getRSS());

			elements.put(Usuario_2013, dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getUsuario());

			elements.put(TipoDatos_2014, dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getTipoDatos());

			elements.put(PreguntaCorta_3001, dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getPreguntaCorta());

			elements.put(Seleccion_3002, dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getSeleccion());

			elements.put(Opcion_3003, dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getOpcion());

			elements.put(VoF_3004, dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getVoF());

			elements.put(PreguntaCorta_3005, dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getPreguntaCorta());

			elements.put(Seleccion_3006, dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getSeleccion());

			elements.put(VoF_3007, dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getVoF());

			elements.put(Atributo_3008, dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getAtributo());

			elements.put(PaginaRedes_sociales_4001,
					dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getPagina_Redes_sociales());

			elements.put(PAGINAS_CRUDHome_4002, dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getPAGINAS_CRUD_Home());

			elements.put(PAGINAS_CRUDTipodatos_4006,
					dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getPAGINAS_CRUD_Tipodatos());

			elements.put(HomeCrud_4003, dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getHome_Crud());

			elements.put(HomeConsulta_4004, dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getHome_Consulta());

			elements.put(ConsultaHome_4005, dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getConsulta_Home());
		}
		return (ENamedElement) elements.get(type);
	}

	/**
	* @generated
	*/
	private static IElementType getElementType(String id) {
		return ElementTypeRegistry.getInstance().getType(id);
	}

	/**
	* @generated
	*/
	public static boolean isKnownElementType(IElementType elementType) {
		if (KNOWN_ELEMENT_TYPES == null) {
			KNOWN_ELEMENT_TYPES = new HashSet<IElementType>();
			KNOWN_ELEMENT_TYPES.add(Web_1000);
			KNOWN_ELEMENT_TYPES.add(Indice_2001);
			KNOWN_ELEMENT_TYPES.add(Detalle_2002);
			KNOWN_ELEMENT_TYPES.add(Creacion_2003);
			KNOWN_ELEMENT_TYPES.add(Borrado_2004);
			KNOWN_ELEMENT_TYPES.add(Encuesta_2005);
			KNOWN_ELEMENT_TYPES.add(Cuestionario_2006);
			KNOWN_ELEMENT_TYPES.add(CRUD_2007);
			KNOWN_ELEMENT_TYPES.add(Update_2008);
			KNOWN_ELEMENT_TYPES.add(Home_2009);
			KNOWN_ELEMENT_TYPES.add(Twitter_2010);
			KNOWN_ELEMENT_TYPES.add(Google_plus_2011);
			KNOWN_ELEMENT_TYPES.add(RSS_2012);
			KNOWN_ELEMENT_TYPES.add(Usuario_2013);
			KNOWN_ELEMENT_TYPES.add(TipoDatos_2014);
			KNOWN_ELEMENT_TYPES.add(PreguntaCorta_3001);
			KNOWN_ELEMENT_TYPES.add(Seleccion_3002);
			KNOWN_ELEMENT_TYPES.add(Opcion_3003);
			KNOWN_ELEMENT_TYPES.add(VoF_3004);
			KNOWN_ELEMENT_TYPES.add(PreguntaCorta_3005);
			KNOWN_ELEMENT_TYPES.add(Seleccion_3006);
			KNOWN_ELEMENT_TYPES.add(VoF_3007);
			KNOWN_ELEMENT_TYPES.add(Atributo_3008);
			KNOWN_ELEMENT_TYPES.add(PaginaRedes_sociales_4001);
			KNOWN_ELEMENT_TYPES.add(PAGINAS_CRUDHome_4002);
			KNOWN_ELEMENT_TYPES.add(PAGINAS_CRUDTipodatos_4006);
			KNOWN_ELEMENT_TYPES.add(HomeCrud_4003);
			KNOWN_ELEMENT_TYPES.add(HomeConsulta_4004);
			KNOWN_ELEMENT_TYPES.add(ConsultaHome_4005);
		}
		return KNOWN_ELEMENT_TYPES.contains(elementType);
	}

	/**
	* @generated
	*/
	public static IElementType getElementType(int visualID) {
		switch (visualID) {
		case dsl_4webquiz.diagram.edit.parts.WebEditPart.VISUAL_ID:
			return Web_1000;
		case dsl_4webquiz.diagram.edit.parts.IndiceEditPart.VISUAL_ID:
			return Indice_2001;
		case dsl_4webquiz.diagram.edit.parts.DetalleEditPart.VISUAL_ID:
			return Detalle_2002;
		case dsl_4webquiz.diagram.edit.parts.CreacionEditPart.VISUAL_ID:
			return Creacion_2003;
		case dsl_4webquiz.diagram.edit.parts.BorradoEditPart.VISUAL_ID:
			return Borrado_2004;
		case dsl_4webquiz.diagram.edit.parts.EncuestaEditPart.VISUAL_ID:
			return Encuesta_2005;
		case dsl_4webquiz.diagram.edit.parts.CuestionarioEditPart.VISUAL_ID:
			return Cuestionario_2006;
		case dsl_4webquiz.diagram.edit.parts.CRUDEditPart.VISUAL_ID:
			return CRUD_2007;
		case dsl_4webquiz.diagram.edit.parts.UpdateEditPart.VISUAL_ID:
			return Update_2008;
		case dsl_4webquiz.diagram.edit.parts.HomeEditPart.VISUAL_ID:
			return Home_2009;
		case dsl_4webquiz.diagram.edit.parts.TwitterEditPart.VISUAL_ID:
			return Twitter_2010;
		case dsl_4webquiz.diagram.edit.parts.Google_plusEditPart.VISUAL_ID:
			return Google_plus_2011;
		case dsl_4webquiz.diagram.edit.parts.RSSEditPart.VISUAL_ID:
			return RSS_2012;
		case dsl_4webquiz.diagram.edit.parts.UsuarioEditPart.VISUAL_ID:
			return Usuario_2013;
		case dsl_4webquiz.diagram.edit.parts.TipoDatosEditPart.VISUAL_ID:
			return TipoDatos_2014;
		case dsl_4webquiz.diagram.edit.parts.PreguntaCortaEditPart.VISUAL_ID:
			return PreguntaCorta_3001;
		case dsl_4webquiz.diagram.edit.parts.SeleccionEditPart.VISUAL_ID:
			return Seleccion_3002;
		case dsl_4webquiz.diagram.edit.parts.OpcionEditPart.VISUAL_ID:
			return Opcion_3003;
		case dsl_4webquiz.diagram.edit.parts.VoFEditPart.VISUAL_ID:
			return VoF_3004;
		case dsl_4webquiz.diagram.edit.parts.PreguntaCorta2EditPart.VISUAL_ID:
			return PreguntaCorta_3005;
		case dsl_4webquiz.diagram.edit.parts.Seleccion2EditPart.VISUAL_ID:
			return Seleccion_3006;
		case dsl_4webquiz.diagram.edit.parts.VoF2EditPart.VISUAL_ID:
			return VoF_3007;
		case dsl_4webquiz.diagram.edit.parts.AtributoEditPart.VISUAL_ID:
			return Atributo_3008;
		case dsl_4webquiz.diagram.edit.parts.PaginaRedes_socialesEditPart.VISUAL_ID:
			return PaginaRedes_sociales_4001;
		case dsl_4webquiz.diagram.edit.parts.PAGINAS_CRUDHomeEditPart.VISUAL_ID:
			return PAGINAS_CRUDHome_4002;
		case dsl_4webquiz.diagram.edit.parts.PAGINAS_CRUDTipodatosEditPart.VISUAL_ID:
			return PAGINAS_CRUDTipodatos_4006;
		case dsl_4webquiz.diagram.edit.parts.HomeCrudEditPart.VISUAL_ID:
			return HomeCrud_4003;
		case dsl_4webquiz.diagram.edit.parts.HomeConsultaEditPart.VISUAL_ID:
			return HomeConsulta_4004;
		case dsl_4webquiz.diagram.edit.parts.ConsultaHomeEditPart.VISUAL_ID:
			return ConsultaHome_4005;
		}
		return null;
	}

	/**
	* @generated
	*/
	public static final DiagramElementTypes TYPED_INSTANCE = new DiagramElementTypes(elementTypeImages) {

		/**
		* @generated
		*/
		@Override

		public boolean isKnownElementType(IElementType elementType) {
			return dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.isKnownElementType(elementType);
		}

		/**
		* @generated
		*/
		@Override

		public IElementType getElementTypeForVisualId(int visualID) {
			return dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.getElementType(visualID);
		}

		/**
		* @generated
		*/
		@Override

		public ENamedElement getDefiningNamedElement(IAdaptable elementTypeAdapter) {
			return dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.getElement(elementTypeAdapter);
		}
	};

}
