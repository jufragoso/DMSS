/*
 * 
 */
package dsl_4webquiz.diagram.providers;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.runtime.common.core.service.AbstractProvider;
import org.eclipse.gmf.runtime.common.core.service.IOperation;
import org.eclipse.gmf.runtime.common.ui.services.parser.GetParserOperation;
import org.eclipse.gmf.runtime.common.ui.services.parser.IParser;
import org.eclipse.gmf.runtime.common.ui.services.parser.IParserProvider;
import org.eclipse.gmf.runtime.common.ui.services.parser.ParserService;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.runtime.emf.ui.services.parser.ParserHintAdapter;
import org.eclipse.gmf.runtime.notation.View;

/**
 * @generated
 */
public class Dsl_4webquizParserProvider extends AbstractProvider implements IParserProvider {

	/**
	* @generated
	*/
	private IParser indiceTitulo_5001Parser;

	/**
	* @generated
	*/
	private IParser getIndiceTitulo_5001Parser() {
		if (indiceTitulo_5001Parser == null) {
			EAttribute[] features = new EAttribute[] { dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getPagina_Titulo() };
			dsl_4webquiz.diagram.parsers.MessageFormatParser parser = new dsl_4webquiz.diagram.parsers.MessageFormatParser(
					features);
			indiceTitulo_5001Parser = parser;
		}
		return indiceTitulo_5001Parser;
	}

	/**
	* @generated
	*/
	private IParser detalleTitulo_5002Parser;

	/**
	* @generated
	*/
	private IParser getDetalleTitulo_5002Parser() {
		if (detalleTitulo_5002Parser == null) {
			EAttribute[] features = new EAttribute[] { dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getPagina_Titulo() };
			dsl_4webquiz.diagram.parsers.MessageFormatParser parser = new dsl_4webquiz.diagram.parsers.MessageFormatParser(
					features);
			detalleTitulo_5002Parser = parser;
		}
		return detalleTitulo_5002Parser;
	}

	/**
	* @generated
	*/
	private IParser creacionTitulo_5003Parser;

	/**
	* @generated
	*/
	private IParser getCreacionTitulo_5003Parser() {
		if (creacionTitulo_5003Parser == null) {
			EAttribute[] features = new EAttribute[] { dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getPagina_Titulo() };
			dsl_4webquiz.diagram.parsers.MessageFormatParser parser = new dsl_4webquiz.diagram.parsers.MessageFormatParser(
					features);
			creacionTitulo_5003Parser = parser;
		}
		return creacionTitulo_5003Parser;
	}

	/**
	* @generated
	*/
	private IParser borradoTitulo_5004Parser;

	/**
	* @generated
	*/
	private IParser getBorradoTitulo_5004Parser() {
		if (borradoTitulo_5004Parser == null) {
			EAttribute[] features = new EAttribute[] { dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getPagina_Titulo() };
			dsl_4webquiz.diagram.parsers.MessageFormatParser parser = new dsl_4webquiz.diagram.parsers.MessageFormatParser(
					features);
			borradoTitulo_5004Parser = parser;
		}
		return borradoTitulo_5004Parser;
	}

	/**
	* @generated
	*/
	private IParser encuestaTitulo_5009Parser;

	/**
	* @generated
	*/
	private IParser getEncuestaTitulo_5009Parser() {
		if (encuestaTitulo_5009Parser == null) {
			EAttribute[] features = new EAttribute[] { dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getPagina_Titulo() };
			dsl_4webquiz.diagram.parsers.MessageFormatParser parser = new dsl_4webquiz.diagram.parsers.MessageFormatParser(
					features);
			encuestaTitulo_5009Parser = parser;
		}
		return encuestaTitulo_5009Parser;
	}

	/**
	* @generated
	*/
	private IParser cuestionarioTitulo_5013Parser;

	/**
	* @generated
	*/
	private IParser getCuestionarioTitulo_5013Parser() {
		if (cuestionarioTitulo_5013Parser == null) {
			EAttribute[] features = new EAttribute[] { dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getPagina_Titulo() };
			dsl_4webquiz.diagram.parsers.MessageFormatParser parser = new dsl_4webquiz.diagram.parsers.MessageFormatParser(
					features);
			cuestionarioTitulo_5013Parser = parser;
		}
		return cuestionarioTitulo_5013Parser;
	}

	/**
	* @generated
	*/
	private IParser cRUDTitulo_5014Parser;

	/**
	* @generated
	*/
	private IParser getCRUDTitulo_5014Parser() {
		if (cRUDTitulo_5014Parser == null) {
			EAttribute[] features = new EAttribute[] { dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getPagina_Titulo() };
			dsl_4webquiz.diagram.parsers.MessageFormatParser parser = new dsl_4webquiz.diagram.parsers.MessageFormatParser(
					features);
			cRUDTitulo_5014Parser = parser;
		}
		return cRUDTitulo_5014Parser;
	}

	/**
	* @generated
	*/
	private IParser updateTitulo_5015Parser;

	/**
	* @generated
	*/
	private IParser getUpdateTitulo_5015Parser() {
		if (updateTitulo_5015Parser == null) {
			EAttribute[] features = new EAttribute[] { dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getPagina_Titulo() };
			dsl_4webquiz.diagram.parsers.MessageFormatParser parser = new dsl_4webquiz.diagram.parsers.MessageFormatParser(
					features);
			updateTitulo_5015Parser = parser;
		}
		return updateTitulo_5015Parser;
	}

	/**
	* @generated
	*/
	private IParser homeTitulo_5016Parser;

	/**
	* @generated
	*/
	private IParser getHomeTitulo_5016Parser() {
		if (homeTitulo_5016Parser == null) {
			EAttribute[] features = new EAttribute[] { dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getPagina_Titulo() };
			dsl_4webquiz.diagram.parsers.MessageFormatParser parser = new dsl_4webquiz.diagram.parsers.MessageFormatParser(
					features);
			homeTitulo_5016Parser = parser;
		}
		return homeTitulo_5016Parser;
	}

	/**
	* @generated
	*/
	private IParser twitterEnlace_5017Parser;

	/**
	* @generated
	*/
	private IParser getTwitterEnlace_5017Parser() {
		if (twitterEnlace_5017Parser == null) {
			EAttribute[] features = new EAttribute[] {
					dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getRedes_Sociales_Enlace() };
			dsl_4webquiz.diagram.parsers.MessageFormatParser parser = new dsl_4webquiz.diagram.parsers.MessageFormatParser(
					features);
			twitterEnlace_5017Parser = parser;
		}
		return twitterEnlace_5017Parser;
	}

	/**
	* @generated
	*/
	private IParser google_plusEnlace_5018Parser;

	/**
	* @generated
	*/
	private IParser getGoogle_plusEnlace_5018Parser() {
		if (google_plusEnlace_5018Parser == null) {
			EAttribute[] features = new EAttribute[] {
					dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getRedes_Sociales_Enlace() };
			dsl_4webquiz.diagram.parsers.MessageFormatParser parser = new dsl_4webquiz.diagram.parsers.MessageFormatParser(
					features);
			google_plusEnlace_5018Parser = parser;
		}
		return google_plusEnlace_5018Parser;
	}

	/**
	* @generated
	*/
	private IParser rSSEnlace_5019Parser;

	/**
	* @generated
	*/
	private IParser getRSSEnlace_5019Parser() {
		if (rSSEnlace_5019Parser == null) {
			EAttribute[] features = new EAttribute[] {
					dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getRedes_Sociales_Enlace() };
			dsl_4webquiz.diagram.parsers.MessageFormatParser parser = new dsl_4webquiz.diagram.parsers.MessageFormatParser(
					features);
			rSSEnlace_5019Parser = parser;
		}
		return rSSEnlace_5019Parser;
	}

	/**
	* @generated
	*/
	private IParser usuarioUsuario_5020Parser;

	/**
	* @generated
	*/
	private IParser getUsuarioUsuario_5020Parser() {
		if (usuarioUsuario_5020Parser == null) {
			EAttribute[] features = new EAttribute[] {
					dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getUsuario_Usuario() };
			dsl_4webquiz.diagram.parsers.MessageFormatParser parser = new dsl_4webquiz.diagram.parsers.MessageFormatParser(
					features);
			usuarioUsuario_5020Parser = parser;
		}
		return usuarioUsuario_5020Parser;
	}

	/**
	* @generated
	*/
	private IParser tipoDatosNombre_5022Parser;

	/**
	* @generated
	*/
	private IParser getTipoDatosNombre_5022Parser() {
		if (tipoDatosNombre_5022Parser == null) {
			EAttribute[] features = new EAttribute[] {
					dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getTipoDatos_Nombre() };
			dsl_4webquiz.diagram.parsers.MessageFormatParser parser = new dsl_4webquiz.diagram.parsers.MessageFormatParser(
					features);
			tipoDatosNombre_5022Parser = parser;
		}
		return tipoDatosNombre_5022Parser;
	}

	/**
	* @generated
	*/
	private IParser preguntaCortaTituloPregunta_5005Parser;

	/**
	* @generated
	*/
	private IParser getPreguntaCortaTituloPregunta_5005Parser() {
		if (preguntaCortaTituloPregunta_5005Parser == null) {
			EAttribute[] features = new EAttribute[] {
					dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getPregunta_TituloPregunta() };
			dsl_4webquiz.diagram.parsers.MessageFormatParser parser = new dsl_4webquiz.diagram.parsers.MessageFormatParser(
					features);
			preguntaCortaTituloPregunta_5005Parser = parser;
		}
		return preguntaCortaTituloPregunta_5005Parser;
	}

	/**
	* @generated
	*/
	private IParser seleccionTituloPregunta_5007Parser;

	/**
	* @generated
	*/
	private IParser getSeleccionTituloPregunta_5007Parser() {
		if (seleccionTituloPregunta_5007Parser == null) {
			EAttribute[] features = new EAttribute[] {
					dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getPregunta_TituloPregunta() };
			dsl_4webquiz.diagram.parsers.MessageFormatParser parser = new dsl_4webquiz.diagram.parsers.MessageFormatParser(
					features);
			seleccionTituloPregunta_5007Parser = parser;
		}
		return seleccionTituloPregunta_5007Parser;
	}

	/**
	* @generated
	*/
	private IParser opcionTituloPregunta_5006Parser;

	/**
	* @generated
	*/
	private IParser getOpcionTituloPregunta_5006Parser() {
		if (opcionTituloPregunta_5006Parser == null) {
			EAttribute[] features = new EAttribute[] {
					dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getOpcion_TituloPregunta() };
			dsl_4webquiz.diagram.parsers.MessageFormatParser parser = new dsl_4webquiz.diagram.parsers.MessageFormatParser(
					features);
			opcionTituloPregunta_5006Parser = parser;
		}
		return opcionTituloPregunta_5006Parser;
	}

	/**
	* @generated
	*/
	private IParser voFTituloPregunta_5008Parser;

	/**
	* @generated
	*/
	private IParser getVoFTituloPregunta_5008Parser() {
		if (voFTituloPregunta_5008Parser == null) {
			EAttribute[] features = new EAttribute[] {
					dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getPregunta_TituloPregunta() };
			dsl_4webquiz.diagram.parsers.MessageFormatParser parser = new dsl_4webquiz.diagram.parsers.MessageFormatParser(
					features);
			voFTituloPregunta_5008Parser = parser;
		}
		return voFTituloPregunta_5008Parser;
	}

	/**
	* @generated
	*/
	private IParser preguntaCortaTituloPregunta_5010Parser;

	/**
	* @generated
	*/
	private IParser getPreguntaCortaTituloPregunta_5010Parser() {
		if (preguntaCortaTituloPregunta_5010Parser == null) {
			EAttribute[] features = new EAttribute[] {
					dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getPregunta_TituloPregunta() };
			dsl_4webquiz.diagram.parsers.MessageFormatParser parser = new dsl_4webquiz.diagram.parsers.MessageFormatParser(
					features);
			preguntaCortaTituloPregunta_5010Parser = parser;
		}
		return preguntaCortaTituloPregunta_5010Parser;
	}

	/**
	* @generated
	*/
	private IParser seleccionTituloPregunta_5011Parser;

	/**
	* @generated
	*/
	private IParser getSeleccionTituloPregunta_5011Parser() {
		if (seleccionTituloPregunta_5011Parser == null) {
			EAttribute[] features = new EAttribute[] {
					dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getPregunta_TituloPregunta() };
			dsl_4webquiz.diagram.parsers.MessageFormatParser parser = new dsl_4webquiz.diagram.parsers.MessageFormatParser(
					features);
			seleccionTituloPregunta_5011Parser = parser;
		}
		return seleccionTituloPregunta_5011Parser;
	}

	/**
	* @generated
	*/
	private IParser voFTituloPregunta_5012Parser;

	/**
	* @generated
	*/
	private IParser getVoFTituloPregunta_5012Parser() {
		if (voFTituloPregunta_5012Parser == null) {
			EAttribute[] features = new EAttribute[] {
					dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getPregunta_TituloPregunta() };
			dsl_4webquiz.diagram.parsers.MessageFormatParser parser = new dsl_4webquiz.diagram.parsers.MessageFormatParser(
					features);
			voFTituloPregunta_5012Parser = parser;
		}
		return voFTituloPregunta_5012Parser;
	}

	/**
	* @generated
	*/
	private IParser atributoNombre_5021Parser;

	/**
	* @generated
	*/
	private IParser getAtributoNombre_5021Parser() {
		if (atributoNombre_5021Parser == null) {
			EAttribute[] features = new EAttribute[] {
					dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getAtributo_Nombre() };
			dsl_4webquiz.diagram.parsers.MessageFormatParser parser = new dsl_4webquiz.diagram.parsers.MessageFormatParser(
					features);
			atributoNombre_5021Parser = parser;
		}
		return atributoNombre_5021Parser;
	}

	/**
	* @generated
	*/
	protected IParser getParser(int visualID) {
		switch (visualID) {
		case dsl_4webquiz.diagram.edit.parts.IndiceTituloEditPart.VISUAL_ID:
			return getIndiceTitulo_5001Parser();
		case dsl_4webquiz.diagram.edit.parts.DetalleTituloEditPart.VISUAL_ID:
			return getDetalleTitulo_5002Parser();
		case dsl_4webquiz.diagram.edit.parts.CreacionTituloEditPart.VISUAL_ID:
			return getCreacionTitulo_5003Parser();
		case dsl_4webquiz.diagram.edit.parts.BorradoTituloEditPart.VISUAL_ID:
			return getBorradoTitulo_5004Parser();
		case dsl_4webquiz.diagram.edit.parts.EncuestaTituloEditPart.VISUAL_ID:
			return getEncuestaTitulo_5009Parser();
		case dsl_4webquiz.diagram.edit.parts.CuestionarioTituloEditPart.VISUAL_ID:
			return getCuestionarioTitulo_5013Parser();
		case dsl_4webquiz.diagram.edit.parts.CRUDTituloEditPart.VISUAL_ID:
			return getCRUDTitulo_5014Parser();
		case dsl_4webquiz.diagram.edit.parts.UpdateTituloEditPart.VISUAL_ID:
			return getUpdateTitulo_5015Parser();
		case dsl_4webquiz.diagram.edit.parts.HomeTituloEditPart.VISUAL_ID:
			return getHomeTitulo_5016Parser();
		case dsl_4webquiz.diagram.edit.parts.TwitterEnlaceEditPart.VISUAL_ID:
			return getTwitterEnlace_5017Parser();
		case dsl_4webquiz.diagram.edit.parts.Google_plusEnlaceEditPart.VISUAL_ID:
			return getGoogle_plusEnlace_5018Parser();
		case dsl_4webquiz.diagram.edit.parts.RSSEnlaceEditPart.VISUAL_ID:
			return getRSSEnlace_5019Parser();
		case dsl_4webquiz.diagram.edit.parts.UsuarioUsuarioEditPart.VISUAL_ID:
			return getUsuarioUsuario_5020Parser();
		case dsl_4webquiz.diagram.edit.parts.TipoDatosNombreEditPart.VISUAL_ID:
			return getTipoDatosNombre_5022Parser();
		case dsl_4webquiz.diagram.edit.parts.PreguntaCortaTituloPreguntaEditPart.VISUAL_ID:
			return getPreguntaCortaTituloPregunta_5005Parser();
		case dsl_4webquiz.diagram.edit.parts.SeleccionTituloPreguntaEditPart.VISUAL_ID:
			return getSeleccionTituloPregunta_5007Parser();
		case dsl_4webquiz.diagram.edit.parts.OpcionTituloPreguntaEditPart.VISUAL_ID:
			return getOpcionTituloPregunta_5006Parser();
		case dsl_4webquiz.diagram.edit.parts.VoFTituloPreguntaEditPart.VISUAL_ID:
			return getVoFTituloPregunta_5008Parser();
		case dsl_4webquiz.diagram.edit.parts.PreguntaCortaTituloPregunta2EditPart.VISUAL_ID:
			return getPreguntaCortaTituloPregunta_5010Parser();
		case dsl_4webquiz.diagram.edit.parts.SeleccionTituloPregunta2EditPart.VISUAL_ID:
			return getSeleccionTituloPregunta_5011Parser();
		case dsl_4webquiz.diagram.edit.parts.VoFTituloPregunta2EditPart.VISUAL_ID:
			return getVoFTituloPregunta_5012Parser();
		case dsl_4webquiz.diagram.edit.parts.AtributoNombreEditPart.VISUAL_ID:
			return getAtributoNombre_5021Parser();
		}
		return null;
	}

	/**
	* Utility method that consults ParserService
	* @generated
	*/
	public static IParser getParser(IElementType type, EObject object, String parserHint) {
		return ParserService.getInstance().getParser(new HintAdapter(type, object, parserHint));
	}

	/**
	* @generated
	*/
	public IParser getParser(IAdaptable hint) {
		String vid = (String) hint.getAdapter(String.class);
		if (vid != null) {
			return getParser(dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getVisualID(vid));
		}
		View view = (View) hint.getAdapter(View.class);
		if (view != null) {
			return getParser(dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getVisualID(view));
		}
		return null;
	}

	/**
	* @generated
	*/
	public boolean provides(IOperation operation) {
		if (operation instanceof GetParserOperation) {
			IAdaptable hint = ((GetParserOperation) operation).getHint();
			if (dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.getElement(hint) == null) {
				return false;
			}
			return getParser(hint) != null;
		}
		return false;
	}

	/**
	* @generated
	*/
	private static class HintAdapter extends ParserHintAdapter {

		/**
		* @generated
		*/
		private final IElementType elementType;

		/**
		* @generated
		*/
		public HintAdapter(IElementType type, EObject object, String parserHint) {
			super(object, parserHint);
			assert type != null;
			elementType = type;
		}

		/**
		* @generated
		*/
		public Object getAdapter(Class adapter) {
			if (IElementType.class.equals(adapter)) {
				return elementType;
			}
			return super.getAdapter(adapter);
		}
	}

}
