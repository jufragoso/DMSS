/*
 * 
 */
package dsl_4webquiz.diagram.providers;

import org.eclipse.gmf.tooling.runtime.providers.DefaultEditPartProvider;

/**
 * @generated
 */
public class Dsl_4webquizEditPartProvider extends DefaultEditPartProvider {

	/**
	* @generated
	*/
	public Dsl_4webquizEditPartProvider() {
		super(new dsl_4webquiz.diagram.edit.parts.Dsl_4webquizEditPartFactory(),
				dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.TYPED_INSTANCE,
				dsl_4webquiz.diagram.edit.parts.WebEditPart.MODEL_ID);
	}

}
