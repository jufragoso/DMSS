/*
 * 
 */
package dsl_4webquiz.diagram.providers;

/**
 * @generated
 */
public class ElementInitializers {

	protected ElementInitializers() {
		// use #getInstance to access cached instance
	}

	/**
	* @generated
	*/
	public static ElementInitializers getInstance() {
		ElementInitializers cached = dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance()
				.getElementInitializers();
		if (cached == null) {
			dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance()
					.setElementInitializers(cached = new ElementInitializers());
		}
		return cached;
	}
}
