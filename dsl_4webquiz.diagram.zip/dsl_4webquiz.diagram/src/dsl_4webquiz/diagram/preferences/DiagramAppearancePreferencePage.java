/*
 * 
 */
package dsl_4webquiz.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.AppearancePreferencePage;

/**
 * @generated
 */
public class DiagramAppearancePreferencePage extends AppearancePreferencePage {

	/**
	* @generated
	*/
	public DiagramAppearancePreferencePage() {
		setPreferenceStore(
				dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance().getPreferenceStore());
	}
}
