/*
 * 
 */
package dsl_4webquiz.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.RulerGridPreferencePage;

/**
 * @generated
 */
public class DiagramRulersAndGridPreferencePage extends RulerGridPreferencePage {

	/**
	* @generated
	*/
	public DiagramRulersAndGridPreferencePage() {
		setPreferenceStore(
				dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance().getPreferenceStore());
	}
}
