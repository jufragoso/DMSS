/*
 * 
 */
package dsl_4webquiz.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.DiagramsPreferencePage;

/**
 * @generated
 */
public class DiagramGeneralPreferencePage extends DiagramsPreferencePage {

	/**
	* @generated
	*/
	public DiagramGeneralPreferencePage() {
		setPreferenceStore(
				dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance().getPreferenceStore());
	}
}
