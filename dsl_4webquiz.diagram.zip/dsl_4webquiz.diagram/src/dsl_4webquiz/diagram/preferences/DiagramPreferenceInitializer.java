/*
 * 
 */
package dsl_4webquiz.diagram.preferences;

import org.eclipse.core.runtime.preferences.AbstractPreferenceInitializer;
import org.eclipse.jface.preference.IPreferenceStore;

/**
 * @generated
 */
public class DiagramPreferenceInitializer extends AbstractPreferenceInitializer {

	/**
	* @generated
	*/
	public void initializeDefaultPreferences() {
		IPreferenceStore store = getPreferenceStore();
		dsl_4webquiz.diagram.preferences.DiagramGeneralPreferencePage.initDefaults(store);
		dsl_4webquiz.diagram.preferences.DiagramAppearancePreferencePage.initDefaults(store);
		dsl_4webquiz.diagram.preferences.DiagramConnectionsPreferencePage.initDefaults(store);
		dsl_4webquiz.diagram.preferences.DiagramPrintingPreferencePage.initDefaults(store);
		dsl_4webquiz.diagram.preferences.DiagramRulersAndGridPreferencePage.initDefaults(store);

	}

	/**
	* @generated
	*/
	protected IPreferenceStore getPreferenceStore() {
		return dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance().getPreferenceStore();
	}
}
