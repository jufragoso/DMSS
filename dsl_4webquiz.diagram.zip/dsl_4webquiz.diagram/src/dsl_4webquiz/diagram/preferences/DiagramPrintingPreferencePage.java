/*
 * 
 */
package dsl_4webquiz.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.PrintingPreferencePage;

/**
 * @generated
 */
public class DiagramPrintingPreferencePage extends PrintingPreferencePage {

	/**
	* @generated
	*/
	public DiagramPrintingPreferencePage() {
		setPreferenceStore(
				dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance().getPreferenceStore());
	}
}
