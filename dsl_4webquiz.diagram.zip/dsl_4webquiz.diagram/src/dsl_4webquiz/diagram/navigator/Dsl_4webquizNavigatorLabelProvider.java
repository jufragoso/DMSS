/*
* 
*/
package dsl_4webquiz.diagram.navigator;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.gmf.runtime.common.ui.services.parser.CommonParserHint;
import org.eclipse.gmf.runtime.common.ui.services.parser.IParser;
import org.eclipse.gmf.runtime.common.ui.services.parser.ParserOptions;
import org.eclipse.gmf.runtime.emf.core.util.EObjectAdapter;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.jface.viewers.ITreePathLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TreePath;
import org.eclipse.jface.viewers.ViewerLabel;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.IMemento;
import org.eclipse.ui.navigator.ICommonContentExtensionSite;
import org.eclipse.ui.navigator.ICommonLabelProvider;

/**
 * @generated
 */
public class Dsl_4webquizNavigatorLabelProvider extends LabelProvider
		implements ICommonLabelProvider, ITreePathLabelProvider {

	/**
	* @generated
	*/
	static {
		dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance().getImageRegistry()
				.put("Navigator?UnknownElement", ImageDescriptor.getMissingImageDescriptor()); //$NON-NLS-1$
		dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance().getImageRegistry()
				.put("Navigator?ImageNotFound", ImageDescriptor.getMissingImageDescriptor()); //$NON-NLS-1$
	}

	/**
	* @generated
	*/
	public void updateLabel(ViewerLabel label, TreePath elementPath) {
		Object element = elementPath.getLastSegment();
		if (element instanceof dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorItem
				&& !isOwnView(((dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorItem) element).getView())) {
			return;
		}
		label.setText(getText(element));
		label.setImage(getImage(element));
	}

	/**
	* @generated
	*/
	public Image getImage(Object element) {
		if (element instanceof dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup) {
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup group = (dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup) element;
			return dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance()
					.getBundledImage(group.getIcon());
		}

		if (element instanceof dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorItem) {
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorItem navigatorItem = (dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorItem) element;
			if (!isOwnView(navigatorItem.getView())) {
				return super.getImage(element);
			}
			return getImage(navigatorItem.getView());
		}

		// Due to plugin.xml content will be called only for "own" views
		if (element instanceof IAdaptable) {
			View view = (View) ((IAdaptable) element).getAdapter(View.class);
			if (view != null && isOwnView(view)) {
				return getImage(view);
			}
		}

		return super.getImage(element);
	}

	/**
	* @generated
	*/
	public Image getImage(View view) {
		switch (dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getVisualID(view)) {
		case dsl_4webquiz.diagram.edit.parts.WebEditPart.VISUAL_ID:
			return getImage("Navigator?Diagram?http://www.example.org/dsl_4webquiz?Web", //$NON-NLS-1$
					dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Web_1000);
		case dsl_4webquiz.diagram.edit.parts.IndiceEditPart.VISUAL_ID:
			return getImage("Navigator?TopLevelNode?http://www.example.org/dsl_4webquiz?Indice", //$NON-NLS-1$
					dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Indice_2001);
		case dsl_4webquiz.diagram.edit.parts.DetalleEditPart.VISUAL_ID:
			return getImage("Navigator?TopLevelNode?http://www.example.org/dsl_4webquiz?Detalle", //$NON-NLS-1$
					dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Detalle_2002);
		case dsl_4webquiz.diagram.edit.parts.CreacionEditPart.VISUAL_ID:
			return getImage("Navigator?TopLevelNode?http://www.example.org/dsl_4webquiz?Creacion", //$NON-NLS-1$
					dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Creacion_2003);
		case dsl_4webquiz.diagram.edit.parts.BorradoEditPart.VISUAL_ID:
			return getImage("Navigator?TopLevelNode?http://www.example.org/dsl_4webquiz?Borrado", //$NON-NLS-1$
					dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Borrado_2004);
		case dsl_4webquiz.diagram.edit.parts.EncuestaEditPart.VISUAL_ID:
			return getImage("Navigator?TopLevelNode?http://www.example.org/dsl_4webquiz?Encuesta", //$NON-NLS-1$
					dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Encuesta_2005);
		case dsl_4webquiz.diagram.edit.parts.CuestionarioEditPart.VISUAL_ID:
			return getImage("Navigator?TopLevelNode?http://www.example.org/dsl_4webquiz?Cuestionario", //$NON-NLS-1$
					dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Cuestionario_2006);
		case dsl_4webquiz.diagram.edit.parts.CRUDEditPart.VISUAL_ID:
			return getImage("Navigator?TopLevelNode?http://www.example.org/dsl_4webquiz?CRUD", //$NON-NLS-1$
					dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.CRUD_2007);
		case dsl_4webquiz.diagram.edit.parts.UpdateEditPart.VISUAL_ID:
			return getImage("Navigator?TopLevelNode?http://www.example.org/dsl_4webquiz?Update", //$NON-NLS-1$
					dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Update_2008);
		case dsl_4webquiz.diagram.edit.parts.HomeEditPart.VISUAL_ID:
			return getImage("Navigator?TopLevelNode?http://www.example.org/dsl_4webquiz?Home", //$NON-NLS-1$
					dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Home_2009);
		case dsl_4webquiz.diagram.edit.parts.TwitterEditPart.VISUAL_ID:
			return getImage("Navigator?TopLevelNode?http://www.example.org/dsl_4webquiz?Twitter", //$NON-NLS-1$
					dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Twitter_2010);
		case dsl_4webquiz.diagram.edit.parts.Google_plusEditPart.VISUAL_ID:
			return getImage("Navigator?TopLevelNode?http://www.example.org/dsl_4webquiz?Google_plus", //$NON-NLS-1$
					dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Google_plus_2011);
		case dsl_4webquiz.diagram.edit.parts.RSSEditPart.VISUAL_ID:
			return getImage("Navigator?TopLevelNode?http://www.example.org/dsl_4webquiz?RSS", //$NON-NLS-1$
					dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.RSS_2012);
		case dsl_4webquiz.diagram.edit.parts.UsuarioEditPart.VISUAL_ID:
			return getImage("Navigator?TopLevelNode?http://www.example.org/dsl_4webquiz?Usuario", //$NON-NLS-1$
					dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Usuario_2013);
		case dsl_4webquiz.diagram.edit.parts.TipoDatosEditPart.VISUAL_ID:
			return getImage("Navigator?TopLevelNode?http://www.example.org/dsl_4webquiz?TipoDatos", //$NON-NLS-1$
					dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.TipoDatos_2014);
		case dsl_4webquiz.diagram.edit.parts.PreguntaCortaEditPart.VISUAL_ID:
			return getImage("Navigator?Node?http://www.example.org/dsl_4webquiz?PreguntaCorta", //$NON-NLS-1$
					dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PreguntaCorta_3001);
		case dsl_4webquiz.diagram.edit.parts.SeleccionEditPart.VISUAL_ID:
			return getImage("Navigator?Node?http://www.example.org/dsl_4webquiz?Seleccion", //$NON-NLS-1$
					dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Seleccion_3002);
		case dsl_4webquiz.diagram.edit.parts.OpcionEditPart.VISUAL_ID:
			return getImage("Navigator?Node?http://www.example.org/dsl_4webquiz?Opcion", //$NON-NLS-1$
					dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Opcion_3003);
		case dsl_4webquiz.diagram.edit.parts.VoFEditPart.VISUAL_ID:
			return getImage("Navigator?Node?http://www.example.org/dsl_4webquiz?VoF", //$NON-NLS-1$
					dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.VoF_3004);
		case dsl_4webquiz.diagram.edit.parts.PreguntaCorta2EditPart.VISUAL_ID:
			return getImage("Navigator?Node?http://www.example.org/dsl_4webquiz?PreguntaCorta", //$NON-NLS-1$
					dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PreguntaCorta_3005);
		case dsl_4webquiz.diagram.edit.parts.Seleccion2EditPart.VISUAL_ID:
			return getImage("Navigator?Node?http://www.example.org/dsl_4webquiz?Seleccion", //$NON-NLS-1$
					dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Seleccion_3006);
		case dsl_4webquiz.diagram.edit.parts.VoF2EditPart.VISUAL_ID:
			return getImage("Navigator?Node?http://www.example.org/dsl_4webquiz?VoF", //$NON-NLS-1$
					dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.VoF_3007);
		case dsl_4webquiz.diagram.edit.parts.AtributoEditPart.VISUAL_ID:
			return getImage("Navigator?Node?http://www.example.org/dsl_4webquiz?Atributo", //$NON-NLS-1$
					dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Atributo_3008);
		case dsl_4webquiz.diagram.edit.parts.PaginaRedes_socialesEditPart.VISUAL_ID:
			return getImage("Navigator?Link?http://www.example.org/dsl_4webquiz?Pagina?redes_sociales", //$NON-NLS-1$
					dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PaginaRedes_sociales_4001);
		case dsl_4webquiz.diagram.edit.parts.PAGINAS_CRUDHomeEditPart.VISUAL_ID:
			return getImage("Navigator?Link?http://www.example.org/dsl_4webquiz?PAGINAS_CRUD?home", //$NON-NLS-1$
					dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PAGINAS_CRUDHome_4002);
		case dsl_4webquiz.diagram.edit.parts.HomeCrudEditPart.VISUAL_ID:
			return getImage("Navigator?Link?http://www.example.org/dsl_4webquiz?Home?crud", //$NON-NLS-1$
					dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.HomeCrud_4003);
		case dsl_4webquiz.diagram.edit.parts.HomeConsultaEditPart.VISUAL_ID:
			return getImage("Navigator?Link?http://www.example.org/dsl_4webquiz?Home?consulta", //$NON-NLS-1$
					dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.HomeConsulta_4004);
		case dsl_4webquiz.diagram.edit.parts.ConsultaHomeEditPart.VISUAL_ID:
			return getImage("Navigator?Link?http://www.example.org/dsl_4webquiz?Consulta?home", //$NON-NLS-1$
					dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.ConsultaHome_4005);
		case dsl_4webquiz.diagram.edit.parts.PAGINAS_CRUDTipodatosEditPart.VISUAL_ID:
			return getImage("Navigator?Link?http://www.example.org/dsl_4webquiz?PAGINAS_CRUD?tipodatos", //$NON-NLS-1$
					dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PAGINAS_CRUDTipodatos_4006);
		}
		return getImage("Navigator?UnknownElement", null); //$NON-NLS-1$
	}

	/**
	* @generated
	*/
	private Image getImage(String key, IElementType elementType) {
		ImageRegistry imageRegistry = dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance()
				.getImageRegistry();
		Image image = imageRegistry.get(key);
		if (image == null && elementType != null
				&& dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.isKnownElementType(elementType)) {
			image = dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.getImage(elementType);
			imageRegistry.put(key, image);
		}

		if (image == null) {
			image = imageRegistry.get("Navigator?ImageNotFound"); //$NON-NLS-1$
			imageRegistry.put(key, image);
		}
		return image;
	}

	/**
	* @generated
	*/
	public String getText(Object element) {
		if (element instanceof dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup) {
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup group = (dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup) element;
			return group.getGroupName();
		}

		if (element instanceof dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorItem) {
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorItem navigatorItem = (dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorItem) element;
			if (!isOwnView(navigatorItem.getView())) {
				return null;
			}
			return getText(navigatorItem.getView());
		}

		// Due to plugin.xml content will be called only for "own" views
		if (element instanceof IAdaptable) {
			View view = (View) ((IAdaptable) element).getAdapter(View.class);
			if (view != null && isOwnView(view)) {
				return getText(view);
			}
		}

		return super.getText(element);
	}

	/**
	* @generated
	*/
	public String getText(View view) {
		if (view.getElement() != null && view.getElement().eIsProxy()) {
			return getUnresolvedDomainElementProxyText(view);
		}
		switch (dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getVisualID(view)) {
		case dsl_4webquiz.diagram.edit.parts.WebEditPart.VISUAL_ID:
			return getWeb_1000Text(view);
		case dsl_4webquiz.diagram.edit.parts.IndiceEditPart.VISUAL_ID:
			return getIndice_2001Text(view);
		case dsl_4webquiz.diagram.edit.parts.DetalleEditPart.VISUAL_ID:
			return getDetalle_2002Text(view);
		case dsl_4webquiz.diagram.edit.parts.CreacionEditPart.VISUAL_ID:
			return getCreacion_2003Text(view);
		case dsl_4webquiz.diagram.edit.parts.BorradoEditPart.VISUAL_ID:
			return getBorrado_2004Text(view);
		case dsl_4webquiz.diagram.edit.parts.EncuestaEditPart.VISUAL_ID:
			return getEncuesta_2005Text(view);
		case dsl_4webquiz.diagram.edit.parts.CuestionarioEditPart.VISUAL_ID:
			return getCuestionario_2006Text(view);
		case dsl_4webquiz.diagram.edit.parts.CRUDEditPart.VISUAL_ID:
			return getCRUD_2007Text(view);
		case dsl_4webquiz.diagram.edit.parts.UpdateEditPart.VISUAL_ID:
			return getUpdate_2008Text(view);
		case dsl_4webquiz.diagram.edit.parts.HomeEditPart.VISUAL_ID:
			return getHome_2009Text(view);
		case dsl_4webquiz.diagram.edit.parts.TwitterEditPart.VISUAL_ID:
			return getTwitter_2010Text(view);
		case dsl_4webquiz.diagram.edit.parts.Google_plusEditPart.VISUAL_ID:
			return getGoogle_plus_2011Text(view);
		case dsl_4webquiz.diagram.edit.parts.RSSEditPart.VISUAL_ID:
			return getRSS_2012Text(view);
		case dsl_4webquiz.diagram.edit.parts.UsuarioEditPart.VISUAL_ID:
			return getUsuario_2013Text(view);
		case dsl_4webquiz.diagram.edit.parts.TipoDatosEditPart.VISUAL_ID:
			return getTipoDatos_2014Text(view);
		case dsl_4webquiz.diagram.edit.parts.PreguntaCortaEditPart.VISUAL_ID:
			return getPreguntaCorta_3001Text(view);
		case dsl_4webquiz.diagram.edit.parts.SeleccionEditPart.VISUAL_ID:
			return getSeleccion_3002Text(view);
		case dsl_4webquiz.diagram.edit.parts.OpcionEditPart.VISUAL_ID:
			return getOpcion_3003Text(view);
		case dsl_4webquiz.diagram.edit.parts.VoFEditPart.VISUAL_ID:
			return getVoF_3004Text(view);
		case dsl_4webquiz.diagram.edit.parts.PreguntaCorta2EditPart.VISUAL_ID:
			return getPreguntaCorta_3005Text(view);
		case dsl_4webquiz.diagram.edit.parts.Seleccion2EditPart.VISUAL_ID:
			return getSeleccion_3006Text(view);
		case dsl_4webquiz.diagram.edit.parts.VoF2EditPart.VISUAL_ID:
			return getVoF_3007Text(view);
		case dsl_4webquiz.diagram.edit.parts.AtributoEditPart.VISUAL_ID:
			return getAtributo_3008Text(view);
		case dsl_4webquiz.diagram.edit.parts.PaginaRedes_socialesEditPart.VISUAL_ID:
			return getPaginaRedes_sociales_4001Text(view);
		case dsl_4webquiz.diagram.edit.parts.PAGINAS_CRUDHomeEditPart.VISUAL_ID:
			return getPAGINAS_CRUDHome_4002Text(view);
		case dsl_4webquiz.diagram.edit.parts.HomeCrudEditPart.VISUAL_ID:
			return getHomeCrud_4003Text(view);
		case dsl_4webquiz.diagram.edit.parts.HomeConsultaEditPart.VISUAL_ID:
			return getHomeConsulta_4004Text(view);
		case dsl_4webquiz.diagram.edit.parts.ConsultaHomeEditPart.VISUAL_ID:
			return getConsultaHome_4005Text(view);
		case dsl_4webquiz.diagram.edit.parts.PAGINAS_CRUDTipodatosEditPart.VISUAL_ID:
			return getPAGINAS_CRUDTipodatos_4006Text(view);
		}
		return getUnknownElementText(view);
	}

	/**
	* @generated
	*/
	private String getWeb_1000Text(View view) {
		dsl_4webquiz.Web domainModelElement = (dsl_4webquiz.Web) view.getElement();
		if (domainModelElement != null) {
			return domainModelElement.getNombre();
		} else {
			dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance()
					.logError("No domain element for view with visualID = " + 1000); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getIndice_2001Text(View view) {
		IParser parser = dsl_4webquiz.diagram.providers.Dsl_4webquizParserProvider.getParser(
				dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Indice_2001,
				view.getElement() != null ? view.getElement() : view,
				dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
						.getType(dsl_4webquiz.diagram.edit.parts.IndiceTituloEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5001); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getDetalle_2002Text(View view) {
		IParser parser = dsl_4webquiz.diagram.providers.Dsl_4webquizParserProvider.getParser(
				dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Detalle_2002,
				view.getElement() != null ? view.getElement() : view,
				dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
						.getType(dsl_4webquiz.diagram.edit.parts.DetalleTituloEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5002); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getCreacion_2003Text(View view) {
		IParser parser = dsl_4webquiz.diagram.providers.Dsl_4webquizParserProvider.getParser(
				dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Creacion_2003,
				view.getElement() != null ? view.getElement() : view,
				dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
						.getType(dsl_4webquiz.diagram.edit.parts.CreacionTituloEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5003); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getBorrado_2004Text(View view) {
		IParser parser = dsl_4webquiz.diagram.providers.Dsl_4webquizParserProvider.getParser(
				dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Borrado_2004,
				view.getElement() != null ? view.getElement() : view,
				dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
						.getType(dsl_4webquiz.diagram.edit.parts.BorradoTituloEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5004); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getEncuesta_2005Text(View view) {
		IParser parser = dsl_4webquiz.diagram.providers.Dsl_4webquizParserProvider.getParser(
				dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Encuesta_2005,
				view.getElement() != null ? view.getElement() : view,
				dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
						.getType(dsl_4webquiz.diagram.edit.parts.EncuestaTituloEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5009); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getCuestionario_2006Text(View view) {
		IParser parser = dsl_4webquiz.diagram.providers.Dsl_4webquizParserProvider.getParser(
				dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Cuestionario_2006,
				view.getElement() != null ? view.getElement() : view,
				dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
						.getType(dsl_4webquiz.diagram.edit.parts.CuestionarioTituloEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5013); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getCRUD_2007Text(View view) {
		IParser parser = dsl_4webquiz.diagram.providers.Dsl_4webquizParserProvider.getParser(
				dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.CRUD_2007,
				view.getElement() != null ? view.getElement() : view,
				dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
						.getType(dsl_4webquiz.diagram.edit.parts.CRUDTituloEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5014); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getUpdate_2008Text(View view) {
		IParser parser = dsl_4webquiz.diagram.providers.Dsl_4webquizParserProvider.getParser(
				dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Update_2008,
				view.getElement() != null ? view.getElement() : view,
				dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
						.getType(dsl_4webquiz.diagram.edit.parts.UpdateTituloEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5015); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getHome_2009Text(View view) {
		IParser parser = dsl_4webquiz.diagram.providers.Dsl_4webquizParserProvider.getParser(
				dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Home_2009,
				view.getElement() != null ? view.getElement() : view,
				dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
						.getType(dsl_4webquiz.diagram.edit.parts.HomeTituloEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5016); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getTwitter_2010Text(View view) {
		IParser parser = dsl_4webquiz.diagram.providers.Dsl_4webquizParserProvider.getParser(
				dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Twitter_2010,
				view.getElement() != null ? view.getElement() : view,
				dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
						.getType(dsl_4webquiz.diagram.edit.parts.TwitterEnlaceEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5017); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getGoogle_plus_2011Text(View view) {
		IParser parser = dsl_4webquiz.diagram.providers.Dsl_4webquizParserProvider.getParser(
				dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Google_plus_2011,
				view.getElement() != null ? view.getElement() : view,
				dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
						.getType(dsl_4webquiz.diagram.edit.parts.Google_plusEnlaceEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5018); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getRSS_2012Text(View view) {
		IParser parser = dsl_4webquiz.diagram.providers.Dsl_4webquizParserProvider.getParser(
				dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.RSS_2012,
				view.getElement() != null ? view.getElement() : view,
				dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
						.getType(dsl_4webquiz.diagram.edit.parts.RSSEnlaceEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5019); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getUsuario_2013Text(View view) {
		IParser parser = dsl_4webquiz.diagram.providers.Dsl_4webquizParserProvider.getParser(
				dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Usuario_2013,
				view.getElement() != null ? view.getElement() : view,
				dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
						.getType(dsl_4webquiz.diagram.edit.parts.UsuarioUsuarioEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5020); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getTipoDatos_2014Text(View view) {
		IParser parser = dsl_4webquiz.diagram.providers.Dsl_4webquizParserProvider.getParser(
				dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.TipoDatos_2014,
				view.getElement() != null ? view.getElement() : view,
				dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
						.getType(dsl_4webquiz.diagram.edit.parts.TipoDatosNombreEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5022); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getPreguntaCorta_3001Text(View view) {
		IParser parser = dsl_4webquiz.diagram.providers.Dsl_4webquizParserProvider.getParser(
				dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PreguntaCorta_3001,
				view.getElement() != null ? view.getElement() : view,
				dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
						.getType(dsl_4webquiz.diagram.edit.parts.PreguntaCortaTituloPreguntaEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5005); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getSeleccion_3002Text(View view) {
		IParser parser = dsl_4webquiz.diagram.providers.Dsl_4webquizParserProvider.getParser(
				dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Seleccion_3002,
				view.getElement() != null ? view.getElement() : view,
				dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
						.getType(dsl_4webquiz.diagram.edit.parts.SeleccionTituloPreguntaEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5007); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getOpcion_3003Text(View view) {
		IParser parser = dsl_4webquiz.diagram.providers.Dsl_4webquizParserProvider.getParser(
				dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Opcion_3003,
				view.getElement() != null ? view.getElement() : view,
				dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
						.getType(dsl_4webquiz.diagram.edit.parts.OpcionTituloPreguntaEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5006); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getVoF_3004Text(View view) {
		IParser parser = dsl_4webquiz.diagram.providers.Dsl_4webquizParserProvider.getParser(
				dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.VoF_3004,
				view.getElement() != null ? view.getElement() : view,
				dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
						.getType(dsl_4webquiz.diagram.edit.parts.VoFTituloPreguntaEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5008); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getPreguntaCorta_3005Text(View view) {
		IParser parser = dsl_4webquiz.diagram.providers.Dsl_4webquizParserProvider.getParser(
				dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PreguntaCorta_3005,
				view.getElement() != null ? view.getElement() : view,
				dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
						.getType(dsl_4webquiz.diagram.edit.parts.PreguntaCortaTituloPregunta2EditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5010); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getSeleccion_3006Text(View view) {
		IParser parser = dsl_4webquiz.diagram.providers.Dsl_4webquizParserProvider.getParser(
				dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Seleccion_3006,
				view.getElement() != null ? view.getElement() : view,
				dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
						.getType(dsl_4webquiz.diagram.edit.parts.SeleccionTituloPregunta2EditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5011); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getVoF_3007Text(View view) {
		IParser parser = dsl_4webquiz.diagram.providers.Dsl_4webquizParserProvider.getParser(
				dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.VoF_3007,
				view.getElement() != null ? view.getElement() : view,
				dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
						.getType(dsl_4webquiz.diagram.edit.parts.VoFTituloPregunta2EditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5012); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getAtributo_3008Text(View view) {
		IParser parser = dsl_4webquiz.diagram.providers.Dsl_4webquizParserProvider.getParser(
				dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Atributo_3008,
				view.getElement() != null ? view.getElement() : view,
				dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
						.getType(dsl_4webquiz.diagram.edit.parts.AtributoNombreEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 5021); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getPaginaRedes_sociales_4001Text(View view) {
		IParser parser = dsl_4webquiz.diagram.providers.Dsl_4webquizParserProvider.getParser(
				dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PaginaRedes_sociales_4001,
				view.getElement() != null ? view.getElement() : view, CommonParserHint.DESCRIPTION);
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 6001); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getPAGINAS_CRUDHome_4002Text(View view) {
		IParser parser = dsl_4webquiz.diagram.providers.Dsl_4webquizParserProvider.getParser(
				dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PAGINAS_CRUDHome_4002,
				view.getElement() != null ? view.getElement() : view, CommonParserHint.DESCRIPTION);
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 6002); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getHomeCrud_4003Text(View view) {
		IParser parser = dsl_4webquiz.diagram.providers.Dsl_4webquizParserProvider.getParser(
				dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.HomeCrud_4003,
				view.getElement() != null ? view.getElement() : view, CommonParserHint.DESCRIPTION);
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 6003); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getHomeConsulta_4004Text(View view) {
		IParser parser = dsl_4webquiz.diagram.providers.Dsl_4webquizParserProvider.getParser(
				dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.HomeConsulta_4004,
				view.getElement() != null ? view.getElement() : view, CommonParserHint.DESCRIPTION);
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 6004); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getConsultaHome_4005Text(View view) {
		IParser parser = dsl_4webquiz.diagram.providers.Dsl_4webquizParserProvider.getParser(
				dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.ConsultaHome_4005,
				view.getElement() != null ? view.getElement() : view, CommonParserHint.DESCRIPTION);
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 6005); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getPAGINAS_CRUDTipodatos_4006Text(View view) {
		IParser parser = dsl_4webquiz.diagram.providers.Dsl_4webquizParserProvider.getParser(
				dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PAGINAS_CRUDTipodatos_4006,
				view.getElement() != null ? view.getElement() : view, CommonParserHint.DESCRIPTION);
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance()
					.logError("Parser was not found for label " + 6006); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	* @generated
	*/
	private String getUnknownElementText(View view) {
		return "<UnknownElement Visual_ID = " + view.getType() + ">"; //$NON-NLS-1$  //$NON-NLS-2$
	}

	/**
	* @generated
	*/
	private String getUnresolvedDomainElementProxyText(View view) {
		return "<Unresolved domain element Visual_ID = " + view.getType() + ">"; //$NON-NLS-1$  //$NON-NLS-2$
	}

	/**
	* @generated
	*/
	public void init(ICommonContentExtensionSite aConfig) {
	}

	/**
	* @generated
	*/
	public void restoreState(IMemento aMemento) {
	}

	/**
	* @generated
	*/
	public void saveState(IMemento aMemento) {
	}

	/**
	* @generated
	*/
	public String getDescription(Object anElement) {
		return null;
	}

	/**
	* @generated
	*/
	private boolean isOwnView(View view) {
		return dsl_4webquiz.diagram.edit.parts.WebEditPart.MODEL_ID
				.equals(dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getModelID(view));
	}

}
