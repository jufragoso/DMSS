/*
* 
*/
package dsl_4webquiz.diagram.navigator;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.edit.domain.AdapterFactoryEditingDomain;
import org.eclipse.emf.transaction.TransactionalEditingDomain;
import org.eclipse.emf.workspace.util.WorkspaceSynchronizer;
import org.eclipse.gmf.runtime.emf.core.GMFEditingDomainFactory;
import org.eclipse.gmf.runtime.notation.Diagram;
import org.eclipse.gmf.runtime.notation.Edge;
import org.eclipse.gmf.runtime.notation.Node;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.ui.IMemento;
import org.eclipse.ui.navigator.ICommonContentExtensionSite;
import org.eclipse.ui.navigator.ICommonContentProvider;

/**
 * @generated
 */
public class Dsl_4webquizNavigatorContentProvider implements ICommonContentProvider {

	/**
	* @generated
	*/
	private static final Object[] EMPTY_ARRAY = new Object[0];

	/**
	* @generated
	*/
	private Viewer myViewer;

	/**
	* @generated
	*/
	private AdapterFactoryEditingDomain myEditingDomain;

	/**
	* @generated
	*/
	private WorkspaceSynchronizer myWorkspaceSynchronizer;

	/**
	* @generated
	*/
	private Runnable myViewerRefreshRunnable;

	/**
	* @generated
	*/
	@SuppressWarnings({ "unchecked", "serial", "rawtypes" })
	public Dsl_4webquizNavigatorContentProvider() {
		TransactionalEditingDomain editingDomain = GMFEditingDomainFactory.INSTANCE.createEditingDomain();
		myEditingDomain = (AdapterFactoryEditingDomain) editingDomain;
		myEditingDomain.setResourceToReadOnlyMap(new HashMap() {
			public Object get(Object key) {
				if (!containsKey(key)) {
					put(key, Boolean.TRUE);
				}
				return super.get(key);
			}
		});
		myViewerRefreshRunnable = new Runnable() {
			public void run() {
				if (myViewer != null) {
					myViewer.refresh();
				}
			}
		};
		myWorkspaceSynchronizer = new WorkspaceSynchronizer(editingDomain, new WorkspaceSynchronizer.Delegate() {
			public void dispose() {
			}

			public boolean handleResourceChanged(final Resource resource) {
				unloadAllResources();
				asyncRefresh();
				return true;
			}

			public boolean handleResourceDeleted(Resource resource) {
				unloadAllResources();
				asyncRefresh();
				return true;
			}

			public boolean handleResourceMoved(Resource resource, final URI newURI) {
				unloadAllResources();
				asyncRefresh();
				return true;
			}
		});
	}

	/**
	* @generated
	*/
	public void dispose() {
		myWorkspaceSynchronizer.dispose();
		myWorkspaceSynchronizer = null;
		myViewerRefreshRunnable = null;
		myViewer = null;
		unloadAllResources();
		((TransactionalEditingDomain) myEditingDomain).dispose();
		myEditingDomain = null;
	}

	/**
	* @generated
	*/
	public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
		myViewer = viewer;
	}

	/**
	* @generated
	*/
	void unloadAllResources() {
		for (Resource nextResource : myEditingDomain.getResourceSet().getResources()) {
			nextResource.unload();
		}
	}

	/**
	* @generated
	*/
	void asyncRefresh() {
		if (myViewer != null && !myViewer.getControl().isDisposed()) {
			myViewer.getControl().getDisplay().asyncExec(myViewerRefreshRunnable);
		}
	}

	/**
	* @generated
	*/
	public Object[] getElements(Object inputElement) {
		return getChildren(inputElement);
	}

	/**
	* @generated
	*/
	public void restoreState(IMemento aMemento) {
	}

	/**
	 * @generated
	 */
	public void saveState(IMemento aMemento) {
	}

	/**
	* @generated
	*/
	public void init(ICommonContentExtensionSite aConfig) {
	}

	/**
	* @generated
	*/
	public Object[] getChildren(Object parentElement) {
		if (parentElement instanceof IFile) {
			IFile file = (IFile) parentElement;
			URI fileURI = URI.createPlatformResourceURI(file.getFullPath().toString(), true);
			Resource resource = myEditingDomain.getResourceSet().getResource(fileURI, true);
			ArrayList<dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorItem> result = new ArrayList<dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorItem>();
			ArrayList<View> topViews = new ArrayList<View>(resource.getContents().size());
			for (EObject o : resource.getContents()) {
				if (o instanceof View) {
					topViews.add((View) o);
				}
			}
			result.addAll(createNavigatorItems(
					selectViewsByType(topViews, dsl_4webquiz.diagram.edit.parts.WebEditPart.MODEL_ID), file, false));
			return result.toArray();
		}

		if (parentElement instanceof dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup) {
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup group = (dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup) parentElement;
			return group.getChildren();
		}

		if (parentElement instanceof dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorItem) {
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorItem navigatorItem = (dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorItem) parentElement;
			if (navigatorItem.isLeaf() || !isOwnView(navigatorItem.getView())) {
				return EMPTY_ARRAY;
			}
			return getViewChildren(navigatorItem.getView(), parentElement);
		}

		/*
		* Due to plugin.xml restrictions this code will be called only for views representing
		* shortcuts to this diagram elements created on other diagrams. 
		*/
		if (parentElement instanceof IAdaptable) {
			View view = (View) ((IAdaptable) parentElement).getAdapter(View.class);
			if (view != null) {
				return getViewChildren(view, parentElement);
			}
		}

		return EMPTY_ARRAY;
	}

	/**
	* @generated
	*/
	private Object[] getViewChildren(View view, Object parentElement) {
		switch (dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getVisualID(view)) {

		case dsl_4webquiz.diagram.edit.parts.WebEditPart.VISUAL_ID: {
			LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem> result = new LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem>();
			result.addAll(getForeignShortcuts((Diagram) view, parentElement));
			Diagram sv = (Diagram) view;
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup links = new dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup(
					dsl_4webquiz.diagram.part.Messages.NavigatorGroupName_Web_1000_links,
					"icons/linksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getChildrenByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.IndiceEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.DetalleEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.CreacionEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.BorradoEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.EncuestaEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.CuestionarioEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.CRUDEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.UpdateEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.HomeEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.TwitterEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.Google_plusEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.RSSEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.UsuarioEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.TipoDatosEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getDiagramLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.PaginaRedes_socialesEditPart.VISUAL_ID));
			links.addChildren(createNavigatorItems(connectedViews, links, false));
			connectedViews = getDiagramLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.PAGINAS_CRUDHomeEditPart.VISUAL_ID));
			links.addChildren(createNavigatorItems(connectedViews, links, false));
			connectedViews = getDiagramLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.PAGINAS_CRUDTipodatosEditPart.VISUAL_ID));
			links.addChildren(createNavigatorItems(connectedViews, links, false));
			connectedViews = getDiagramLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.HomeCrudEditPart.VISUAL_ID));
			links.addChildren(createNavigatorItems(connectedViews, links, false));
			connectedViews = getDiagramLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.HomeConsultaEditPart.VISUAL_ID));
			links.addChildren(createNavigatorItems(connectedViews, links, false));
			connectedViews = getDiagramLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.ConsultaHomeEditPart.VISUAL_ID));
			links.addChildren(createNavigatorItems(connectedViews, links, false));
			if (!links.isEmpty()) {
				result.add(links);
			}
			return result.toArray();
		}

		case dsl_4webquiz.diagram.edit.parts.IndiceEditPart.VISUAL_ID: {
			LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem> result = new LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem>();
			Node sv = (Node) view;
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup outgoinglinks = new dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup(
					dsl_4webquiz.diagram.part.Messages.NavigatorGroupName_Indice_2001_outgoinglinks,
					"icons/outgoingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup incominglinks = new dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup(
					dsl_4webquiz.diagram.part.Messages.NavigatorGroupName_Indice_2001_incominglinks,
					"icons/incomingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.PaginaRedes_socialesEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.PAGINAS_CRUDHomeEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.PAGINAS_CRUDTipodatosEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			connectedViews = getIncomingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.HomeCrudEditPart.VISUAL_ID));
			incominglinks.addChildren(createNavigatorItems(connectedViews, incominglinks, true));
			if (!outgoinglinks.isEmpty()) {
				result.add(outgoinglinks);
			}
			if (!incominglinks.isEmpty()) {
				result.add(incominglinks);
			}
			return result.toArray();
		}

		case dsl_4webquiz.diagram.edit.parts.DetalleEditPart.VISUAL_ID: {
			LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem> result = new LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem>();
			Node sv = (Node) view;
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup outgoinglinks = new dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup(
					dsl_4webquiz.diagram.part.Messages.NavigatorGroupName_Detalle_2002_outgoinglinks,
					"icons/outgoingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup incominglinks = new dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup(
					dsl_4webquiz.diagram.part.Messages.NavigatorGroupName_Detalle_2002_incominglinks,
					"icons/incomingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.PaginaRedes_socialesEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.PAGINAS_CRUDHomeEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.PAGINAS_CRUDTipodatosEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			connectedViews = getIncomingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.HomeCrudEditPart.VISUAL_ID));
			incominglinks.addChildren(createNavigatorItems(connectedViews, incominglinks, true));
			if (!outgoinglinks.isEmpty()) {
				result.add(outgoinglinks);
			}
			if (!incominglinks.isEmpty()) {
				result.add(incominglinks);
			}
			return result.toArray();
		}

		case dsl_4webquiz.diagram.edit.parts.CreacionEditPart.VISUAL_ID: {
			LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem> result = new LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem>();
			Node sv = (Node) view;
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup outgoinglinks = new dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup(
					dsl_4webquiz.diagram.part.Messages.NavigatorGroupName_Creacion_2003_outgoinglinks,
					"icons/outgoingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup incominglinks = new dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup(
					dsl_4webquiz.diagram.part.Messages.NavigatorGroupName_Creacion_2003_incominglinks,
					"icons/incomingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.PaginaRedes_socialesEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.PAGINAS_CRUDHomeEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.PAGINAS_CRUDTipodatosEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			connectedViews = getIncomingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.HomeCrudEditPart.VISUAL_ID));
			incominglinks.addChildren(createNavigatorItems(connectedViews, incominglinks, true));
			if (!outgoinglinks.isEmpty()) {
				result.add(outgoinglinks);
			}
			if (!incominglinks.isEmpty()) {
				result.add(incominglinks);
			}
			return result.toArray();
		}

		case dsl_4webquiz.diagram.edit.parts.BorradoEditPart.VISUAL_ID: {
			LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem> result = new LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem>();
			Node sv = (Node) view;
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup outgoinglinks = new dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup(
					dsl_4webquiz.diagram.part.Messages.NavigatorGroupName_Borrado_2004_outgoinglinks,
					"icons/outgoingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup incominglinks = new dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup(
					dsl_4webquiz.diagram.part.Messages.NavigatorGroupName_Borrado_2004_incominglinks,
					"icons/incomingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.PaginaRedes_socialesEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.PAGINAS_CRUDHomeEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.PAGINAS_CRUDTipodatosEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			connectedViews = getIncomingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.HomeCrudEditPart.VISUAL_ID));
			incominglinks.addChildren(createNavigatorItems(connectedViews, incominglinks, true));
			if (!outgoinglinks.isEmpty()) {
				result.add(outgoinglinks);
			}
			if (!incominglinks.isEmpty()) {
				result.add(incominglinks);
			}
			return result.toArray();
		}

		case dsl_4webquiz.diagram.edit.parts.EncuestaEditPart.VISUAL_ID: {
			LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem> result = new LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem>();
			Node sv = (Node) view;
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup outgoinglinks = new dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup(
					dsl_4webquiz.diagram.part.Messages.NavigatorGroupName_Encuesta_2005_outgoinglinks,
					"icons/outgoingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup incominglinks = new dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup(
					dsl_4webquiz.diagram.part.Messages.NavigatorGroupName_Encuesta_2005_incominglinks,
					"icons/incomingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getChildrenByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getType(
							dsl_4webquiz.diagram.edit.parts.EncuestaEncuestaPreguntaEncuestaCompartmentEditPart.VISUAL_ID));
			connectedViews = getChildrenByType(connectedViews, dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
					.getType(dsl_4webquiz.diagram.edit.parts.PreguntaCortaEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getType(
							dsl_4webquiz.diagram.edit.parts.EncuestaEncuestaPreguntaEncuestaCompartmentEditPart.VISUAL_ID));
			connectedViews = getChildrenByType(connectedViews, dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
					.getType(dsl_4webquiz.diagram.edit.parts.SeleccionEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getType(
							dsl_4webquiz.diagram.edit.parts.EncuestaEncuestaPreguntaEncuestaCompartmentEditPart.VISUAL_ID));
			connectedViews = getChildrenByType(connectedViews, dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
					.getType(dsl_4webquiz.diagram.edit.parts.VoFEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.PaginaRedes_socialesEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			connectedViews = getIncomingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.HomeConsultaEditPart.VISUAL_ID));
			incominglinks.addChildren(createNavigatorItems(connectedViews, incominglinks, true));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.ConsultaHomeEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			if (!outgoinglinks.isEmpty()) {
				result.add(outgoinglinks);
			}
			if (!incominglinks.isEmpty()) {
				result.add(incominglinks);
			}
			return result.toArray();
		}

		case dsl_4webquiz.diagram.edit.parts.CuestionarioEditPart.VISUAL_ID: {
			LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem> result = new LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem>();
			Node sv = (Node) view;
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup outgoinglinks = new dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup(
					dsl_4webquiz.diagram.part.Messages.NavigatorGroupName_Cuestionario_2006_outgoinglinks,
					"icons/outgoingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup incominglinks = new dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup(
					dsl_4webquiz.diagram.part.Messages.NavigatorGroupName_Cuestionario_2006_incominglinks,
					"icons/incomingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getChildrenByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getType(
							dsl_4webquiz.diagram.edit.parts.CuestionarioCuestionarioPreguntaCuestionarioCompartmentEditPart.VISUAL_ID));
			connectedViews = getChildrenByType(connectedViews, dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
					.getType(dsl_4webquiz.diagram.edit.parts.PreguntaCorta2EditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getType(
							dsl_4webquiz.diagram.edit.parts.CuestionarioCuestionarioPreguntaCuestionarioCompartmentEditPart.VISUAL_ID));
			connectedViews = getChildrenByType(connectedViews, dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
					.getType(dsl_4webquiz.diagram.edit.parts.Seleccion2EditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getChildrenByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getType(
							dsl_4webquiz.diagram.edit.parts.CuestionarioCuestionarioPreguntaCuestionarioCompartmentEditPart.VISUAL_ID));
			connectedViews = getChildrenByType(connectedViews, dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
					.getType(dsl_4webquiz.diagram.edit.parts.VoF2EditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.PaginaRedes_socialesEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			connectedViews = getIncomingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.HomeConsultaEditPart.VISUAL_ID));
			incominglinks.addChildren(createNavigatorItems(connectedViews, incominglinks, true));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.ConsultaHomeEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			if (!outgoinglinks.isEmpty()) {
				result.add(outgoinglinks);
			}
			if (!incominglinks.isEmpty()) {
				result.add(incominglinks);
			}
			return result.toArray();
		}

		case dsl_4webquiz.diagram.edit.parts.CRUDEditPart.VISUAL_ID: {
			LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem> result = new LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem>();
			Node sv = (Node) view;
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup outgoinglinks = new dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup(
					dsl_4webquiz.diagram.part.Messages.NavigatorGroupName_CRUD_2007_outgoinglinks,
					"icons/outgoingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup incominglinks = new dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup(
					dsl_4webquiz.diagram.part.Messages.NavigatorGroupName_CRUD_2007_incominglinks,
					"icons/incomingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.PaginaRedes_socialesEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.PAGINAS_CRUDHomeEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.PAGINAS_CRUDTipodatosEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			connectedViews = getIncomingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.HomeCrudEditPart.VISUAL_ID));
			incominglinks.addChildren(createNavigatorItems(connectedViews, incominglinks, true));
			if (!outgoinglinks.isEmpty()) {
				result.add(outgoinglinks);
			}
			if (!incominglinks.isEmpty()) {
				result.add(incominglinks);
			}
			return result.toArray();
		}

		case dsl_4webquiz.diagram.edit.parts.UpdateEditPart.VISUAL_ID: {
			LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem> result = new LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem>();
			Node sv = (Node) view;
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup outgoinglinks = new dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup(
					dsl_4webquiz.diagram.part.Messages.NavigatorGroupName_Update_2008_outgoinglinks,
					"icons/outgoingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup incominglinks = new dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup(
					dsl_4webquiz.diagram.part.Messages.NavigatorGroupName_Update_2008_incominglinks,
					"icons/incomingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.PaginaRedes_socialesEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.PAGINAS_CRUDHomeEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.PAGINAS_CRUDTipodatosEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			connectedViews = getIncomingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.HomeCrudEditPart.VISUAL_ID));
			incominglinks.addChildren(createNavigatorItems(connectedViews, incominglinks, true));
			if (!outgoinglinks.isEmpty()) {
				result.add(outgoinglinks);
			}
			if (!incominglinks.isEmpty()) {
				result.add(incominglinks);
			}
			return result.toArray();
		}

		case dsl_4webquiz.diagram.edit.parts.HomeEditPart.VISUAL_ID: {
			LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem> result = new LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem>();
			Node sv = (Node) view;
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup outgoinglinks = new dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup(
					dsl_4webquiz.diagram.part.Messages.NavigatorGroupName_Home_2009_outgoinglinks,
					"icons/outgoingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup incominglinks = new dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup(
					dsl_4webquiz.diagram.part.Messages.NavigatorGroupName_Home_2009_incominglinks,
					"icons/incomingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.PaginaRedes_socialesEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			connectedViews = getIncomingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.PAGINAS_CRUDHomeEditPart.VISUAL_ID));
			incominglinks.addChildren(createNavigatorItems(connectedViews, incominglinks, true));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.HomeCrudEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			connectedViews = getOutgoingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.HomeConsultaEditPart.VISUAL_ID));
			outgoinglinks.addChildren(createNavigatorItems(connectedViews, outgoinglinks, true));
			connectedViews = getIncomingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.ConsultaHomeEditPart.VISUAL_ID));
			incominglinks.addChildren(createNavigatorItems(connectedViews, incominglinks, true));
			if (!outgoinglinks.isEmpty()) {
				result.add(outgoinglinks);
			}
			if (!incominglinks.isEmpty()) {
				result.add(incominglinks);
			}
			return result.toArray();
		}

		case dsl_4webquiz.diagram.edit.parts.TwitterEditPart.VISUAL_ID: {
			LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem> result = new LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem>();
			Node sv = (Node) view;
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup incominglinks = new dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup(
					dsl_4webquiz.diagram.part.Messages.NavigatorGroupName_Twitter_2010_incominglinks,
					"icons/incomingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getIncomingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.PaginaRedes_socialesEditPart.VISUAL_ID));
			incominglinks.addChildren(createNavigatorItems(connectedViews, incominglinks, true));
			if (!incominglinks.isEmpty()) {
				result.add(incominglinks);
			}
			return result.toArray();
		}

		case dsl_4webquiz.diagram.edit.parts.Google_plusEditPart.VISUAL_ID: {
			LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem> result = new LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem>();
			Node sv = (Node) view;
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup incominglinks = new dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup(
					dsl_4webquiz.diagram.part.Messages.NavigatorGroupName_Google_plus_2011_incominglinks,
					"icons/incomingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getIncomingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.PaginaRedes_socialesEditPart.VISUAL_ID));
			incominglinks.addChildren(createNavigatorItems(connectedViews, incominglinks, true));
			if (!incominglinks.isEmpty()) {
				result.add(incominglinks);
			}
			return result.toArray();
		}

		case dsl_4webquiz.diagram.edit.parts.RSSEditPart.VISUAL_ID: {
			LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem> result = new LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem>();
			Node sv = (Node) view;
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup incominglinks = new dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup(
					dsl_4webquiz.diagram.part.Messages.NavigatorGroupName_RSS_2012_incominglinks,
					"icons/incomingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getIncomingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.PaginaRedes_socialesEditPart.VISUAL_ID));
			incominglinks.addChildren(createNavigatorItems(connectedViews, incominglinks, true));
			if (!incominglinks.isEmpty()) {
				result.add(incominglinks);
			}
			return result.toArray();
		}

		case dsl_4webquiz.diagram.edit.parts.TipoDatosEditPart.VISUAL_ID: {
			LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem> result = new LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem>();
			Node sv = (Node) view;
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup incominglinks = new dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup(
					dsl_4webquiz.diagram.part.Messages.NavigatorGroupName_TipoDatos_2014_incominglinks,
					"icons/incomingLinksNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getChildrenByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getType(
							dsl_4webquiz.diagram.edit.parts.TipoDatosTipoDatosAtributoCompartmentEditPart.VISUAL_ID));
			connectedViews = getChildrenByType(connectedViews, dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
					.getType(dsl_4webquiz.diagram.edit.parts.AtributoEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			connectedViews = getIncomingLinksByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.PAGINAS_CRUDTipodatosEditPart.VISUAL_ID));
			incominglinks.addChildren(createNavigatorItems(connectedViews, incominglinks, true));
			if (!incominglinks.isEmpty()) {
				result.add(incominglinks);
			}
			return result.toArray();
		}

		case dsl_4webquiz.diagram.edit.parts.SeleccionEditPart.VISUAL_ID: {
			LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem> result = new LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem>();
			Node sv = (Node) view;
			Collection<View> connectedViews;
			connectedViews = getChildrenByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getType(
							dsl_4webquiz.diagram.edit.parts.SeleccionSeleccionOpcionCompartmentEditPart.VISUAL_ID));
			connectedViews = getChildrenByType(connectedViews, dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
					.getType(dsl_4webquiz.diagram.edit.parts.OpcionEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			return result.toArray();
		}

		case dsl_4webquiz.diagram.edit.parts.Seleccion2EditPart.VISUAL_ID: {
			LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem> result = new LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem>();
			Node sv = (Node) view;
			Collection<View> connectedViews;
			connectedViews = getChildrenByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getType(
							dsl_4webquiz.diagram.edit.parts.SeleccionSeleccionOpcionCompartment2EditPart.VISUAL_ID));
			connectedViews = getChildrenByType(connectedViews, dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
					.getType(dsl_4webquiz.diagram.edit.parts.OpcionEditPart.VISUAL_ID));
			result.addAll(createNavigatorItems(connectedViews, parentElement, false));
			return result.toArray();
		}

		case dsl_4webquiz.diagram.edit.parts.PaginaRedes_socialesEditPart.VISUAL_ID: {
			LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem> result = new LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem>();
			Edge sv = (Edge) view;
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup target = new dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup(
					dsl_4webquiz.diagram.part.Messages.NavigatorGroupName_PaginaRedes_sociales_4001_target,
					"icons/linkTargetNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup source = new dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup(
					dsl_4webquiz.diagram.part.Messages.NavigatorGroupName_PaginaRedes_sociales_4001_source,
					"icons/linkSourceNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getLinksTargetByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.TwitterEditPart.VISUAL_ID));
			target.addChildren(createNavigatorItems(connectedViews, target, true));
			connectedViews = getLinksTargetByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.Google_plusEditPart.VISUAL_ID));
			target.addChildren(createNavigatorItems(connectedViews, target, true));
			connectedViews = getLinksTargetByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.RSSEditPart.VISUAL_ID));
			target.addChildren(createNavigatorItems(connectedViews, target, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.IndiceEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.DetalleEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.CreacionEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.BorradoEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.EncuestaEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.CuestionarioEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.CRUDEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.UpdateEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.HomeEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			if (!target.isEmpty()) {
				result.add(target);
			}
			if (!source.isEmpty()) {
				result.add(source);
			}
			return result.toArray();
		}

		case dsl_4webquiz.diagram.edit.parts.PAGINAS_CRUDHomeEditPart.VISUAL_ID: {
			LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem> result = new LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem>();
			Edge sv = (Edge) view;
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup target = new dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup(
					dsl_4webquiz.diagram.part.Messages.NavigatorGroupName_PAGINAS_CRUDHome_4002_target,
					"icons/linkTargetNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup source = new dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup(
					dsl_4webquiz.diagram.part.Messages.NavigatorGroupName_PAGINAS_CRUDHome_4002_source,
					"icons/linkSourceNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getLinksTargetByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.HomeEditPart.VISUAL_ID));
			target.addChildren(createNavigatorItems(connectedViews, target, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.IndiceEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.DetalleEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.CreacionEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.BorradoEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.CRUDEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.UpdateEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			if (!target.isEmpty()) {
				result.add(target);
			}
			if (!source.isEmpty()) {
				result.add(source);
			}
			return result.toArray();
		}

		case dsl_4webquiz.diagram.edit.parts.HomeCrudEditPart.VISUAL_ID: {
			LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem> result = new LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem>();
			Edge sv = (Edge) view;
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup target = new dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup(
					dsl_4webquiz.diagram.part.Messages.NavigatorGroupName_HomeCrud_4003_target,
					"icons/linkTargetNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup source = new dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup(
					dsl_4webquiz.diagram.part.Messages.NavigatorGroupName_HomeCrud_4003_source,
					"icons/linkSourceNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getLinksTargetByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.IndiceEditPart.VISUAL_ID));
			target.addChildren(createNavigatorItems(connectedViews, target, true));
			connectedViews = getLinksTargetByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.DetalleEditPart.VISUAL_ID));
			target.addChildren(createNavigatorItems(connectedViews, target, true));
			connectedViews = getLinksTargetByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.CreacionEditPart.VISUAL_ID));
			target.addChildren(createNavigatorItems(connectedViews, target, true));
			connectedViews = getLinksTargetByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.BorradoEditPart.VISUAL_ID));
			target.addChildren(createNavigatorItems(connectedViews, target, true));
			connectedViews = getLinksTargetByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.CRUDEditPart.VISUAL_ID));
			target.addChildren(createNavigatorItems(connectedViews, target, true));
			connectedViews = getLinksTargetByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.UpdateEditPart.VISUAL_ID));
			target.addChildren(createNavigatorItems(connectedViews, target, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.HomeEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			if (!target.isEmpty()) {
				result.add(target);
			}
			if (!source.isEmpty()) {
				result.add(source);
			}
			return result.toArray();
		}

		case dsl_4webquiz.diagram.edit.parts.HomeConsultaEditPart.VISUAL_ID: {
			LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem> result = new LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem>();
			Edge sv = (Edge) view;
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup target = new dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup(
					dsl_4webquiz.diagram.part.Messages.NavigatorGroupName_HomeConsulta_4004_target,
					"icons/linkTargetNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup source = new dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup(
					dsl_4webquiz.diagram.part.Messages.NavigatorGroupName_HomeConsulta_4004_source,
					"icons/linkSourceNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getLinksTargetByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.EncuestaEditPart.VISUAL_ID));
			target.addChildren(createNavigatorItems(connectedViews, target, true));
			connectedViews = getLinksTargetByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.CuestionarioEditPart.VISUAL_ID));
			target.addChildren(createNavigatorItems(connectedViews, target, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.HomeEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			if (!target.isEmpty()) {
				result.add(target);
			}
			if (!source.isEmpty()) {
				result.add(source);
			}
			return result.toArray();
		}

		case dsl_4webquiz.diagram.edit.parts.ConsultaHomeEditPart.VISUAL_ID: {
			LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem> result = new LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem>();
			Edge sv = (Edge) view;
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup target = new dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup(
					dsl_4webquiz.diagram.part.Messages.NavigatorGroupName_ConsultaHome_4005_target,
					"icons/linkTargetNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup source = new dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup(
					dsl_4webquiz.diagram.part.Messages.NavigatorGroupName_ConsultaHome_4005_source,
					"icons/linkSourceNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getLinksTargetByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.HomeEditPart.VISUAL_ID));
			target.addChildren(createNavigatorItems(connectedViews, target, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.EncuestaEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.CuestionarioEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			if (!target.isEmpty()) {
				result.add(target);
			}
			if (!source.isEmpty()) {
				result.add(source);
			}
			return result.toArray();
		}

		case dsl_4webquiz.diagram.edit.parts.PAGINAS_CRUDTipodatosEditPart.VISUAL_ID: {
			LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem> result = new LinkedList<dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem>();
			Edge sv = (Edge) view;
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup target = new dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup(
					dsl_4webquiz.diagram.part.Messages.NavigatorGroupName_PAGINAS_CRUDTipodatos_4006_target,
					"icons/linkTargetNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup source = new dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorGroup(
					dsl_4webquiz.diagram.part.Messages.NavigatorGroupName_PAGINAS_CRUDTipodatos_4006_source,
					"icons/linkSourceNavigatorGroup.gif", parentElement); //$NON-NLS-1$
			Collection<View> connectedViews;
			connectedViews = getLinksTargetByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.TipoDatosEditPart.VISUAL_ID));
			target.addChildren(createNavigatorItems(connectedViews, target, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.IndiceEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.DetalleEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.CreacionEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.BorradoEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.CRUDEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			connectedViews = getLinksSourceByType(Collections.singleton(sv),
					dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry
							.getType(dsl_4webquiz.diagram.edit.parts.UpdateEditPart.VISUAL_ID));
			source.addChildren(createNavigatorItems(connectedViews, source, true));
			if (!target.isEmpty()) {
				result.add(target);
			}
			if (!source.isEmpty()) {
				result.add(source);
			}
			return result.toArray();
		}
		}
		return EMPTY_ARRAY;
	}

	/**
	* @generated
	*/
	private Collection<View> getLinksSourceByType(Collection<Edge> edges, String type) {
		LinkedList<View> result = new LinkedList<View>();
		for (Edge nextEdge : edges) {
			View nextEdgeSource = nextEdge.getSource();
			if (type.equals(nextEdgeSource.getType()) && isOwnView(nextEdgeSource)) {
				result.add(nextEdgeSource);
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	private Collection<View> getLinksTargetByType(Collection<Edge> edges, String type) {
		LinkedList<View> result = new LinkedList<View>();
		for (Edge nextEdge : edges) {
			View nextEdgeTarget = nextEdge.getTarget();
			if (type.equals(nextEdgeTarget.getType()) && isOwnView(nextEdgeTarget)) {
				result.add(nextEdgeTarget);
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	private Collection<View> getOutgoingLinksByType(Collection<? extends View> nodes, String type) {
		LinkedList<View> result = new LinkedList<View>();
		for (View nextNode : nodes) {
			result.addAll(selectViewsByType(nextNode.getSourceEdges(), type));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private Collection<View> getIncomingLinksByType(Collection<? extends View> nodes, String type) {
		LinkedList<View> result = new LinkedList<View>();
		for (View nextNode : nodes) {
			result.addAll(selectViewsByType(nextNode.getTargetEdges(), type));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private Collection<View> getChildrenByType(Collection<? extends View> nodes, String type) {
		LinkedList<View> result = new LinkedList<View>();
		for (View nextNode : nodes) {
			result.addAll(selectViewsByType(nextNode.getChildren(), type));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private Collection<View> getDiagramLinksByType(Collection<Diagram> diagrams, String type) {
		ArrayList<View> result = new ArrayList<View>();
		for (Diagram nextDiagram : diagrams) {
			result.addAll(selectViewsByType(nextDiagram.getEdges(), type));
		}
		return result;
	}

	// TODO refactor as static method
	/**
	 * @generated
	 */
	private Collection<View> selectViewsByType(Collection<View> views, String type) {
		ArrayList<View> result = new ArrayList<View>();
		for (View nextView : views) {
			if (type.equals(nextView.getType()) && isOwnView(nextView)) {
				result.add(nextView);
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	private boolean isOwnView(View view) {
		return dsl_4webquiz.diagram.edit.parts.WebEditPart.MODEL_ID
				.equals(dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getModelID(view));
	}

	/**
	 * @generated
	 */
	private Collection<dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorItem> createNavigatorItems(
			Collection<View> views, Object parent, boolean isLeafs) {
		ArrayList<dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorItem> result = new ArrayList<dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorItem>(
				views.size());
		for (View nextView : views) {
			result.add(new dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorItem(nextView, parent, isLeafs));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private Collection<dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorItem> getForeignShortcuts(Diagram diagram,
			Object parent) {
		LinkedList<View> result = new LinkedList<View>();
		for (Iterator<View> it = diagram.getChildren().iterator(); it.hasNext();) {
			View nextView = it.next();
			if (!isOwnView(nextView) && nextView.getEAnnotation("Shortcut") != null) { //$NON-NLS-1$
				result.add(nextView);
			}
		}
		return createNavigatorItems(result, parent, false);
	}

	/**
	* @generated
	*/
	public Object getParent(Object element) {
		if (element instanceof dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem) {
			dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem abstractNavigatorItem = (dsl_4webquiz.diagram.navigator.Dsl_4webquizAbstractNavigatorItem) element;
			return abstractNavigatorItem.getParent();
		}
		return null;
	}

	/**
	* @generated
	*/
	public boolean hasChildren(Object element) {
		return element instanceof IFile || getChildren(element).length > 0;
	}

}
