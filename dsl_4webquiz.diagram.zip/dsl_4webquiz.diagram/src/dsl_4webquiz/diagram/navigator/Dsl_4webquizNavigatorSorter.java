/*
* 
*/
package dsl_4webquiz.diagram.navigator;

import org.eclipse.jface.viewers.ViewerSorter;

/**
 * @generated
 */
public class Dsl_4webquizNavigatorSorter extends ViewerSorter {

	/**
	* @generated
	*/
	private static final int GROUP_CATEGORY = 7007;

	/**
	* @generated
	*/
	private static final int SHORTCUTS_CATEGORY = 7006;

	/**
	* @generated
	*/
	public int category(Object element) {
		if (element instanceof dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorItem) {
			dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorItem item = (dsl_4webquiz.diagram.navigator.Dsl_4webquizNavigatorItem) element;
			if (item.getView().getEAnnotation("Shortcut") != null) { //$NON-NLS-1$
				return SHORTCUTS_CATEGORY;
			}
			return dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getVisualID(item.getView());
		}
		return GROUP_CATEGORY;
	}

}
