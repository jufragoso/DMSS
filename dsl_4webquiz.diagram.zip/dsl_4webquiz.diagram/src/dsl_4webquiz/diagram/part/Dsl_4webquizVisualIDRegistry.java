/*
* 
*/
package dsl_4webquiz.diagram.part;

import org.eclipse.core.runtime.Platform;
import org.eclipse.emf.ecore.EAnnotation;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.runtime.notation.Diagram;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.gmf.tooling.runtime.structure.DiagramStructure;

/**
 * This registry is used to determine which type of visual object should be
 * created for the corresponding Diagram, Node, ChildNode or Link represented
 * by a domain model object.
 * 
 * @generated
 */
public class Dsl_4webquizVisualIDRegistry {

	/**
	* @generated
	*/
	private static final String DEBUG_KEY = "dsl_4webquiz.diagram/debug/visualID"; //$NON-NLS-1$

	/**
	* @generated
	*/
	public static int getVisualID(View view) {
		if (view instanceof Diagram) {
			if (dsl_4webquiz.diagram.edit.parts.WebEditPart.MODEL_ID.equals(view.getType())) {
				return dsl_4webquiz.diagram.edit.parts.WebEditPart.VISUAL_ID;
			} else {
				return -1;
			}
		}
		return dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getVisualID(view.getType());
	}

	/**
	* @generated
	*/
	public static String getModelID(View view) {
		View diagram = view.getDiagram();
		while (view != diagram) {
			EAnnotation annotation = view.getEAnnotation("Shortcut"); //$NON-NLS-1$
			if (annotation != null) {
				return (String) annotation.getDetails().get("modelID"); //$NON-NLS-1$
			}
			view = (View) view.eContainer();
		}
		return diagram != null ? diagram.getType() : null;
	}

	/**
	* @generated
	*/
	public static int getVisualID(String type) {
		try {
			return Integer.parseInt(type);
		} catch (NumberFormatException e) {
			if (Boolean.TRUE.toString().equalsIgnoreCase(Platform.getDebugOption(DEBUG_KEY))) {
				dsl_4webquiz.diagram.part.Dsl_4webquizDiagramEditorPlugin.getInstance()
						.logError("Unable to parse view type as a visualID number: " + type);
			}
		}
		return -1;
	}

	/**
	* @generated
	*/
	public static String getType(int visualID) {
		return Integer.toString(visualID);
	}

	/**
	* @generated
	*/
	public static int getDiagramVisualID(EObject domainElement) {
		if (domainElement == null) {
			return -1;
		}
		if (dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getWeb().isSuperTypeOf(domainElement.eClass())
				&& isDiagram((dsl_4webquiz.Web) domainElement)) {
			return dsl_4webquiz.diagram.edit.parts.WebEditPart.VISUAL_ID;
		}
		return -1;
	}

	/**
	* @generated
	*/
	public static int getNodeVisualID(View containerView, EObject domainElement) {
		if (domainElement == null) {
			return -1;
		}
		String containerModelID = dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getModelID(containerView);
		if (!dsl_4webquiz.diagram.edit.parts.WebEditPart.MODEL_ID.equals(containerModelID)
				&& !"dsl_4webquiz".equals(containerModelID)) { //$NON-NLS-1$
			return -1;
		}
		int containerVisualID;
		if (dsl_4webquiz.diagram.edit.parts.WebEditPart.MODEL_ID.equals(containerModelID)) {
			containerVisualID = dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getVisualID(containerView);
		} else {
			if (containerView instanceof Diagram) {
				containerVisualID = dsl_4webquiz.diagram.edit.parts.WebEditPart.VISUAL_ID;
			} else {
				return -1;
			}
		}
		switch (containerVisualID) {
		case dsl_4webquiz.diagram.edit.parts.WebEditPart.VISUAL_ID:
			if (dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getIndice().isSuperTypeOf(domainElement.eClass())) {
				return dsl_4webquiz.diagram.edit.parts.IndiceEditPart.VISUAL_ID;
			}
			if (dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getDetalle().isSuperTypeOf(domainElement.eClass())) {
				return dsl_4webquiz.diagram.edit.parts.DetalleEditPart.VISUAL_ID;
			}
			if (dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getCreacion().isSuperTypeOf(domainElement.eClass())) {
				return dsl_4webquiz.diagram.edit.parts.CreacionEditPart.VISUAL_ID;
			}
			if (dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getBorrado().isSuperTypeOf(domainElement.eClass())) {
				return dsl_4webquiz.diagram.edit.parts.BorradoEditPart.VISUAL_ID;
			}
			if (dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getEncuesta().isSuperTypeOf(domainElement.eClass())) {
				return dsl_4webquiz.diagram.edit.parts.EncuestaEditPart.VISUAL_ID;
			}
			if (dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getCuestionario().isSuperTypeOf(domainElement.eClass())) {
				return dsl_4webquiz.diagram.edit.parts.CuestionarioEditPart.VISUAL_ID;
			}
			if (dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getCRUD().isSuperTypeOf(domainElement.eClass())) {
				return dsl_4webquiz.diagram.edit.parts.CRUDEditPart.VISUAL_ID;
			}
			if (dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getUpdate().isSuperTypeOf(domainElement.eClass())) {
				return dsl_4webquiz.diagram.edit.parts.UpdateEditPart.VISUAL_ID;
			}
			if (dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getHome().isSuperTypeOf(domainElement.eClass())) {
				return dsl_4webquiz.diagram.edit.parts.HomeEditPart.VISUAL_ID;
			}
			if (dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getTwitter().isSuperTypeOf(domainElement.eClass())) {
				return dsl_4webquiz.diagram.edit.parts.TwitterEditPart.VISUAL_ID;
			}
			if (dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getGoogle_plus().isSuperTypeOf(domainElement.eClass())) {
				return dsl_4webquiz.diagram.edit.parts.Google_plusEditPart.VISUAL_ID;
			}
			if (dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getRSS().isSuperTypeOf(domainElement.eClass())) {
				return dsl_4webquiz.diagram.edit.parts.RSSEditPart.VISUAL_ID;
			}
			if (dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getUsuario().isSuperTypeOf(domainElement.eClass())) {
				return dsl_4webquiz.diagram.edit.parts.UsuarioEditPart.VISUAL_ID;
			}
			if (dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getTipoDatos().isSuperTypeOf(domainElement.eClass())) {
				return dsl_4webquiz.diagram.edit.parts.TipoDatosEditPart.VISUAL_ID;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.EncuestaEncuestaPreguntaEncuestaCompartmentEditPart.VISUAL_ID:
			if (dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getPreguntaCorta().isSuperTypeOf(domainElement.eClass())) {
				return dsl_4webquiz.diagram.edit.parts.PreguntaCortaEditPart.VISUAL_ID;
			}
			if (dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getSeleccion().isSuperTypeOf(domainElement.eClass())) {
				return dsl_4webquiz.diagram.edit.parts.SeleccionEditPart.VISUAL_ID;
			}
			if (dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getVoF().isSuperTypeOf(domainElement.eClass())) {
				return dsl_4webquiz.diagram.edit.parts.VoFEditPart.VISUAL_ID;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.SeleccionSeleccionOpcionCompartmentEditPart.VISUAL_ID:
			if (dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getOpcion().isSuperTypeOf(domainElement.eClass())) {
				return dsl_4webquiz.diagram.edit.parts.OpcionEditPart.VISUAL_ID;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.CuestionarioCuestionarioPreguntaCuestionarioCompartmentEditPart.VISUAL_ID:
			if (dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getPreguntaCorta().isSuperTypeOf(domainElement.eClass())) {
				return dsl_4webquiz.diagram.edit.parts.PreguntaCorta2EditPart.VISUAL_ID;
			}
			if (dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getSeleccion().isSuperTypeOf(domainElement.eClass())) {
				return dsl_4webquiz.diagram.edit.parts.Seleccion2EditPart.VISUAL_ID;
			}
			if (dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getVoF().isSuperTypeOf(domainElement.eClass())) {
				return dsl_4webquiz.diagram.edit.parts.VoF2EditPart.VISUAL_ID;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.SeleccionSeleccionOpcionCompartment2EditPart.VISUAL_ID:
			if (dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getOpcion().isSuperTypeOf(domainElement.eClass())) {
				return dsl_4webquiz.diagram.edit.parts.OpcionEditPart.VISUAL_ID;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.TipoDatosTipoDatosAtributoCompartmentEditPart.VISUAL_ID:
			if (dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getAtributo().isSuperTypeOf(domainElement.eClass())) {
				return dsl_4webquiz.diagram.edit.parts.AtributoEditPart.VISUAL_ID;
			}
			break;
		}
		return -1;
	}

	/**
	* @generated
	*/
	public static boolean canCreateNode(View containerView, int nodeVisualID) {
		String containerModelID = dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getModelID(containerView);
		if (!dsl_4webquiz.diagram.edit.parts.WebEditPart.MODEL_ID.equals(containerModelID)
				&& !"dsl_4webquiz".equals(containerModelID)) { //$NON-NLS-1$
			return false;
		}
		int containerVisualID;
		if (dsl_4webquiz.diagram.edit.parts.WebEditPart.MODEL_ID.equals(containerModelID)) {
			containerVisualID = dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getVisualID(containerView);
		} else {
			if (containerView instanceof Diagram) {
				containerVisualID = dsl_4webquiz.diagram.edit.parts.WebEditPart.VISUAL_ID;
			} else {
				return false;
			}
		}
		switch (containerVisualID) {
		case dsl_4webquiz.diagram.edit.parts.WebEditPart.VISUAL_ID:
			if (dsl_4webquiz.diagram.edit.parts.IndiceEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (dsl_4webquiz.diagram.edit.parts.DetalleEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (dsl_4webquiz.diagram.edit.parts.CreacionEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (dsl_4webquiz.diagram.edit.parts.BorradoEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (dsl_4webquiz.diagram.edit.parts.EncuestaEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (dsl_4webquiz.diagram.edit.parts.CuestionarioEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (dsl_4webquiz.diagram.edit.parts.CRUDEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (dsl_4webquiz.diagram.edit.parts.UpdateEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (dsl_4webquiz.diagram.edit.parts.HomeEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (dsl_4webquiz.diagram.edit.parts.TwitterEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (dsl_4webquiz.diagram.edit.parts.Google_plusEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (dsl_4webquiz.diagram.edit.parts.RSSEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (dsl_4webquiz.diagram.edit.parts.UsuarioEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (dsl_4webquiz.diagram.edit.parts.TipoDatosEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.IndiceEditPart.VISUAL_ID:
			if (dsl_4webquiz.diagram.edit.parts.IndiceTituloEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.DetalleEditPart.VISUAL_ID:
			if (dsl_4webquiz.diagram.edit.parts.DetalleTituloEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.CreacionEditPart.VISUAL_ID:
			if (dsl_4webquiz.diagram.edit.parts.CreacionTituloEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.BorradoEditPart.VISUAL_ID:
			if (dsl_4webquiz.diagram.edit.parts.BorradoTituloEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.EncuestaEditPart.VISUAL_ID:
			if (dsl_4webquiz.diagram.edit.parts.EncuestaTituloEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (dsl_4webquiz.diagram.edit.parts.EncuestaEncuestaPreguntaEncuestaCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.CuestionarioEditPart.VISUAL_ID:
			if (dsl_4webquiz.diagram.edit.parts.CuestionarioTituloEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (dsl_4webquiz.diagram.edit.parts.CuestionarioCuestionarioPreguntaCuestionarioCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.CRUDEditPart.VISUAL_ID:
			if (dsl_4webquiz.diagram.edit.parts.CRUDTituloEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.UpdateEditPart.VISUAL_ID:
			if (dsl_4webquiz.diagram.edit.parts.UpdateTituloEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.HomeEditPart.VISUAL_ID:
			if (dsl_4webquiz.diagram.edit.parts.HomeTituloEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.TwitterEditPart.VISUAL_ID:
			if (dsl_4webquiz.diagram.edit.parts.TwitterEnlaceEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.Google_plusEditPart.VISUAL_ID:
			if (dsl_4webquiz.diagram.edit.parts.Google_plusEnlaceEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.RSSEditPart.VISUAL_ID:
			if (dsl_4webquiz.diagram.edit.parts.RSSEnlaceEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.UsuarioEditPart.VISUAL_ID:
			if (dsl_4webquiz.diagram.edit.parts.UsuarioUsuarioEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.TipoDatosEditPart.VISUAL_ID:
			if (dsl_4webquiz.diagram.edit.parts.TipoDatosNombreEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (dsl_4webquiz.diagram.edit.parts.TipoDatosTipoDatosAtributoCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.PreguntaCortaEditPart.VISUAL_ID:
			if (dsl_4webquiz.diagram.edit.parts.PreguntaCortaTituloPreguntaEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.SeleccionEditPart.VISUAL_ID:
			if (dsl_4webquiz.diagram.edit.parts.SeleccionTituloPreguntaEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (dsl_4webquiz.diagram.edit.parts.SeleccionSeleccionOpcionCompartmentEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.OpcionEditPart.VISUAL_ID:
			if (dsl_4webquiz.diagram.edit.parts.OpcionTituloPreguntaEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.VoFEditPart.VISUAL_ID:
			if (dsl_4webquiz.diagram.edit.parts.VoFTituloPreguntaEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.PreguntaCorta2EditPart.VISUAL_ID:
			if (dsl_4webquiz.diagram.edit.parts.PreguntaCortaTituloPregunta2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.Seleccion2EditPart.VISUAL_ID:
			if (dsl_4webquiz.diagram.edit.parts.SeleccionTituloPregunta2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (dsl_4webquiz.diagram.edit.parts.SeleccionSeleccionOpcionCompartment2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.VoF2EditPart.VISUAL_ID:
			if (dsl_4webquiz.diagram.edit.parts.VoFTituloPregunta2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.AtributoEditPart.VISUAL_ID:
			if (dsl_4webquiz.diagram.edit.parts.AtributoNombreEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.EncuestaEncuestaPreguntaEncuestaCompartmentEditPart.VISUAL_ID:
			if (dsl_4webquiz.diagram.edit.parts.PreguntaCortaEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (dsl_4webquiz.diagram.edit.parts.SeleccionEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (dsl_4webquiz.diagram.edit.parts.VoFEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.SeleccionSeleccionOpcionCompartmentEditPart.VISUAL_ID:
			if (dsl_4webquiz.diagram.edit.parts.OpcionEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.CuestionarioCuestionarioPreguntaCuestionarioCompartmentEditPart.VISUAL_ID:
			if (dsl_4webquiz.diagram.edit.parts.PreguntaCorta2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (dsl_4webquiz.diagram.edit.parts.Seleccion2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (dsl_4webquiz.diagram.edit.parts.VoF2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.SeleccionSeleccionOpcionCompartment2EditPart.VISUAL_ID:
			if (dsl_4webquiz.diagram.edit.parts.OpcionEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.TipoDatosTipoDatosAtributoCompartmentEditPart.VISUAL_ID:
			if (dsl_4webquiz.diagram.edit.parts.AtributoEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.PaginaRedes_socialesEditPart.VISUAL_ID:
			if (dsl_4webquiz.diagram.edit.parts.PaginaRedes_socialesExternalLabelEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.PAGINAS_CRUDHomeEditPart.VISUAL_ID:
			if (dsl_4webquiz.diagram.edit.parts.WrappingLabelEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.PAGINAS_CRUDTipodatosEditPart.VISUAL_ID:
			if (dsl_4webquiz.diagram.edit.parts.WrappingLabel2EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.HomeCrudEditPart.VISUAL_ID:
			if (dsl_4webquiz.diagram.edit.parts.WrappingLabel3EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.HomeConsultaEditPart.VISUAL_ID:
			if (dsl_4webquiz.diagram.edit.parts.WrappingLabel4EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case dsl_4webquiz.diagram.edit.parts.ConsultaHomeEditPart.VISUAL_ID:
			if (dsl_4webquiz.diagram.edit.parts.WrappingLabel5EditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		}
		return false;
	}

	/**
	* @generated
	*/
	public static int getLinkWithClassVisualID(EObject domainElement) {
		if (domainElement == null) {
			return -1;
		}
		return -1;
	}

	/**
	* User can change implementation of this method to handle some specific
	* situations not covered by default logic.
	* 
	* @generated
	*/
	private static boolean isDiagram(dsl_4webquiz.Web element) {
		return true;
	}

	/**
	* @generated
	*/
	public static boolean checkNodeVisualID(View containerView, EObject domainElement, int candidate) {
		if (candidate == -1) {
			//unrecognized id is always bad
			return false;
		}
		int basic = getNodeVisualID(containerView, domainElement);
		return basic == candidate;
	}

	/**
	* @generated
	*/
	public static boolean isCompartmentVisualID(int visualID) {
		switch (visualID) {
		case dsl_4webquiz.diagram.edit.parts.EncuestaEncuestaPreguntaEncuestaCompartmentEditPart.VISUAL_ID:
		case dsl_4webquiz.diagram.edit.parts.SeleccionSeleccionOpcionCompartmentEditPart.VISUAL_ID:
		case dsl_4webquiz.diagram.edit.parts.CuestionarioCuestionarioPreguntaCuestionarioCompartmentEditPart.VISUAL_ID:
		case dsl_4webquiz.diagram.edit.parts.SeleccionSeleccionOpcionCompartment2EditPart.VISUAL_ID:
		case dsl_4webquiz.diagram.edit.parts.TipoDatosTipoDatosAtributoCompartmentEditPart.VISUAL_ID:
			return true;
		default:
			break;
		}
		return false;
	}

	/**
	* @generated
	*/
	public static boolean isSemanticLeafVisualID(int visualID) {
		switch (visualID) {
		case dsl_4webquiz.diagram.edit.parts.WebEditPart.VISUAL_ID:
			return false;
		case dsl_4webquiz.diagram.edit.parts.IndiceEditPart.VISUAL_ID:
		case dsl_4webquiz.diagram.edit.parts.DetalleEditPart.VISUAL_ID:
		case dsl_4webquiz.diagram.edit.parts.CreacionEditPart.VISUAL_ID:
		case dsl_4webquiz.diagram.edit.parts.BorradoEditPart.VISUAL_ID:
		case dsl_4webquiz.diagram.edit.parts.CRUDEditPart.VISUAL_ID:
		case dsl_4webquiz.diagram.edit.parts.UpdateEditPart.VISUAL_ID:
		case dsl_4webquiz.diagram.edit.parts.HomeEditPart.VISUAL_ID:
		case dsl_4webquiz.diagram.edit.parts.TwitterEditPart.VISUAL_ID:
		case dsl_4webquiz.diagram.edit.parts.Google_plusEditPart.VISUAL_ID:
		case dsl_4webquiz.diagram.edit.parts.RSSEditPart.VISUAL_ID:
		case dsl_4webquiz.diagram.edit.parts.UsuarioEditPart.VISUAL_ID:
		case dsl_4webquiz.diagram.edit.parts.PreguntaCortaEditPart.VISUAL_ID:
		case dsl_4webquiz.diagram.edit.parts.OpcionEditPart.VISUAL_ID:
		case dsl_4webquiz.diagram.edit.parts.VoFEditPart.VISUAL_ID:
		case dsl_4webquiz.diagram.edit.parts.PreguntaCorta2EditPart.VISUAL_ID:
		case dsl_4webquiz.diagram.edit.parts.VoF2EditPart.VISUAL_ID:
		case dsl_4webquiz.diagram.edit.parts.AtributoEditPart.VISUAL_ID:
			return true;
		default:
			break;
		}
		return false;
	}

	/**
	* @generated
	*/
	public static final DiagramStructure TYPED_INSTANCE = new DiagramStructure() {
		/**
		* @generated
		*/
		@Override

		public int getVisualID(View view) {
			return dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getVisualID(view);
		}

		/**
		* @generated
		*/
		@Override

		public String getModelID(View view) {
			return dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getModelID(view);
		}

		/**
		* @generated
		*/
		@Override

		public int getNodeVisualID(View containerView, EObject domainElement) {
			return dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getNodeVisualID(containerView, domainElement);
		}

		/**
		* @generated
		*/
		@Override

		public boolean checkNodeVisualID(View containerView, EObject domainElement, int candidate) {
			return dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.checkNodeVisualID(containerView,
					domainElement, candidate);
		}

		/**
		* @generated
		*/
		@Override

		public boolean isCompartmentVisualID(int visualID) {
			return dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.isCompartmentVisualID(visualID);
		}

		/**
		* @generated
		*/
		@Override

		public boolean isSemanticLeafVisualID(int visualID) {
			return dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.isSemanticLeafVisualID(visualID);
		}
	};

}
