/*
 * 
 */
package dsl_4webquiz.diagram.part;

import org.eclipse.osgi.util.NLS;

/**
 * @generated
 */
public class Messages extends NLS {

	/**
	* @generated
	*/
	static {
		NLS.initializeMessages("messages", Messages.class); //$NON-NLS-1$
	}

	/**
	* @generated
	*/
	private Messages() {
	}

	/**
	* @generated
	*/
	public static String Dsl_4webquizCreationWizardTitle;

	/**
	* @generated
	*/
	public static String Dsl_4webquizCreationWizard_DiagramModelFilePageTitle;

	/**
	* @generated
	*/
	public static String Dsl_4webquizCreationWizard_DiagramModelFilePageDescription;

	/**
	* @generated
	*/
	public static String Dsl_4webquizCreationWizard_DomainModelFilePageTitle;

	/**
	* @generated
	*/
	public static String Dsl_4webquizCreationWizard_DomainModelFilePageDescription;

	/**
	* @generated
	*/
	public static String Dsl_4webquizCreationWizardOpenEditorError;

	/**
	* @generated
	*/
	public static String Dsl_4webquizCreationWizardCreationError;

	/**
	* @generated
	*/
	public static String Dsl_4webquizCreationWizardPageExtensionError;

	/**
	* @generated
	*/
	public static String Dsl_4webquizDiagramEditorUtil_OpenModelResourceErrorDialogTitle;

	/**
	* @generated
	*/
	public static String Dsl_4webquizDiagramEditorUtil_OpenModelResourceErrorDialogMessage;

	/**
	* @generated
	*/
	public static String Dsl_4webquizDiagramEditorUtil_CreateDiagramProgressTask;

	/**
	* @generated
	*/
	public static String Dsl_4webquizDiagramEditorUtil_CreateDiagramCommandLabel;

	/**
	* @generated
	*/
	public static String Dsl_4webquizDocumentProvider_isModifiable;

	/**
	* @generated
	*/
	public static String Dsl_4webquizDocumentProvider_handleElementContentChanged;

	/**
	* @generated
	*/
	public static String Dsl_4webquizDocumentProvider_IncorrectInputError;

	/**
	* @generated
	*/
	public static String Dsl_4webquizDocumentProvider_NoDiagramInResourceError;

	/**
	* @generated
	*/
	public static String Dsl_4webquizDocumentProvider_DiagramLoadingError;

	/**
	* @generated
	*/
	public static String Dsl_4webquizDocumentProvider_UnsynchronizedFileSaveError;

	/**
	* @generated
	*/
	public static String Dsl_4webquizDocumentProvider_SaveDiagramTask;

	/**
	* @generated
	*/
	public static String Dsl_4webquizDocumentProvider_SaveNextResourceTask;

	/**
	* @generated
	*/
	public static String Dsl_4webquizDocumentProvider_SaveAsOperation;

	/**
	* @generated
	*/
	public static String InitDiagramFile_ResourceErrorDialogTitle;

	/**
	* @generated
	*/
	public static String InitDiagramFile_ResourceErrorDialogMessage;

	/**
	* @generated
	*/
	public static String InitDiagramFile_WizardTitle;

	/**
	* @generated
	*/
	public static String InitDiagramFile_OpenModelFileDialogTitle;

	/**
	* @generated
	*/
	public static String Dsl_4webquizNewDiagramFileWizard_CreationPageName;

	/**
	* @generated
	*/
	public static String Dsl_4webquizNewDiagramFileWizard_CreationPageTitle;

	/**
	* @generated
	*/
	public static String Dsl_4webquizNewDiagramFileWizard_CreationPageDescription;

	/**
	* @generated
	*/
	public static String Dsl_4webquizNewDiagramFileWizard_RootSelectionPageName;

	/**
	* @generated
	*/
	public static String Dsl_4webquizNewDiagramFileWizard_RootSelectionPageTitle;

	/**
	* @generated
	*/
	public static String Dsl_4webquizNewDiagramFileWizard_RootSelectionPageDescription;

	/**
	* @generated
	*/
	public static String Dsl_4webquizNewDiagramFileWizard_RootSelectionPageSelectionTitle;

	/**
	* @generated
	*/
	public static String Dsl_4webquizNewDiagramFileWizard_RootSelectionPageNoSelectionMessage;

	/**
	* @generated
	*/
	public static String Dsl_4webquizNewDiagramFileWizard_RootSelectionPageInvalidSelectionMessage;

	/**
	* @generated
	*/
	public static String Dsl_4webquizNewDiagramFileWizard_InitDiagramCommand;

	/**
	* @generated
	*/
	public static String Dsl_4webquizNewDiagramFileWizard_IncorrectRootError;

	/**
	* @generated
	*/
	public static String Dsl_4webquizDiagramEditor_SavingDeletedFile;

	/**
	* @generated
	*/
	public static String Dsl_4webquizDiagramEditor_SaveAsErrorTitle;

	/**
	* @generated
	*/
	public static String Dsl_4webquizDiagramEditor_SaveAsErrorMessage;

	/**
	* @generated
	*/
	public static String Dsl_4webquizDiagramEditor_SaveErrorTitle;

	/**
	* @generated
	*/
	public static String Dsl_4webquizDiagramEditor_SaveErrorMessage;

	/**
	* @generated
	*/
	public static String Dsl_4webquizElementChooserDialog_SelectModelElementTitle;

	/**
	* @generated
	*/
	public static String ModelElementSelectionPageMessage;

	/**
	* @generated
	*/
	public static String ValidateActionMessage;

	/**
	* @generated
	*/
	public static String Objects1Group_title;

	/**
	* @generated
	*/
	public static String Connections2Group_title;

	/**
	* @generated
	*/
	public static String Atributo1CreationTool_title;

	/**
	* @generated
	*/
	public static String Atributo1CreationTool_desc;

	/**
	* @generated
	*/
	public static String Borrado2CreationTool_title;

	/**
	* @generated
	*/
	public static String Borrado2CreationTool_desc;

	/**
	* @generated
	*/
	public static String CRUD3CreationTool_title;

	/**
	* @generated
	*/
	public static String CRUD3CreationTool_desc;

	/**
	* @generated
	*/
	public static String Creacion4CreationTool_title;

	/**
	* @generated
	*/
	public static String Creacion4CreationTool_desc;

	/**
	* @generated
	*/
	public static String Cuestionario5CreationTool_title;

	/**
	* @generated
	*/
	public static String Cuestionario5CreationTool_desc;

	/**
	* @generated
	*/
	public static String Detalle6CreationTool_title;

	/**
	* @generated
	*/
	public static String Detalle6CreationTool_desc;

	/**
	* @generated
	*/
	public static String Encuesta7CreationTool_title;

	/**
	* @generated
	*/
	public static String Encuesta7CreationTool_desc;

	/**
	* @generated
	*/
	public static String Google_plus8CreationTool_title;

	/**
	* @generated
	*/
	public static String Google_plus8CreationTool_desc;

	/**
	* @generated
	*/
	public static String Home9CreationTool_title;

	/**
	* @generated
	*/
	public static String Home9CreationTool_desc;

	/**
	* @generated
	*/
	public static String Indice10CreationTool_title;

	/**
	* @generated
	*/
	public static String Indice10CreationTool_desc;

	/**
	* @generated
	*/
	public static String Opcion11CreationTool_title;

	/**
	* @generated
	*/
	public static String Opcion11CreationTool_desc;

	/**
	* @generated
	*/
	public static String PreguntaCorta12CreationTool_title;

	/**
	* @generated
	*/
	public static String PreguntaCorta12CreationTool_desc;

	/**
	* @generated
	*/
	public static String RSS13CreationTool_title;

	/**
	* @generated
	*/
	public static String RSS13CreationTool_desc;

	/**
	* @generated
	*/
	public static String Seleccion14CreationTool_title;

	/**
	* @generated
	*/
	public static String Seleccion14CreationTool_desc;

	/**
	* @generated
	*/
	public static String TipoDatos15CreationTool_title;

	/**
	* @generated
	*/
	public static String TipoDatos15CreationTool_desc;

	/**
	* @generated
	*/
	public static String Twitter16CreationTool_title;

	/**
	* @generated
	*/
	public static String Twitter16CreationTool_desc;

	/**
	* @generated
	*/
	public static String Update17CreationTool_title;

	/**
	* @generated
	*/
	public static String Update17CreationTool_desc;

	/**
	* @generated
	*/
	public static String Usuario18CreationTool_title;

	/**
	* @generated
	*/
	public static String Usuario18CreationTool_desc;

	/**
	* @generated
	*/
	public static String VoF19CreationTool_title;

	/**
	* @generated
	*/
	public static String VoF19CreationTool_desc;

	/**
	* @generated
	*/
	public static String Consulta1CreationTool_title;

	/**
	* @generated
	*/
	public static String Consulta1CreationTool_desc;

	/**
	* @generated
	*/
	public static String Crud2CreationTool_title;

	/**
	* @generated
	*/
	public static String Crud2CreationTool_desc;

	/**
	* @generated
	*/
	public static String Home3CreationTool_title;

	/**
	* @generated
	*/
	public static String Home3CreationTool_desc;

	/**
	* @generated
	*/
	public static String Home4CreationTool_title;

	/**
	* @generated
	*/
	public static String Home4CreationTool_desc;

	/**
	* @generated
	*/
	public static String Redes_sociales5CreationTool_title;

	/**
	* @generated
	*/
	public static String Redes_sociales5CreationTool_desc;

	/**
	* @generated
	*/
	public static String Tipodatos6CreationTool_title;

	/**
	* @generated
	*/
	public static String Tipodatos6CreationTool_desc;

	/**
	* @generated
	*/
	public static String EncuestaEncuestaPreguntaEncuestaCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String SeleccionSeleccionOpcionCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String CuestionarioCuestionarioPreguntaCuestionarioCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String SeleccionSeleccionOpcionCompartment2EditPart_title;

	/**
	* @generated
	*/
	public static String TipoDatosTipoDatosAtributoCompartmentEditPart_title;

	/**
	* @generated
	*/
	public static String CommandName_OpenDiagram;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Web_1000_links;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Indice_2001_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Indice_2001_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Detalle_2002_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Detalle_2002_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Creacion_2003_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Creacion_2003_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Borrado_2004_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Borrado_2004_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Encuesta_2005_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Encuesta_2005_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Cuestionario_2006_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Cuestionario_2006_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_CRUD_2007_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_CRUD_2007_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Update_2008_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Update_2008_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Home_2009_outgoinglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Home_2009_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Twitter_2010_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_Google_plus_2011_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_RSS_2012_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_TipoDatos_2014_incominglinks;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_PaginaRedes_sociales_4001_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_PaginaRedes_sociales_4001_source;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_PAGINAS_CRUDHome_4002_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_PAGINAS_CRUDHome_4002_source;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_HomeCrud_4003_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_HomeCrud_4003_source;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_HomeConsulta_4004_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_HomeConsulta_4004_source;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_ConsultaHome_4005_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_ConsultaHome_4005_source;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_PAGINAS_CRUDTipodatos_4006_target;

	/**
	* @generated
	*/
	public static String NavigatorGroupName_PAGINAS_CRUDTipodatos_4006_source;

	/**
	* @generated
	*/
	public static String NavigatorActionProvider_OpenDiagramActionName;

	/**
	* @generated
	*/
	public static String MessageFormatParser_InvalidInputError;

	/**
	* @generated
	*/
	public static String Dsl_4webquizModelingAssistantProviderTitle;

	/**
	* @generated
	*/
	public static String Dsl_4webquizModelingAssistantProviderMessage;

	//TODO: put accessor fields manually	
}
