
/*
 * 
 */
package dsl_4webquiz.diagram.part;

import java.util.ArrayList;
import java.util.Collections;

import org.eclipse.gef.palette.PaletteContainer;
import org.eclipse.gef.palette.PaletteDrawer;
import org.eclipse.gef.palette.PaletteRoot;
import org.eclipse.gef.palette.ToolEntry;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.tooling.runtime.part.DefaultLinkToolEntry;
import org.eclipse.gmf.tooling.runtime.part.DefaultNodeToolEntry;

/**
 * @generated
 */
public class Dsl_4webquizPaletteFactory {

	/**
	* @generated
	*/
	public void fillPalette(PaletteRoot paletteRoot) {
		paletteRoot.add(createObjects1Group());
		paletteRoot.add(createConnections2Group());
	}

	/**
	* Creates "Objects" palette tool group
	* @generated
	*/
	private PaletteContainer createObjects1Group() {
		PaletteDrawer paletteContainer = new PaletteDrawer(dsl_4webquiz.diagram.part.Messages.Objects1Group_title);
		paletteContainer.setId("createObjects1Group"); //$NON-NLS-1$
		paletteContainer.add(createAtributo1CreationTool());
		paletteContainer.add(createBorrado2CreationTool());
		paletteContainer.add(createCRUD3CreationTool());
		paletteContainer.add(createCreacion4CreationTool());
		paletteContainer.add(createCuestionario5CreationTool());
		paletteContainer.add(createDetalle6CreationTool());
		paletteContainer.add(createEncuesta7CreationTool());
		paletteContainer.add(createGoogle_plus8CreationTool());
		paletteContainer.add(createHome9CreationTool());
		paletteContainer.add(createIndice10CreationTool());
		paletteContainer.add(createOpcion11CreationTool());
		paletteContainer.add(createPreguntaCorta12CreationTool());
		paletteContainer.add(createRSS13CreationTool());
		paletteContainer.add(createSeleccion14CreationTool());
		paletteContainer.add(createTipoDatos15CreationTool());
		paletteContainer.add(createTwitter16CreationTool());
		paletteContainer.add(createUpdate17CreationTool());
		paletteContainer.add(createUsuario18CreationTool());
		paletteContainer.add(createVoF19CreationTool());
		return paletteContainer;
	}

	/**
	* Creates "Connections" palette tool group
	* @generated
	*/
	private PaletteContainer createConnections2Group() {
		PaletteDrawer paletteContainer = new PaletteDrawer(dsl_4webquiz.diagram.part.Messages.Connections2Group_title);
		paletteContainer.setId("createConnections2Group"); //$NON-NLS-1$
		paletteContainer.add(createConsulta1CreationTool());
		paletteContainer.add(createCrud2CreationTool());
		paletteContainer.add(createHome3CreationTool());
		paletteContainer.add(createHome4CreationTool());
		paletteContainer.add(createRedes_sociales5CreationTool());
		paletteContainer.add(createTipodatos6CreationTool());
		return paletteContainer;
	}

	/**
	* @generated
	*/
	private ToolEntry createAtributo1CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				dsl_4webquiz.diagram.part.Messages.Atributo1CreationTool_title,
				dsl_4webquiz.diagram.part.Messages.Atributo1CreationTool_desc,
				Collections.singletonList(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Atributo_3008));
		entry.setId("createAtributo1CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes
				.getImageDescriptor(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Atributo_3008));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createBorrado2CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				dsl_4webquiz.diagram.part.Messages.Borrado2CreationTool_title,
				dsl_4webquiz.diagram.part.Messages.Borrado2CreationTool_desc,
				Collections.singletonList(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Borrado_2004));
		entry.setId("createBorrado2CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes
				.getImageDescriptor(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Borrado_2004));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createCRUD3CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				dsl_4webquiz.diagram.part.Messages.CRUD3CreationTool_title,
				dsl_4webquiz.diagram.part.Messages.CRUD3CreationTool_desc,
				Collections.singletonList(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.CRUD_2007));
		entry.setId("createCRUD3CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes
				.getImageDescriptor(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.CRUD_2007));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createCreacion4CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				dsl_4webquiz.diagram.part.Messages.Creacion4CreationTool_title,
				dsl_4webquiz.diagram.part.Messages.Creacion4CreationTool_desc,
				Collections.singletonList(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Creacion_2003));
		entry.setId("createCreacion4CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes
				.getImageDescriptor(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Creacion_2003));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createCuestionario5CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				dsl_4webquiz.diagram.part.Messages.Cuestionario5CreationTool_title,
				dsl_4webquiz.diagram.part.Messages.Cuestionario5CreationTool_desc,
				Collections.singletonList(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Cuestionario_2006));
		entry.setId("createCuestionario5CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes
				.getImageDescriptor(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Cuestionario_2006));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createDetalle6CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				dsl_4webquiz.diagram.part.Messages.Detalle6CreationTool_title,
				dsl_4webquiz.diagram.part.Messages.Detalle6CreationTool_desc,
				Collections.singletonList(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Detalle_2002));
		entry.setId("createDetalle6CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes
				.getImageDescriptor(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Detalle_2002));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createEncuesta7CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				dsl_4webquiz.diagram.part.Messages.Encuesta7CreationTool_title,
				dsl_4webquiz.diagram.part.Messages.Encuesta7CreationTool_desc,
				Collections.singletonList(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Encuesta_2005));
		entry.setId("createEncuesta7CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes
				.getImageDescriptor(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Encuesta_2005));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createGoogle_plus8CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				dsl_4webquiz.diagram.part.Messages.Google_plus8CreationTool_title,
				dsl_4webquiz.diagram.part.Messages.Google_plus8CreationTool_desc,
				Collections.singletonList(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Google_plus_2011));
		entry.setId("createGoogle_plus8CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes
				.getImageDescriptor(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Google_plus_2011));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createHome9CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				dsl_4webquiz.diagram.part.Messages.Home9CreationTool_title,
				dsl_4webquiz.diagram.part.Messages.Home9CreationTool_desc,
				Collections.singletonList(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Home_2009));
		entry.setId("createHome9CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes
				.getImageDescriptor(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Home_2009));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createIndice10CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				dsl_4webquiz.diagram.part.Messages.Indice10CreationTool_title,
				dsl_4webquiz.diagram.part.Messages.Indice10CreationTool_desc,
				Collections.singletonList(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Indice_2001));
		entry.setId("createIndice10CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes
				.getImageDescriptor(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Indice_2001));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createOpcion11CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				dsl_4webquiz.diagram.part.Messages.Opcion11CreationTool_title,
				dsl_4webquiz.diagram.part.Messages.Opcion11CreationTool_desc,
				Collections.singletonList(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Opcion_3003));
		entry.setId("createOpcion11CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes
				.getImageDescriptor(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Opcion_3003));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createPreguntaCorta12CreationTool() {
		ArrayList<IElementType> types = new ArrayList<IElementType>(2);
		types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PreguntaCorta_3001);
		types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PreguntaCorta_3005);
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				dsl_4webquiz.diagram.part.Messages.PreguntaCorta12CreationTool_title,
				dsl_4webquiz.diagram.part.Messages.PreguntaCorta12CreationTool_desc, types);
		entry.setId("createPreguntaCorta12CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes
				.getImageDescriptor(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PreguntaCorta_3001));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createRSS13CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				dsl_4webquiz.diagram.part.Messages.RSS13CreationTool_title,
				dsl_4webquiz.diagram.part.Messages.RSS13CreationTool_desc,
				Collections.singletonList(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.RSS_2012));
		entry.setId("createRSS13CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes
				.getImageDescriptor(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.RSS_2012));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createSeleccion14CreationTool() {
		ArrayList<IElementType> types = new ArrayList<IElementType>(2);
		types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Seleccion_3002);
		types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Seleccion_3006);
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				dsl_4webquiz.diagram.part.Messages.Seleccion14CreationTool_title,
				dsl_4webquiz.diagram.part.Messages.Seleccion14CreationTool_desc, types);
		entry.setId("createSeleccion14CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes
				.getImageDescriptor(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Seleccion_3002));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createTipoDatos15CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				dsl_4webquiz.diagram.part.Messages.TipoDatos15CreationTool_title,
				dsl_4webquiz.diagram.part.Messages.TipoDatos15CreationTool_desc,
				Collections.singletonList(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.TipoDatos_2014));
		entry.setId("createTipoDatos15CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes
				.getImageDescriptor(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.TipoDatos_2014));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createTwitter16CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				dsl_4webquiz.diagram.part.Messages.Twitter16CreationTool_title,
				dsl_4webquiz.diagram.part.Messages.Twitter16CreationTool_desc,
				Collections.singletonList(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Twitter_2010));
		entry.setId("createTwitter16CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes
				.getImageDescriptor(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Twitter_2010));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createUpdate17CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				dsl_4webquiz.diagram.part.Messages.Update17CreationTool_title,
				dsl_4webquiz.diagram.part.Messages.Update17CreationTool_desc,
				Collections.singletonList(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Update_2008));
		entry.setId("createUpdate17CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes
				.getImageDescriptor(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Update_2008));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createUsuario18CreationTool() {
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				dsl_4webquiz.diagram.part.Messages.Usuario18CreationTool_title,
				dsl_4webquiz.diagram.part.Messages.Usuario18CreationTool_desc,
				Collections.singletonList(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Usuario_2013));
		entry.setId("createUsuario18CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes
				.getImageDescriptor(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.Usuario_2013));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createVoF19CreationTool() {
		ArrayList<IElementType> types = new ArrayList<IElementType>(2);
		types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.VoF_3004);
		types.add(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.VoF_3007);
		DefaultNodeToolEntry entry = new DefaultNodeToolEntry(
				dsl_4webquiz.diagram.part.Messages.VoF19CreationTool_title,
				dsl_4webquiz.diagram.part.Messages.VoF19CreationTool_desc, types);
		entry.setId("createVoF19CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes
				.getImageDescriptor(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.VoF_3004));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createConsulta1CreationTool() {
		DefaultLinkToolEntry entry = new DefaultLinkToolEntry(
				dsl_4webquiz.diagram.part.Messages.Consulta1CreationTool_title,
				dsl_4webquiz.diagram.part.Messages.Consulta1CreationTool_desc,
				Collections.singletonList(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.HomeConsulta_4004));
		entry.setId("createConsulta1CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes
				.getImageDescriptor(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.HomeConsulta_4004));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createCrud2CreationTool() {
		DefaultLinkToolEntry entry = new DefaultLinkToolEntry(
				dsl_4webquiz.diagram.part.Messages.Crud2CreationTool_title,
				dsl_4webquiz.diagram.part.Messages.Crud2CreationTool_desc,
				Collections.singletonList(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.HomeCrud_4003));
		entry.setId("createCrud2CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes
				.getImageDescriptor(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.HomeCrud_4003));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createHome3CreationTool() {
		DefaultLinkToolEntry entry = new DefaultLinkToolEntry(
				dsl_4webquiz.diagram.part.Messages.Home3CreationTool_title,
				dsl_4webquiz.diagram.part.Messages.Home3CreationTool_desc, Collections
						.singletonList(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PAGINAS_CRUDHome_4002));
		entry.setId("createHome3CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes
				.getImageDescriptor(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PAGINAS_CRUDHome_4002));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createHome4CreationTool() {
		DefaultLinkToolEntry entry = new DefaultLinkToolEntry(
				dsl_4webquiz.diagram.part.Messages.Home4CreationTool_title,
				dsl_4webquiz.diagram.part.Messages.Home4CreationTool_desc,
				Collections.singletonList(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.ConsultaHome_4005));
		entry.setId("createHome4CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes
				.getImageDescriptor(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.ConsultaHome_4005));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createRedes_sociales5CreationTool() {
		DefaultLinkToolEntry entry = new DefaultLinkToolEntry(
				dsl_4webquiz.diagram.part.Messages.Redes_sociales5CreationTool_title,
				dsl_4webquiz.diagram.part.Messages.Redes_sociales5CreationTool_desc, Collections.singletonList(
						dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PaginaRedes_sociales_4001));
		entry.setId("createRedes_sociales5CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes
				.getImageDescriptor(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PaginaRedes_sociales_4001));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	* @generated
	*/
	private ToolEntry createTipodatos6CreationTool() {
		DefaultLinkToolEntry entry = new DefaultLinkToolEntry(
				dsl_4webquiz.diagram.part.Messages.Tipodatos6CreationTool_title,
				dsl_4webquiz.diagram.part.Messages.Tipodatos6CreationTool_desc, Collections.singletonList(
						dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PAGINAS_CRUDTipodatos_4006));
		entry.setId("createTipodatos6CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.getImageDescriptor(
				dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PAGINAS_CRUDTipodatos_4006));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

}
