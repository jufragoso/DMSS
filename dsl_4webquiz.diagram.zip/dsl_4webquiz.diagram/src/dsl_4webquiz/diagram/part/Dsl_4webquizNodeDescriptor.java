/*
* 
*/
package dsl_4webquiz.diagram.part;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.tooling.runtime.update.UpdaterNodeDescriptor;

/**
 * @generated
 */
public class Dsl_4webquizNodeDescriptor extends UpdaterNodeDescriptor {
	/**
	* @generated
	*/
	public Dsl_4webquizNodeDescriptor(EObject modelElement, int visualID) {
		super(modelElement, visualID);
	}

}
