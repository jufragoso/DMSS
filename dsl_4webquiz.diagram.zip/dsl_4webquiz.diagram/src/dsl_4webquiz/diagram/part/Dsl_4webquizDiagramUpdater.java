/*
* 
*/
package dsl_4webquiz.diagram.part;

import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.gmf.tooling.runtime.update.DiagramUpdater;

/**
 * @generated
 */
public class Dsl_4webquizDiagramUpdater {

	/**
	* @generated
	*/
	public static boolean isShortcutOrphaned(View view) {
		return !view.isSetElement() || view.getElement() == null || view.getElement().eIsProxy();
	}

	/**
	* @generated
	*/
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor> getSemanticChildren(View view) {
		switch (dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getVisualID(view)) {
		case dsl_4webquiz.diagram.edit.parts.WebEditPart.VISUAL_ID:
			return getWeb_1000SemanticChildren(view);
		case dsl_4webquiz.diagram.edit.parts.EncuestaEncuestaPreguntaEncuestaCompartmentEditPart.VISUAL_ID:
			return getEncuestaEncuestaPreguntaEncuestaCompartment_7001SemanticChildren(view);
		case dsl_4webquiz.diagram.edit.parts.SeleccionSeleccionOpcionCompartmentEditPart.VISUAL_ID:
			return getSeleccionSeleccionOpcionCompartment_7002SemanticChildren(view);
		case dsl_4webquiz.diagram.edit.parts.CuestionarioCuestionarioPreguntaCuestionarioCompartmentEditPart.VISUAL_ID:
			return getCuestionarioCuestionarioPreguntaCuestionarioCompartment_7003SemanticChildren(view);
		case dsl_4webquiz.diagram.edit.parts.SeleccionSeleccionOpcionCompartment2EditPart.VISUAL_ID:
			return getSeleccionSeleccionOpcionCompartment_7004SemanticChildren(view);
		case dsl_4webquiz.diagram.edit.parts.TipoDatosTipoDatosAtributoCompartmentEditPart.VISUAL_ID:
			return getTipoDatosTipoDatosAtributoCompartment_7005SemanticChildren(view);
		}
		return Collections.emptyList();
	}

	/**
	* @generated
	*/
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor> getWeb_1000SemanticChildren(View view) {
		if (!view.isSetElement()) {
			return Collections.emptyList();
		}
		dsl_4webquiz.Web modelElement = (dsl_4webquiz.Web) view.getElement();
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor>();
		for (Iterator<?> it = modelElement.getPagina().iterator(); it.hasNext();) {
			dsl_4webquiz.Pagina childElement = (dsl_4webquiz.Pagina) it.next();
			int visualID = dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getNodeVisualID(view, childElement);
			if (visualID == dsl_4webquiz.diagram.edit.parts.IndiceEditPart.VISUAL_ID) {
				result.add(new dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == dsl_4webquiz.diagram.edit.parts.DetalleEditPart.VISUAL_ID) {
				result.add(new dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == dsl_4webquiz.diagram.edit.parts.CreacionEditPart.VISUAL_ID) {
				result.add(new dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == dsl_4webquiz.diagram.edit.parts.BorradoEditPart.VISUAL_ID) {
				result.add(new dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == dsl_4webquiz.diagram.edit.parts.EncuestaEditPart.VISUAL_ID) {
				result.add(new dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == dsl_4webquiz.diagram.edit.parts.CuestionarioEditPart.VISUAL_ID) {
				result.add(new dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == dsl_4webquiz.diagram.edit.parts.CRUDEditPart.VISUAL_ID) {
				result.add(new dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == dsl_4webquiz.diagram.edit.parts.UpdateEditPart.VISUAL_ID) {
				result.add(new dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == dsl_4webquiz.diagram.edit.parts.HomeEditPart.VISUAL_ID) {
				result.add(new dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		for (Iterator<?> it = modelElement.getRedes_sociales().iterator(); it.hasNext();) {
			dsl_4webquiz.Redes_Sociales childElement = (dsl_4webquiz.Redes_Sociales) it.next();
			int visualID = dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getNodeVisualID(view, childElement);
			if (visualID == dsl_4webquiz.diagram.edit.parts.TwitterEditPart.VISUAL_ID) {
				result.add(new dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == dsl_4webquiz.diagram.edit.parts.Google_plusEditPart.VISUAL_ID) {
				result.add(new dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == dsl_4webquiz.diagram.edit.parts.RSSEditPart.VISUAL_ID) {
				result.add(new dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		for (Iterator<?> it = modelElement.getUsuario().iterator(); it.hasNext();) {
			dsl_4webquiz.Usuario childElement = (dsl_4webquiz.Usuario) it.next();
			int visualID = dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getNodeVisualID(view, childElement);
			if (visualID == dsl_4webquiz.diagram.edit.parts.UsuarioEditPart.VISUAL_ID) {
				result.add(new dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		for (Iterator<?> it = modelElement.getEntidad().iterator(); it.hasNext();) {
			dsl_4webquiz.TipoDatos childElement = (dsl_4webquiz.TipoDatos) it.next();
			int visualID = dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getNodeVisualID(view, childElement);
			if (visualID == dsl_4webquiz.diagram.edit.parts.TipoDatosEditPart.VISUAL_ID) {
				result.add(new dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor> getEncuestaEncuestaPreguntaEncuestaCompartment_7001SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		dsl_4webquiz.Encuesta modelElement = (dsl_4webquiz.Encuesta) containerView.getElement();
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor>();
		for (Iterator<?> it = modelElement.getPreguntaEncuesta().iterator(); it.hasNext();) {
			dsl_4webquiz.Pregunta childElement = (dsl_4webquiz.Pregunta) it.next();
			int visualID = dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getNodeVisualID(view, childElement);
			if (visualID == dsl_4webquiz.diagram.edit.parts.PreguntaCortaEditPart.VISUAL_ID) {
				result.add(new dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == dsl_4webquiz.diagram.edit.parts.SeleccionEditPart.VISUAL_ID) {
				result.add(new dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == dsl_4webquiz.diagram.edit.parts.VoFEditPart.VISUAL_ID) {
				result.add(new dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor> getSeleccionSeleccionOpcionCompartment_7002SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		dsl_4webquiz.Seleccion modelElement = (dsl_4webquiz.Seleccion) containerView.getElement();
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor>();
		for (Iterator<?> it = modelElement.getOpcion().iterator(); it.hasNext();) {
			dsl_4webquiz.Opcion childElement = (dsl_4webquiz.Opcion) it.next();
			int visualID = dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getNodeVisualID(view, childElement);
			if (visualID == dsl_4webquiz.diagram.edit.parts.OpcionEditPart.VISUAL_ID) {
				result.add(new dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor> getCuestionarioCuestionarioPreguntaCuestionarioCompartment_7003SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		dsl_4webquiz.Cuestionario modelElement = (dsl_4webquiz.Cuestionario) containerView.getElement();
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor>();
		for (Iterator<?> it = modelElement.getPreguntaCuestionario().iterator(); it.hasNext();) {
			dsl_4webquiz.Pregunta childElement = (dsl_4webquiz.Pregunta) it.next();
			int visualID = dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getNodeVisualID(view, childElement);
			if (visualID == dsl_4webquiz.diagram.edit.parts.PreguntaCorta2EditPart.VISUAL_ID) {
				result.add(new dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == dsl_4webquiz.diagram.edit.parts.Seleccion2EditPart.VISUAL_ID) {
				result.add(new dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == dsl_4webquiz.diagram.edit.parts.VoF2EditPart.VISUAL_ID) {
				result.add(new dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor> getSeleccionSeleccionOpcionCompartment_7004SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		dsl_4webquiz.Seleccion modelElement = (dsl_4webquiz.Seleccion) containerView.getElement();
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor>();
		for (Iterator<?> it = modelElement.getOpcion().iterator(); it.hasNext();) {
			dsl_4webquiz.Opcion childElement = (dsl_4webquiz.Opcion) it.next();
			int visualID = dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getNodeVisualID(view, childElement);
			if (visualID == dsl_4webquiz.diagram.edit.parts.OpcionEditPart.VISUAL_ID) {
				result.add(new dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor> getTipoDatosTipoDatosAtributoCompartment_7005SemanticChildren(
			View view) {
		if (false == view.eContainer() instanceof View) {
			return Collections.emptyList();
		}
		View containerView = (View) view.eContainer();
		if (!containerView.isSetElement()) {
			return Collections.emptyList();
		}
		dsl_4webquiz.TipoDatos modelElement = (dsl_4webquiz.TipoDatos) containerView.getElement();
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor>();
		for (Iterator<?> it = modelElement.getAtributo().iterator(); it.hasNext();) {
			dsl_4webquiz.Atributo childElement = (dsl_4webquiz.Atributo) it.next();
			int visualID = dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getNodeVisualID(view, childElement);
			if (visualID == dsl_4webquiz.diagram.edit.parts.AtributoEditPart.VISUAL_ID) {
				result.add(new dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getContainedLinks(View view) {
		switch (dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getVisualID(view)) {
		case dsl_4webquiz.diagram.edit.parts.WebEditPart.VISUAL_ID:
			return getWeb_1000ContainedLinks(view);
		case dsl_4webquiz.diagram.edit.parts.IndiceEditPart.VISUAL_ID:
			return getIndice_2001ContainedLinks(view);
		case dsl_4webquiz.diagram.edit.parts.DetalleEditPart.VISUAL_ID:
			return getDetalle_2002ContainedLinks(view);
		case dsl_4webquiz.diagram.edit.parts.CreacionEditPart.VISUAL_ID:
			return getCreacion_2003ContainedLinks(view);
		case dsl_4webquiz.diagram.edit.parts.BorradoEditPart.VISUAL_ID:
			return getBorrado_2004ContainedLinks(view);
		case dsl_4webquiz.diagram.edit.parts.EncuestaEditPart.VISUAL_ID:
			return getEncuesta_2005ContainedLinks(view);
		case dsl_4webquiz.diagram.edit.parts.CuestionarioEditPart.VISUAL_ID:
			return getCuestionario_2006ContainedLinks(view);
		case dsl_4webquiz.diagram.edit.parts.CRUDEditPart.VISUAL_ID:
			return getCRUD_2007ContainedLinks(view);
		case dsl_4webquiz.diagram.edit.parts.UpdateEditPart.VISUAL_ID:
			return getUpdate_2008ContainedLinks(view);
		case dsl_4webquiz.diagram.edit.parts.HomeEditPart.VISUAL_ID:
			return getHome_2009ContainedLinks(view);
		case dsl_4webquiz.diagram.edit.parts.TwitterEditPart.VISUAL_ID:
			return getTwitter_2010ContainedLinks(view);
		case dsl_4webquiz.diagram.edit.parts.Google_plusEditPart.VISUAL_ID:
			return getGoogle_plus_2011ContainedLinks(view);
		case dsl_4webquiz.diagram.edit.parts.RSSEditPart.VISUAL_ID:
			return getRSS_2012ContainedLinks(view);
		case dsl_4webquiz.diagram.edit.parts.UsuarioEditPart.VISUAL_ID:
			return getUsuario_2013ContainedLinks(view);
		case dsl_4webquiz.diagram.edit.parts.TipoDatosEditPart.VISUAL_ID:
			return getTipoDatos_2014ContainedLinks(view);
		case dsl_4webquiz.diagram.edit.parts.PreguntaCortaEditPart.VISUAL_ID:
			return getPreguntaCorta_3001ContainedLinks(view);
		case dsl_4webquiz.diagram.edit.parts.SeleccionEditPart.VISUAL_ID:
			return getSeleccion_3002ContainedLinks(view);
		case dsl_4webquiz.diagram.edit.parts.OpcionEditPart.VISUAL_ID:
			return getOpcion_3003ContainedLinks(view);
		case dsl_4webquiz.diagram.edit.parts.VoFEditPart.VISUAL_ID:
			return getVoF_3004ContainedLinks(view);
		case dsl_4webquiz.diagram.edit.parts.PreguntaCorta2EditPart.VISUAL_ID:
			return getPreguntaCorta_3005ContainedLinks(view);
		case dsl_4webquiz.diagram.edit.parts.Seleccion2EditPart.VISUAL_ID:
			return getSeleccion_3006ContainedLinks(view);
		case dsl_4webquiz.diagram.edit.parts.VoF2EditPart.VISUAL_ID:
			return getVoF_3007ContainedLinks(view);
		case dsl_4webquiz.diagram.edit.parts.AtributoEditPart.VISUAL_ID:
			return getAtributo_3008ContainedLinks(view);
		}
		return Collections.emptyList();
	}

	/**
	* @generated
	*/
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getIncomingLinks(View view) {
		switch (dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getVisualID(view)) {
		case dsl_4webquiz.diagram.edit.parts.IndiceEditPart.VISUAL_ID:
			return getIndice_2001IncomingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.DetalleEditPart.VISUAL_ID:
			return getDetalle_2002IncomingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.CreacionEditPart.VISUAL_ID:
			return getCreacion_2003IncomingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.BorradoEditPart.VISUAL_ID:
			return getBorrado_2004IncomingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.EncuestaEditPart.VISUAL_ID:
			return getEncuesta_2005IncomingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.CuestionarioEditPart.VISUAL_ID:
			return getCuestionario_2006IncomingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.CRUDEditPart.VISUAL_ID:
			return getCRUD_2007IncomingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.UpdateEditPart.VISUAL_ID:
			return getUpdate_2008IncomingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.HomeEditPart.VISUAL_ID:
			return getHome_2009IncomingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.TwitterEditPart.VISUAL_ID:
			return getTwitter_2010IncomingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.Google_plusEditPart.VISUAL_ID:
			return getGoogle_plus_2011IncomingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.RSSEditPart.VISUAL_ID:
			return getRSS_2012IncomingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.UsuarioEditPart.VISUAL_ID:
			return getUsuario_2013IncomingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.TipoDatosEditPart.VISUAL_ID:
			return getTipoDatos_2014IncomingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.PreguntaCortaEditPart.VISUAL_ID:
			return getPreguntaCorta_3001IncomingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.SeleccionEditPart.VISUAL_ID:
			return getSeleccion_3002IncomingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.OpcionEditPart.VISUAL_ID:
			return getOpcion_3003IncomingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.VoFEditPart.VISUAL_ID:
			return getVoF_3004IncomingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.PreguntaCorta2EditPart.VISUAL_ID:
			return getPreguntaCorta_3005IncomingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.Seleccion2EditPart.VISUAL_ID:
			return getSeleccion_3006IncomingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.VoF2EditPart.VISUAL_ID:
			return getVoF_3007IncomingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.AtributoEditPart.VISUAL_ID:
			return getAtributo_3008IncomingLinks(view);
		}
		return Collections.emptyList();
	}

	/**
	* @generated
	*/
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getOutgoingLinks(View view) {
		switch (dsl_4webquiz.diagram.part.Dsl_4webquizVisualIDRegistry.getVisualID(view)) {
		case dsl_4webquiz.diagram.edit.parts.IndiceEditPart.VISUAL_ID:
			return getIndice_2001OutgoingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.DetalleEditPart.VISUAL_ID:
			return getDetalle_2002OutgoingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.CreacionEditPart.VISUAL_ID:
			return getCreacion_2003OutgoingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.BorradoEditPart.VISUAL_ID:
			return getBorrado_2004OutgoingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.EncuestaEditPart.VISUAL_ID:
			return getEncuesta_2005OutgoingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.CuestionarioEditPart.VISUAL_ID:
			return getCuestionario_2006OutgoingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.CRUDEditPart.VISUAL_ID:
			return getCRUD_2007OutgoingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.UpdateEditPart.VISUAL_ID:
			return getUpdate_2008OutgoingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.HomeEditPart.VISUAL_ID:
			return getHome_2009OutgoingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.TwitterEditPart.VISUAL_ID:
			return getTwitter_2010OutgoingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.Google_plusEditPart.VISUAL_ID:
			return getGoogle_plus_2011OutgoingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.RSSEditPart.VISUAL_ID:
			return getRSS_2012OutgoingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.UsuarioEditPart.VISUAL_ID:
			return getUsuario_2013OutgoingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.TipoDatosEditPart.VISUAL_ID:
			return getTipoDatos_2014OutgoingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.PreguntaCortaEditPart.VISUAL_ID:
			return getPreguntaCorta_3001OutgoingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.SeleccionEditPart.VISUAL_ID:
			return getSeleccion_3002OutgoingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.OpcionEditPart.VISUAL_ID:
			return getOpcion_3003OutgoingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.VoFEditPart.VISUAL_ID:
			return getVoF_3004OutgoingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.PreguntaCorta2EditPart.VISUAL_ID:
			return getPreguntaCorta_3005OutgoingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.Seleccion2EditPart.VISUAL_ID:
			return getSeleccion_3006OutgoingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.VoF2EditPart.VISUAL_ID:
			return getVoF_3007OutgoingLinks(view);
		case dsl_4webquiz.diagram.edit.parts.AtributoEditPart.VISUAL_ID:
			return getAtributo_3008OutgoingLinks(view);
		}
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getWeb_1000ContainedLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getIndice_2001ContainedLinks(View view) {
		dsl_4webquiz.Indice modelElement = (dsl_4webquiz.Indice) view.getElement();
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Pagina_Redes_sociales_4001(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_PAGINAS_CRUD_Home_4002(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_PAGINAS_CRUD_Tipodatos_4006(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getDetalle_2002ContainedLinks(View view) {
		dsl_4webquiz.Detalle modelElement = (dsl_4webquiz.Detalle) view.getElement();
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Pagina_Redes_sociales_4001(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_PAGINAS_CRUD_Home_4002(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_PAGINAS_CRUD_Tipodatos_4006(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getCreacion_2003ContainedLinks(View view) {
		dsl_4webquiz.Creacion modelElement = (dsl_4webquiz.Creacion) view.getElement();
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Pagina_Redes_sociales_4001(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_PAGINAS_CRUD_Home_4002(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_PAGINAS_CRUD_Tipodatos_4006(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getBorrado_2004ContainedLinks(View view) {
		dsl_4webquiz.Borrado modelElement = (dsl_4webquiz.Borrado) view.getElement();
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Pagina_Redes_sociales_4001(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_PAGINAS_CRUD_Home_4002(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_PAGINAS_CRUD_Tipodatos_4006(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getEncuesta_2005ContainedLinks(View view) {
		dsl_4webquiz.Encuesta modelElement = (dsl_4webquiz.Encuesta) view.getElement();
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Pagina_Redes_sociales_4001(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_Consulta_Home_4005(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getCuestionario_2006ContainedLinks(
			View view) {
		dsl_4webquiz.Cuestionario modelElement = (dsl_4webquiz.Cuestionario) view.getElement();
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Pagina_Redes_sociales_4001(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_Consulta_Home_4005(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getCRUD_2007ContainedLinks(View view) {
		dsl_4webquiz.CRUD modelElement = (dsl_4webquiz.CRUD) view.getElement();
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Pagina_Redes_sociales_4001(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_PAGINAS_CRUD_Home_4002(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_PAGINAS_CRUD_Tipodatos_4006(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getUpdate_2008ContainedLinks(View view) {
		dsl_4webquiz.Update modelElement = (dsl_4webquiz.Update) view.getElement();
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Pagina_Redes_sociales_4001(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_PAGINAS_CRUD_Home_4002(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_PAGINAS_CRUD_Tipodatos_4006(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getHome_2009ContainedLinks(View view) {
		dsl_4webquiz.Home modelElement = (dsl_4webquiz.Home) view.getElement();
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Pagina_Redes_sociales_4001(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_Home_Crud_4003(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_Home_Consulta_4004(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getTwitter_2010ContainedLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getGoogle_plus_2011ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getRSS_2012ContainedLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getUsuario_2013ContainedLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getTipoDatos_2014ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getPreguntaCorta_3001ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getSeleccion_3002ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getOpcion_3003ContainedLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getVoF_3004ContainedLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getPreguntaCorta_3005ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getSeleccion_3006ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getVoF_3007ContainedLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getAtributo_3008ContainedLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getIndice_2001IncomingLinks(View view) {
		dsl_4webquiz.Indice modelElement = (dsl_4webquiz.Indice) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_Home_Crud_4003(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getDetalle_2002IncomingLinks(View view) {
		dsl_4webquiz.Detalle modelElement = (dsl_4webquiz.Detalle) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_Home_Crud_4003(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getCreacion_2003IncomingLinks(View view) {
		dsl_4webquiz.Creacion modelElement = (dsl_4webquiz.Creacion) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_Home_Crud_4003(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getBorrado_2004IncomingLinks(View view) {
		dsl_4webquiz.Borrado modelElement = (dsl_4webquiz.Borrado) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_Home_Crud_4003(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getEncuesta_2005IncomingLinks(View view) {
		dsl_4webquiz.Encuesta modelElement = (dsl_4webquiz.Encuesta) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_Home_Consulta_4004(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getCuestionario_2006IncomingLinks(
			View view) {
		dsl_4webquiz.Cuestionario modelElement = (dsl_4webquiz.Cuestionario) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_Home_Consulta_4004(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getCRUD_2007IncomingLinks(View view) {
		dsl_4webquiz.CRUD modelElement = (dsl_4webquiz.CRUD) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_Home_Crud_4003(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getUpdate_2008IncomingLinks(View view) {
		dsl_4webquiz.Update modelElement = (dsl_4webquiz.Update) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_Home_Crud_4003(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getHome_2009IncomingLinks(View view) {
		dsl_4webquiz.Home modelElement = (dsl_4webquiz.Home) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_PAGINAS_CRUD_Home_4002(modelElement, crossReferences));
		result.addAll(getIncomingFeatureModelFacetLinks_Consulta_Home_4005(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getTwitter_2010IncomingLinks(View view) {
		dsl_4webquiz.Twitter modelElement = (dsl_4webquiz.Twitter) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_Pagina_Redes_sociales_4001(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getGoogle_plus_2011IncomingLinks(
			View view) {
		dsl_4webquiz.Google_plus modelElement = (dsl_4webquiz.Google_plus) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_Pagina_Redes_sociales_4001(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getRSS_2012IncomingLinks(View view) {
		dsl_4webquiz.RSS modelElement = (dsl_4webquiz.RSS) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_Pagina_Redes_sociales_4001(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getUsuario_2013IncomingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getTipoDatos_2014IncomingLinks(View view) {
		dsl_4webquiz.TipoDatos modelElement = (dsl_4webquiz.TipoDatos) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		result.addAll(getIncomingFeatureModelFacetLinks_PAGINAS_CRUD_Tipodatos_4006(modelElement, crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getPreguntaCorta_3001IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getSeleccion_3002IncomingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getOpcion_3003IncomingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getVoF_3004IncomingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getPreguntaCorta_3005IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getSeleccion_3006IncomingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getVoF_3007IncomingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getAtributo_3008IncomingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getIndice_2001OutgoingLinks(View view) {
		dsl_4webquiz.Indice modelElement = (dsl_4webquiz.Indice) view.getElement();
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Pagina_Redes_sociales_4001(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_PAGINAS_CRUD_Home_4002(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_PAGINAS_CRUD_Tipodatos_4006(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getDetalle_2002OutgoingLinks(View view) {
		dsl_4webquiz.Detalle modelElement = (dsl_4webquiz.Detalle) view.getElement();
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Pagina_Redes_sociales_4001(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_PAGINAS_CRUD_Home_4002(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_PAGINAS_CRUD_Tipodatos_4006(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getCreacion_2003OutgoingLinks(View view) {
		dsl_4webquiz.Creacion modelElement = (dsl_4webquiz.Creacion) view.getElement();
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Pagina_Redes_sociales_4001(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_PAGINAS_CRUD_Home_4002(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_PAGINAS_CRUD_Tipodatos_4006(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getBorrado_2004OutgoingLinks(View view) {
		dsl_4webquiz.Borrado modelElement = (dsl_4webquiz.Borrado) view.getElement();
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Pagina_Redes_sociales_4001(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_PAGINAS_CRUD_Home_4002(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_PAGINAS_CRUD_Tipodatos_4006(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getEncuesta_2005OutgoingLinks(View view) {
		dsl_4webquiz.Encuesta modelElement = (dsl_4webquiz.Encuesta) view.getElement();
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Pagina_Redes_sociales_4001(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_Consulta_Home_4005(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getCuestionario_2006OutgoingLinks(
			View view) {
		dsl_4webquiz.Cuestionario modelElement = (dsl_4webquiz.Cuestionario) view.getElement();
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Pagina_Redes_sociales_4001(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_Consulta_Home_4005(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getCRUD_2007OutgoingLinks(View view) {
		dsl_4webquiz.CRUD modelElement = (dsl_4webquiz.CRUD) view.getElement();
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Pagina_Redes_sociales_4001(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_PAGINAS_CRUD_Home_4002(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_PAGINAS_CRUD_Tipodatos_4006(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getUpdate_2008OutgoingLinks(View view) {
		dsl_4webquiz.Update modelElement = (dsl_4webquiz.Update) view.getElement();
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Pagina_Redes_sociales_4001(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_PAGINAS_CRUD_Home_4002(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_PAGINAS_CRUD_Tipodatos_4006(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getHome_2009OutgoingLinks(View view) {
		dsl_4webquiz.Home modelElement = (dsl_4webquiz.Home) view.getElement();
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		result.addAll(getOutgoingFeatureModelFacetLinks_Pagina_Redes_sociales_4001(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_Home_Crud_4003(modelElement));
		result.addAll(getOutgoingFeatureModelFacetLinks_Home_Consulta_4004(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getTwitter_2010OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getGoogle_plus_2011OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getRSS_2012OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getUsuario_2013OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getTipoDatos_2014OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getPreguntaCorta_3001OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getSeleccion_3002OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getOpcion_3003OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getVoF_3004OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getPreguntaCorta_3005OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getSeleccion_3006OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getVoF_3007OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getAtributo_3008OutgoingLinks(View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	private static Collection<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getIncomingFeatureModelFacetLinks_Pagina_Redes_sociales_4001(
			dsl_4webquiz.Redes_Sociales target, Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() == dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE
					.getPagina_Redes_sociales()) {
				result.add(new dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor(setting.getEObject(), target,
						dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PaginaRedes_sociales_4001,
						dsl_4webquiz.diagram.edit.parts.PaginaRedes_socialesEditPart.VISUAL_ID));
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getIncomingFeatureModelFacetLinks_PAGINAS_CRUD_Home_4002(
			dsl_4webquiz.Home target, Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() == dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getPAGINAS_CRUD_Home()) {
				result.add(new dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor(setting.getEObject(), target,
						dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PAGINAS_CRUDHome_4002,
						dsl_4webquiz.diagram.edit.parts.PAGINAS_CRUDHomeEditPart.VISUAL_ID));
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	private static Collection<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getIncomingFeatureModelFacetLinks_PAGINAS_CRUD_Tipodatos_4006(
			dsl_4webquiz.TipoDatos target, Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() == dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE
					.getPAGINAS_CRUD_Tipodatos()) {
				result.add(new dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor(setting.getEObject(), target,
						dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PAGINAS_CRUDTipodatos_4006,
						dsl_4webquiz.diagram.edit.parts.PAGINAS_CRUDTipodatosEditPart.VISUAL_ID));
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getIncomingFeatureModelFacetLinks_Home_Crud_4003(
			dsl_4webquiz.PAGINAS_CRUD target, Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() == dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getHome_Crud()) {
				result.add(new dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor(setting.getEObject(), target,
						dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.HomeCrud_4003,
						dsl_4webquiz.diagram.edit.parts.HomeCrudEditPart.VISUAL_ID));
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getIncomingFeatureModelFacetLinks_Home_Consulta_4004(
			dsl_4webquiz.Consulta target, Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() == dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getHome_Consulta()) {
				result.add(new dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor(setting.getEObject(), target,
						dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.HomeConsulta_4004,
						dsl_4webquiz.diagram.edit.parts.HomeConsultaEditPart.VISUAL_ID));
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getIncomingFeatureModelFacetLinks_Consulta_Home_4005(
			dsl_4webquiz.Home target, Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() == dsl_4webquiz.Dsl_4webquizPackage.eINSTANCE.getConsulta_Home()) {
				result.add(new dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor(setting.getEObject(), target,
						dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.ConsultaHome_4005,
						dsl_4webquiz.diagram.edit.parts.ConsultaHomeEditPart.VISUAL_ID));
			}
		}
		return result;
	}

	/**
	* @generated
	*/
	private static Collection<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getOutgoingFeatureModelFacetLinks_Pagina_Redes_sociales_4001(
			dsl_4webquiz.Pagina source) {
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		for (Iterator<?> destinations = source.getRedes_sociales().iterator(); destinations.hasNext();) {
			dsl_4webquiz.Redes_Sociales destination = (dsl_4webquiz.Redes_Sociales) destinations.next();
			result.add(new dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor(source, destination,
					dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PaginaRedes_sociales_4001,
					dsl_4webquiz.diagram.edit.parts.PaginaRedes_socialesEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	* @generated
	*/
	private static Collection<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getOutgoingFeatureModelFacetLinks_PAGINAS_CRUD_Home_4002(
			dsl_4webquiz.PAGINAS_CRUD source) {
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		dsl_4webquiz.Home destination = source.getHome();
		if (destination == null) {
			return result;
		}
		result.add(new dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor(source, destination,
				dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PAGINAS_CRUDHome_4002,
				dsl_4webquiz.diagram.edit.parts.PAGINAS_CRUDHomeEditPart.VISUAL_ID));
		return result;
	}

	/**
	* @generated
	*/
	private static Collection<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getOutgoingFeatureModelFacetLinks_PAGINAS_CRUD_Tipodatos_4006(
			dsl_4webquiz.PAGINAS_CRUD source) {
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		dsl_4webquiz.TipoDatos destination = source.getTipodatos();
		if (destination == null) {
			return result;
		}
		result.add(new dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor(source, destination,
				dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.PAGINAS_CRUDTipodatos_4006,
				dsl_4webquiz.diagram.edit.parts.PAGINAS_CRUDTipodatosEditPart.VISUAL_ID));
		return result;
	}

	/**
	* @generated
	*/
	private static Collection<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getOutgoingFeatureModelFacetLinks_Home_Crud_4003(
			dsl_4webquiz.Home source) {
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		for (Iterator<?> destinations = source.getCrud().iterator(); destinations.hasNext();) {
			dsl_4webquiz.PAGINAS_CRUD destination = (dsl_4webquiz.PAGINAS_CRUD) destinations.next();
			result.add(new dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor(source, destination,
					dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.HomeCrud_4003,
					dsl_4webquiz.diagram.edit.parts.HomeCrudEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	* @generated
	*/
	private static Collection<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getOutgoingFeatureModelFacetLinks_Home_Consulta_4004(
			dsl_4webquiz.Home source) {
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		for (Iterator<?> destinations = source.getConsulta().iterator(); destinations.hasNext();) {
			dsl_4webquiz.Consulta destination = (dsl_4webquiz.Consulta) destinations.next();
			result.add(new dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor(source, destination,
					dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.HomeConsulta_4004,
					dsl_4webquiz.diagram.edit.parts.HomeConsultaEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	* @generated
	*/
	private static Collection<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getOutgoingFeatureModelFacetLinks_Consulta_Home_4005(
			dsl_4webquiz.Consulta source) {
		LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> result = new LinkedList<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor>();
		dsl_4webquiz.Home destination = source.getHome();
		if (destination == null) {
			return result;
		}
		result.add(new dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor(source, destination,
				dsl_4webquiz.diagram.providers.Dsl_4webquizElementTypes.ConsultaHome_4005,
				dsl_4webquiz.diagram.edit.parts.ConsultaHomeEditPart.VISUAL_ID));
		return result;
	}

	/**
	* @generated
	*/
	public static final DiagramUpdater TYPED_INSTANCE = new DiagramUpdater() {
		/**
		* @generated
		*/
		@Override

		public List<dsl_4webquiz.diagram.part.Dsl_4webquizNodeDescriptor> getSemanticChildren(View view) {
			return Dsl_4webquizDiagramUpdater.getSemanticChildren(view);
		}

		/**
		* @generated
		*/
		@Override

		public List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getContainedLinks(View view) {
			return Dsl_4webquizDiagramUpdater.getContainedLinks(view);
		}

		/**
		* @generated
		*/
		@Override

		public List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getIncomingLinks(View view) {
			return Dsl_4webquizDiagramUpdater.getIncomingLinks(view);
		}

		/**
		* @generated
		*/
		@Override

		public List<dsl_4webquiz.diagram.part.Dsl_4webquizLinkDescriptor> getOutgoingLinks(View view) {
			return Dsl_4webquizDiagramUpdater.getOutgoingLinks(view);
		}
	};

}
